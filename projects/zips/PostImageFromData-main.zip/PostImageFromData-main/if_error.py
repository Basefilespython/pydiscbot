class VkLogger():
    def __init__(self, t):pass
    def gTIME(self): return ''
    def send(self, message):pass
    def config(self, message):pass   
    def info(self, message):pass   
    def error(self, error):pass