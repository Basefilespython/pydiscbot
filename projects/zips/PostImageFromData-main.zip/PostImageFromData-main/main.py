import os
import time
import vk_api
from modules.User import User
from modules.functions import *
from modules.Classes import NotPostingImages, VkLogger, Colors
from modules.CheckV.Version import Version 
from modules.longp import longpoll_start
from modules.if_pictures_ravno_zero_naxyi import download

from threading import Thread


try:
    from alive_progress import alive_bar
except ModuleNotFoundError:
    os.system('pip install alive_progress')
    from alive_progress import alive_bar


ProjectVersion = '0.0.1'


if str(os.name) == "nt":dir_pref = "\\"
else:dir_pref = "/"

pictures_folder_directory = f'{os.getcwd()}{dir_pref}pictures'
if not os.path.exists(pictures_folder_directory):
    os.mkdir(pictures_folder_directory)


def one():
    print('Function: one')
    pass

def two():
    print('Function: two')
    pass

def three():
    print('Function: three')
    pass




def main_working_function(user, status_starting):
    time_ = user.time_sleep * 60 * 60
    time_to_start_script = user.time_to_start_script
    try:
        account_getProfileInfo_id, account_getProfileInfo_first_name, account_getProfileInfo_last_name, screen_name, account_getProfileInfo_status, account_getProfileInfo_verification_status = user.account_getProfileInfo()
    except vk_api.exceptions.ApiError as err:
        vlogger.error([vk_api.exceptions.ApiError, err, 'account_getProfileInfo()'])
        print('Failed to call account_getProfileInfo() function by error: %s' % err)
    except FileNotFoundError as err:
        vlogger.error([FileNotFoundError, err, 'account_getProfileInfo()'])
        print('Failed to call account_getProfileInfo() function by error: %s' % err)
        account_getProfileInfo_id, account_getProfileInfo_first_name, account_getProfileInfo_last_name, screen_name, account_getProfileInfo_status, account_getProfileInfo_verification_status =  '0', f'{Colors.red}ERROR{Colors.white}', f'{Colors.red}ERROR{Colors.white}', '0', f'{Colors.red}ERROR{Colors.white}', ''
    except Exception as err:
        vlogger.error(['UNKNOWN', err, 'account_getProfileInfo()'])
        print('Failed to account_getProfileInfo() function by error: %s' % err)
        account_getProfileInfo_id, account_getProfileInfo_first_name, account_getProfileInfo_last_name, screen_name, account_getProfileInfo_status, account_getProfileInfo_verification_status =  None, None, None, None, None, None
    
    try:
        guild_address, guild_name, guild_description, guild_group_id = user.groups_getSettings(user.group_id)
    except Exception as err:
        vlogger.error(['UNKNOWN', err, 'groups_getSettings()'])
        print('Failed to groups_getSettings() function by error: %s' % err)
        guild_address, guild_name, guild_description, guild_group_id = '0', f'{Colors.red}ERROR{Colors.white}', f'{Colors.red}ERROR{Colors.white}', '0'
        
    guild_description = guild_description.replace('\n', '\n┊ ')

    local_ip = get_local_ip_address()
    if local_ip == '95.24.164.242': local_ip = f'{local_ip} ✅'
    else: local_ip = f'{local_ip} ❌'

    print(f'''{"-"*10}
Запущена главная функция ({status_starting})

┌{"―"*5} IP-адрес машины:
┊ IP: {local_ip}
└{"―"*10}


┌{"―"*5} Авторизованный пользователь:
┊ Имя: {account_getProfileInfo_first_name} {account_getProfileInfo_verification_status}
┊ Фамилия: {account_getProfileInfo_last_name}
┊ Статус: {account_getProfileInfo_status}
├{"―"*10}
┊ Cсылка: https://vk.com/{screen_name} (https://vk.com/id{account_getProfileInfo_id})
└{"―"*10}


┌{"―"*5} Группа:
┊ Имя: {guild_name}
┊ Описание:
┊ {guild_description}
├{"―"*10}
┊ Cсылка: https://vk.com/{guild_address} (https://vk.com/club{guild_group_id})
└{"―"*10}
''')

    offset = get_offset_for_script(8, time_)
    vlogger.info(f'Offset {offset}')
    print(f'''
┌{"―"*34}┐
┊ Текущее время:          {str(time.strftime("%H:%M:%S", time.localtime()))} ┊
┊ Запуск назначен на:     {time_to_start_script} ┊
└{"―"*34}┘''')

    while str(time.strftime("%H:%M:%S", time.localtime())) != time_to_start_script:#time_to_start_script:
        time.sleep(1)

    print(f'\n┌{"―"*5}\n┊ Запуск...\n└{"―"*45}')
    vlogger.info('Запуск...')

    len_find_imgs = len(get_images_in_folder(pictures_folder_directory))
    print(f'Количество найденных изображений: {len_find_imgs}')
    vlogger.info(f'Количество найденных изображений: {len_find_imgs}')
    del len_find_imgs


    while True:
        print(f'{"-"*20}')
        try:
            if check_files(pictures_folder_directory) == False:
                if not os.path.exists(pictures_folder_directory):os.mkdir(pictures_folder_directory)
                download(pictures_folder_directory)



            try:
                picture = get_random_image(pictures_folder_directory)
            except vk_api.exceptions.ApiError as err:
                vlogger.error([vk_api.exceptions.ApiError, err, 'get_random_image'])
                print('Failed to call get_random_image function by error: %s' % err)
            except Exception as err:
                vlogger.error(['UNKNOWN', err, 'get_random_image'])
                print('Failed to get_random_image function by error: %s' % err)
            photo = user.picture_send(picture, pictures_folder_directory)
            post_id = user.make_post(photo)['post_id'] # 1
            VkLogger.info(f'{VkLogger.gTIME} New post {post_id}')

            try:set_new_information_in_description(user, None)
            except vk_api.exceptions.ApiError as err:
                vlogger.error([vk_api.exceptions.ApiError, err, 'set_new_information_in_description'])
                print('Failed to call set_new_information_in_description function by error: %s' % err)
            except Exception as err:
                vlogger.error(['UNKNOWN', err, 'set_new_information_in_description'])
                print('Failed to call set_new_information_in_description function by error: %s' % err)

            try:set_new_information_on_the_wall(user)
            except vk_api.exceptions.ApiError as err:
                vlogger.error([vk_api.exceptions.ApiError, err, 'set_new_information_on_the_wall'])
                print('Failed to call set_new_information_on_the_wall function by error: %s' % err)
            except Exception as err:
                vlogger.error(['UNKNOWN', err, 'set_new_repost_wall'])
                print('Failed to call set_new_information_on_the_wall function by error: %s' % err)

            try:set_new_repost_wall(user,post_id)
            except vk_api.exceptions.ApiError as err:
                vlogger.error([vk_api.exceptions.ApiError, err, 'set_new_repost_wall'])
                print('Failed to call set_new_repost_wall function by error: %s' % err)
            except Exception as err:
                vlogger.error(['UNKNOWN', err, 'set_new_repost_wall'])
                print('Failed to call set_new_repost_wall function by error: %s' % err)

            print(f'[+][{time.strftime("%m.%d.%Y, %H:%M:%S", time.localtime())}] Making the post >>> {post_id}')

            with alive_bar(time_) as bar:
                for _ in range(0, time_):
                    if _ in offset:
                        # print(f'Метка офсета - {_}')
                        set_new_information_in_description(user, prints_in_console())
                        set_new_information_on_the_wall(user)
                    time.sleep(1)
                    bar()
        except vk_api.exceptions.ApiError as e:
            print(f'{"-"*4}')
            vlogger.error([vk_api.exceptions.ApiError, e, 'in Main While True'])
            print(f'[Error][vk_api.exceptions.ApiError]: {e}')
            # break
            # print(f'{"-"*4}')



def out_working_function():
    ch = None
    time.sleep(4)
    print('\n')
    while ch == None:
        try:
            ass = int(input(f'{"-"*10}\nВыберите нужный параметр >>> '))
            if ass == 1:
                one()
            elif ass == 2:
                two()
            elif ass == 3:
                three()
            elif ass == 999:
                break
            else:
                pass
        except KeyboardInterrupt:pass
        except Exception:pass
    print(f'''
{"-"*10}
Консоль была выключена.
{"-"*10}''')





if __name__ == '__main__':
        ver = Version(ProjectVersion)
        ver.ValidateVersion()
        user = User()
        
        vlogger = VkLogger(user)
        vlogger.send('-'*80)
        vlogger.config('VkLogger module has been successfully loaded.')
        vlogger.config('User module has been successfully loaded.')
        # # vlogger.send('[TEST]')
        # vlogger.send('[TEST-SEND]')
        # vlogger.config('[TEST-CONFIG]')
        # vlogger.info('[TEST-INFO]')
        # vlogger.error([SystemError, 'SYSTEMINTERNALERROR', 'SYSTEM'])
        # user.secure_sendSMSNotification()
        # user.notifications_get()
        # account_getProfileInfo_id, account_getProfileInfo_first_name, account_getProfileInfo_last_name, account_getProfileInfo_status, account_getProfileInfo_verification_status = user.account_getProfileInfo()
    # main_working_function(user)
    # try:
        # user.account_getAppPermissions(435600030) # 675190047-335876 435600030-1040183263
        #
        # user.send_message('643')
        # user.set_status('UwU')
        # user.groups_getOnTheWall()
        # der_lofng_start(user.vk, user)
        # Thread(target=der_lofng_start, args=(user.vk, user)).start()

        # set_new_information_on_the_wall(user)

        longpoll_start(user.vk, user)
        vlogger.info(f'Started longpolling User {user.user_id}')
        Thread(target=main_working_function, args=(user, 'IN_CODE_STARTING')).start()

        # der_lofng_start(user.vk, user)


        # Thread(target=der_lofng_start, args=user).start()
        # print(user.vk)
        # der_lofng_start(user.vk, user)



    # except Exception as e:
    #   set_new_information_in_description(user, 'Status: ERROR')
    #   raise
    # set_new_information_in_description(user)
    # print(address, name)
    # print(description)



# "malayski51@gmail.com"
# "89252054020Bandit5000"