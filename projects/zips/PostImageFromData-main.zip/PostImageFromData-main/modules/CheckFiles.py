from modules.functions import *
from modules.Classes import Colors
C = Colors()
green = C.green
white = C.white
red = C.red
ind_ = 60
ind_2 = 34

def sep_(text):
    return (ind_ - len(text))*" "
def sep2_(text):
    return (ind_2 - len(text))*" "

def check_metods(user):
    print(f'┌{"―"*39}>') 
    print( '┊                                 STATUS')
    text = '├> make_post'
    try:
        
        post_id = user.make_post('', 'DEBUG')['post_id']
        user.delete_post(post_id)
        print(f'{text}{sep2_(text)}{green}[OK]{white}')
    except vk_api.exceptions.ApiError as error:
        post_id = '0'
        error = except_errors(error, msg = None, metod = 2)
        text = f'{text}{sep2_(text)}{red}[ERROR]{white}'
        print(f'{text}{sep_(text)}{error}')
        
        
    text = '├> account_getProfileInfo'
    try:
        user.account_getProfileInfo()
        print(f'{text}{sep2_(text)}{green}[OK]{white}')
    except vk_api.exceptions.ApiError as error:
        error = except_errors(error, msg = None, metod = 2)
        text = f'{text}{sep2_(text)}{red}[ERROR]{white}'
        print(f'{text}{sep_(text)}{error}')
        
    text = '├> groups_getById'
    try:
        user.groups_getById(user.group_id)
        print(f'{text}{sep2_(text)}{green}[OK]{white}')
    except vk_api.exceptions.ApiError as error:
        error = except_errors(error, msg = None, metod = 2)
        text = f'{text}{sep2_(text)}{red}[ERROR]{white}'
        print(f'{text}{sep_(text)}{error}')
        

    
    text = '├> groups_getOnTheWall'
    try:
        user.groups_getOnTheWall()
        print(f'{text}{sep2_(text)}{green}[OK]{white}')
    except vk_api.exceptions.ApiError as error:
        error = except_errors(error, msg = None, metod = 2)
        text = f'{text}{sep2_(text)}{red}[ERROR]{white}'
        print(f'{text}{sep_(text)}{error}')
        
    text = '├> groups_getOnTheWallCustom'
    try:
        user.groups_getOnTheWallCustom(1, user.checkGuildId)
        print(f'{text}{sep2_(text)}{green}[OK]{white}')
    except vk_api.exceptions.ApiError as error:
        error = except_errors(error, msg = None, metod = 2)
        text = f'{text}{sep2_(text)}{red}[ERROR]{white}'
        print(f'{text}{sep_(text)}{error}')

    text = '├> groups_getSettings'
    try:
        address, name, description, group_id = user.groups_getSettings(user.group_id)
        print(f'{text}{sep2_(text)}{green}[OK]{white}')
    except vk_api.exceptions.ApiError as error:
        error = except_errors(error, msg = None, metod = 2)
        address, name, description, group_id = 0, 'ERROR', 'ERROR', -2
        text = f'{text}{sep2_(text)}{red}[ERROR]{white}'
        print(f'{text}{sep_(text)}{error}')
        

    text = '├> set_status'
    try:
        stst = user.get_status()
        user.set_status(stst)
        print(f'{text}{sep2_(text)}{green}[OK]{white}')
    except vk_api.exceptions.ApiError as error:
        error = except_errors(error, msg = None, metod = 2)
        text = f'{text}{sep2_(text)}{red}[ERROR]{white}'
        print(f'{text}{sep_(text)}{error}') 
        
        
    text = '├> groups_setDescription'
    try:
        user.groups_setDescription(user.group_id, description)
        print(f'{text}{sep2_(text)}{green}[OK]{white}')
    except vk_api.exceptions.ApiError as error:
        error = except_errors(error, msg = None, metod = 2)
        text = f'{text}{sep2_(text)}{red}[ERROR]{white}'
        print(f'{text}{sep_(text)}{error}')



        

    text = '├> repost_wall'
    try:
        user.repost_wall(1)
        print(f'{text}{sep2_(text)}{green}[OK]{white}')
    except vk_api.exceptions.ApiError as error:
        error = except_errors(error, msg = None, metod = 2)
        text = f'{text}{sep2_(text)}{red}[ERROR]{white}'
        print(f'{text}{sep_(text)}{error}')
    
    text = '├> send_message - beseda'
    try:
        id_, chat_id = user.send_message('DEBUG', 'beseda')
        user.delete_message(id_, chat_id)
        print(f'{text}{sep2_(text)}{green}[OK]{white}')
    except vk_api.exceptions.ApiError as error:
        error = except_errors(error, msg = None, metod = 2)
        text = f'{text}{sep2_(text)}{red}[ERROR]{white}'
        print(f'{text}{sep_(text)}{error}')
 
    text = '├> send_message - logs'
    try:
        id_, chat_id = user.send_message('DEBUG', 'logs')
        # print(id_, chat_id)
        user.delete_message(id_, chat_id)
        print(f'{text}{sep2_(text)}{green}[OK]{white}')
    except vk_api.exceptions.ApiError as error:
        error = except_errors(error, msg = None, metod = 2)
        text = f'{text}{sep2_(text)}{red}[ERROR]{white}'
        print(f'{text}{sep_(text)}{error}')   
    
    
    print(f'└{"―"*39}>') 