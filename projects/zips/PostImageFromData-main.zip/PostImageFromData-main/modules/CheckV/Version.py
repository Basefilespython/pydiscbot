# def Fing
#     py_logger.warning(f"An obsolete version of the script has been found (NEW-{nversion_}, OLD-{sversion_})!")
#     print(f"""{yellow}[*] {name_d_}{white}""")
#     print(f"{violet}[*] An old version: {sversion_}, A new version: {nversion_}")
#     ch = input(f"{green}[!] {loc['10']} (Y/N) >>> ")
#     print(white)
#     if ch == "Y":
#       check(0, name_file_,redir_)
#       val = True
#       raise ForcedRebootException(loc["19"])
#     else:
#       pass
import json
import requests
from modules.Classes import Colors, ScriptUpdater
from modules.if_pictures_ravno_zero_naxyi import GitHubDownload

class Version():
    def __init__(self, programINST_version):
        self.version = programINST_version
        self.Aversion, self.ErrorMSG = self.getActiveVersion()
        
    def getActiveVersion(self):
        try:
            url = 'https://raw.githubusercontent.com/Basefilespython/pydiscbot/main/projects/download_and_crop/ver/version_PostImageFromData.json'
            Aversion = requests.get(url).text
            # print(Aversion)
            Aversion = json.loads(Aversion)["ver"]
            Error = 'None'
        except Exception as Error:
            print('Failed to get active version from %s: %s' % (url, Error))
            Aversion = 'None'
        return Aversion, Error
    
    def FindOLDestVersion(self):
        print(f'Find current version from {self.version}')
        print(f'Available version {self.Aversion}')
        ch = input(f"{Colors.green}[!] Скачать актуальную версию? (Y/N) >>> ")
        print(Colors.white)
        if ch == "Y":
            GitHubDownload()
            raise ScriptUpdater('Перезагрузите скрипт!')
        else:
            pass
    
    def FindActuallVersion(self):
        print(f'Find available and current version: {self.Aversion}')
    
    def ErrorValidateVersion(self, error):
        print(f'Version check failed: {error}')
    
    def ValidateVersion(self):
        sversion = self.version
        nversion = self.Aversion
        if nversion != 'None':
            s1, s2, s3, n1, n2, n3 = (
            str(sversion).split(".")[0],
            str(sversion).split(".")[1],
            str(sversion).split(".")[2],
            str(nversion).split(".")[0],
            str(nversion).split(".")[1],
            str(nversion).split(".")[2])
            if s1 >= n1:
                if s2 >= n2:
                    if s3 >= n3:
                        self.FindActuallVersion()
                    else:self.FindOLDestVersion()
                else:self.FindOLDestVersion()
            else:self.FindOLDestVersion()
        else:
            
            lens_simvolov = len(list(f'[*] Working Version: {sversion}'))
            print(f"""[*] Working Version: {sversion}{' '*(38-lens_simvolov)}[!] Cause: {self.ErrorMSG}""")