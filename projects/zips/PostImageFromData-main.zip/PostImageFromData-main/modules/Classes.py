import time


class NotPostingImages(Exception):
    pass
class ScriptUpdater(Exception):
    pass

class VkLogger():
    def __init__(self, User):
        from modules.functions import send_message as __send_message
        self.send_message = __send_message
        
        self.user = User
        
    def gTIME(self): 
        return str(time.strftime("[%H:%M:%S %d %b %Y]", time.localtime()))
    
    def send(self, message):
        self.send_message(self.user, f"💠 {message}", 'logs')
        
    def config(self, message):
        self.send_message(self.user, f"📕 {message}", 'logs')
        
    def info(self, message):
        self.send_message(self.user, f"❕ {message}", 'logs')
        
    def error(self, error):
        if "<class '" in str(error[0]):
            error[0] = str(error[0]).replace("<class '",'').replace("'>","")
        
        self.send_message(self.user, f'''{"♦"*10}
🚨 Ошибка!
🎲 Тип ошибки: {error[0]}
📜 Сообщение: 
{error[1]}
📌 Функция: {error[2]}''', 'logs')
        

class Colors():
    try:
        from colorama import Fore, Style
        black = Fore.BLACK
        red = Fore.RED
        green = Fore.GREEN
        yellow = Fore.YELLOW
        blue = Fore.BLUE
        cyan = Fore.CYAN
        white = Fore.WHITE
        st = Style.RESET_ALL
    except:
        black = "\033[30m"
        red = "\033[31m"
        green = "\033[32m"
        yellow = "\033[33m"
        blue = "\033[34m"
        cyan = violet = "\033[35m"
        white = "\033[37m"
        st = "\033[37"
