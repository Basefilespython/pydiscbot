import unicodedata
import urllib.request
from PIL import Image
import random
import sqlite3
import json
import requests
import vk_api
import os


if str(os.name) == "nt":dir_pref = "\\"
else:dir_pref = "/"


def captcha_handler(captcha):
    key = input("Enter captcha code {0}: ".format(captcha.get_url())).strip()
    return captcha.try_again(key)

def auth_handler():
    key = input("Enter authentication code: ")
    remember_device = True
    return key, remember_device



class SUser:
    def __init__(self, file=rf'modules{dir_pref}config.json'):
        with open(file) as f:data = json.load(f)
        self.servise_auth_token= data['service']
        self.vk_servise_auth = vk_api.VkApi(token = self.servise_auth_token)
        
        
        
        
class User:
    """
        docstring forUser.

        Чтение конфигурации из файла
    """

    def __init__(self, file=rf'modules{dir_pref}config.json'):
        with open(file) as f:
            data = json.load(f)

        self.user_id = data['user_id']
        self.group_id = data['group_id']
        self.donors = data['donors']
        
        self.defaultChatId = data['chats']['defaultChatId']
        self.LogsChatId = data['chats']['LogsChatId']
        
        self.add_friends = data['add_friends']
        self.del_requests = data['del_requests']
        self.repost = data['repost']
        self.watermark = data['watermark']
        self.watermark_img = data['watermark_img']
        self.time_to_start_script = data['time_to_start_script']
        self.time_sleep = int(data['time_sleep'])
        self.sqlog = data['sqlog']
        self.admin_post = data['wall_admin_post_id']
        self.auth_data = data['auth_data']
        self.token = self.auth_data['tokens']['token']
        self.servise_auth_token= self.auth_data['tokens']['VKMiniAppsMytoken']
        self.login = self.auth_data['login']
        self.passwd= self.auth_data['password']
        if data['auth_token'] == 1:
            self.vk = vk_api.VkApi(token = self.token) # user + messages
        else:
            self.vk = vk_api.VkApi(
                                    self.login, self.passwd,
                                    captcha_handler=captcha_handler,
                                    auth_handler = auth_handler,
                                    app_id=2685278) #all - 6287487, my - 2685278
            self.vk.auth()
        self.vk_servise_auth = vk_api.VkApi(token = self.servise_auth_token)
        self.checkGuildId = data['dataCheck']['checkguildId']
        self.v = data['v']
        
        if not os.path.exists(f'modules{dir_pref}jsons{dir_pref}'):os.mkdir(f'modules{dir_pref}jsons{dir_pref}')

    """
        Добавить в друзья все заявки
    """

    def add_all_to_friends(self):
        for request_to_friends in self.vk.method('friends.getRequests', {'out': 0, 'v': self.v})['items']:
            try:
                self.vk.method('friends.add', {
                               'user_id': request_to_friends, 'v': self.v})
            except:
                pass

    """
        Отписаться от всех заявок
    """

    def friends_deny_request(self):
        for request_to_friends in self.vk.method('friends.getRequests', {'out': 1, 'v': self.v})['items']:
            try:
                self.vk.method('friends.delete', {
                               'user_id': request_to_friends, 'v': self.v})
            except:
                pass

    """
        Загрузка изображения на сервер и получение объекта photo
    """

    def picture_send(self, image_to_send, working_directory):
        do = os.getcwd()
        os.chdir(working_directory)
        a = self.vk.method('photos.getWallUploadServer', {'v': self.v})
        b = requests.post(a['upload_url'], files={
                          'photo': open(image_to_send, 'rb')}).json()
        c = self.vk.method('photos.saveWallPhoto', {
            'photo': b['photo'], 'server': b['server'], 'hash': b['hash'], 'v': self.v})[0]
        d = f'photo{c["owner_id"]}_{c["id"]}'
        os.chdir(do)
        return d

    """
        Репост последнего поста из группы
        (если есть закреп - то предпоследнего)
    """

    def repost_last_post(self):
        post = self.vk.method(
            'wall.get', {'owner_id': -self.group_id, 'count': 1, 'filter': 'owner', 'v': self.v})['items'][0]
        if 'is_pinned' in post:
            post = self.vk.method('wall.get', {
                                  'owner_id': -self.group_id, 'offset': 1, 'count': 1, 'filter': 'owner', 'v': self.v})['items'][0]
        owner_id = post['owner_id']
        post_id = post['id']
        self.vk.method('wall.repost', {
                       'object': f'wall{owner_id}_{post_id}', 'v': self.v})
        return post_id

    """
        Проверка наличия идентификатора поста в базе данных
    """

    def check_in_db(self, id):
        conn = sqlite3.connect("posts.db")
        cursor = conn.cursor()
        try:
            cursor.execute('CREATE TABLE posts (id text)')
        except:
            pass
        sql = "SELECT * FROM posts WHERE id=?"
        cursor.execute(sql, [(id)])
        res = cursor.fetchall()
        if res:
            return 1
        else:
            return 0

    """
        Добавление идентификатора поста в базу данных
    """

    def add_in_db(self, id):
        conn = sqlite3.connect("posts.db")
        cursor = conn.cursor()
        try:
            cursor.execute("""CREATE TABLE posts (id text)""")
        except:
            pass
        cursor.execute("""INSERT INTO posts (id) VALUES (?)""", (id,))
        conn.commit()
        return 0

    """
        Добавление водяного знака
    """

    def add_watermark(self, img):
        picture = Image.open(img)
        watermark = Image.open(self.watermark_img).convert("RGBA")
        width, height = watermark.size
        picture.paste(watermark, (0, 0, width, height),  watermark)
        picture.save(img)

    """
        Получает случайный пост со стены группы из списка
    """

    def get_random_post(self):
        while True:
            donor_id = random.choice(self.donors)
            count = self.vk.method(
                'wall.get', {'owner_id': donor_id, 'v': self.v})['count']
            post = self.vk.method('wall.get', {'owner_id': donor_id, 'offset': random.randint(
                2, count - 1), 'count': 1, 'filter': 'owner', 'v': self.v})['items'][0]
            donor_post_id = post['id']
            text = post['text'].lower()
            if any(word in text for word in self.stop_words):
                continue
            if post['marked_as_ads']:
                continue
            if self.sqlog:
                if self.check_in_db(f'{donor_id}_{donor_post_id}'):
                    continue
            attachments = ''
            for attachment in post['attachments']:
                if attachment['type'] == 'photo':
                    photo = attachment['photo']
                    url = photo['sizes'][-1]['url']
                    file = url.split('/')[-1]
                    urllib.request.urlretrieve(url, file)
                    if self.watermark:
                        self.add_watermark(file)
                    attachments += self.picture_send(file) + ','
                    os.remove(file)
                if attachment['type'] == 'audio':
                    audio = attachment['audio']
                    attachments += f'audio{audio["owner_id"]}_{audio["id"]},'
                if attachment['type'] == 'audio_playlist':
                    audio_playlist = attachment['audio_playlist']
                    attachments += f'audio_playlist{audio_playlist["owner_id"]}_{audio_playlist["id"]},'
                if attachment['type'] == 'video':
                    video = attachment['video']
                    attachments += f'video{video["owner_id"]}_{video["id"]},'
                if attachment['type'] == 'doc':
                    doc = attachment['doc']
                    attachments += f'doc{doc["owner_id"]}_{doc["id"]},'
            if not attachments:
                continue
            break
        return {'donor_id': donor_id, 'donor_post_id': donor_post_id, 'attachments': attachments, 'text': text}

    """
        Пост в группу
    """

    def make_post(self, attachments, text):
        # if text == 'None':
        #     self.post_text = 'DEBUG'
        # else: self.post_text = ''#str(random.choice(["Тут должен быть текст, но его забыли сюда вставить.", "" ]))
        if text == '':text = None
        print(f'text->{text}')
        self.vk.method('account.setOnline', {'v': self.v})
        id_ = self.vk.method('wall.post', {
                                           'owner_id': -self.group_id,
                                           'message': text, #+ f'\n\n\nИсточник: @club{abs(donor_id)}({donor})',
                                            'attachments': attachments,
                                            'from_group': 1,
                                            'signed': 0,
                                            'v': self.v})
        # id_ = {'post_id': 28}
        try:
            ab = self.vk.method('wall.getById', {
                'posts' : f'-{self.group_id}_{id_["post_id"]}',
                'fields': 'post_type',
                'v': self.v})[0]['post_type']
        except:ab = 'error'
        # oss_ = os.getcwd()
        # os.chdir(f'modules{dir_pref}jsons{dir_pref}')
        # with open(f'make_post_{id_["post_id"]}.json', "w") as outfile:json.dump(ab, outfile, indent=4)
        # os.chdir(oss_)
        
        if ab == 'suggest' and text != 'DEBUG':
            print(f'''
┌{"―"*55}┐
┊ Запись с ID: {id_['post_id']} была отправлена в предложенные записи ┊
└{"―"*55}┘
''')
        elif ab == 'error':
            pass
#             print(f'''
# ┌{"―"*65}┐
# ┊ Запись с ID: {id_['post_id']} была создана, но проверка типа записи не удалась ┊
# └{"―"*65}┘
# ''')
        return id_

    def delete_post(self, post_id):
        self.vk.method('account.setOnline', {'v': self.v})
        status = self.vk.method('wall.delete', {
                                           'owner_id': -self.group_id,
                                           'post_id' : post_id,
                                            'v': self.v
                                            })
        return status

    def groups_getSettings(self, group_id):
        group_id = self.group_id
        groups_Settings = self.vk.method('groups.getSettings', {'group_id': group_id,'v': self.v})
        groups_Settings['description'] = str(groups_Settings['description']).encode('unicode-escape').decode('unicode-escape')
        description = str(groups_Settings['description']).encode('unicode-escape').decode('unicode-escape')
        name = str(groups_Settings['title']).encode('unicode-escape').decode('unicode-escape')
        address = groups_Settings['address']
        return address, name, description, group_id
    
    def groups_getById(self, group_id):
        # r_can_post = self.vk.method('groups.getById', {'group_id': group_id, 'fields' : 'can_post','v': self.v})
        r = self.vk.method('groups.getById', {'group_id': group_id,'fields' : 'description','v': self.v})
                                            #   'fields' : 'can_post','fields' : 'description','v': self.v})

        can_post = self.vk.method('groups.getById', {'group_id': group_id,'fields' : 'can_post','v': self.v})[0]['can_post']
        verified = self.vk.method('groups.getById', {'group_id': group_id,'fields' : 'verified','v': self.v})[0]['verified']
        # print(can_post, verified)
        r[0]['can_post'] = can_post
        r[0]['verified'] = verified
        oss_ = os.getcwd()
        os.chdir(f'modules{dir_pref}jsons{dir_pref}')
        with open("groups_getById.json", "w") as outfile:json.dump(r, outfile, indent=4)
        os.chdir(oss_)
        return r#, r_can_post
    

    def groups_getOnTheWallCustom(self, post_id, group_id = None):
        if group_id is None:
            group_id = self.group_id
        # print(f'-{group_id}_{post_id}')
        post_ = self.vk.method('wall.getById', {'posts': f'-{group_id}_{post_id}','v': self.v})[0]
        return post_



    def groups_getOnTheWall(self):
        try:
            post_ = self.vk.method('wall.getById', {'posts': f'-{self.group_id}_{self.admin_post}','v': self.v})[0]
            post_['text'] = str(post_['text']).encode('unicode-escape').decode('unicode-escape')
            oss_ = os.getcwd()
            os.chdir(f'modules{dir_pref}jsons{dir_pref}')
            with open("groups_getOnTheWall.json", "w") as outfile:json.dump(post_, outfile, indent=4)
            os.chdir(oss_)
            return post_['text']
        except vk_api.exceptions.ApiError as error:
            if 'Unknown method passed' in str(error):
                print(f'[!!!] Обнаружена проблема с токеном! Немедленно замените его!')
            return ''





    def groups_setDescription(self, group_id, description):
        self.vk.method('groups.edit', {'group_id': group_id,'v': self.v, 'description': description})
        # print(groups_Settings)

    def account_getAppPermissions(self, user_id):

        ass_ = self.vk.method('account.getAppPermissions', {'user_id': user_id,'v': self.v})
        print(ass_)

    def send_message(self, message, type_ch, attachment = None):
        # baseda = 136
        # logs__ = 135
        if type_ch == 'beseda':
            chat_id = int(f'2000000{self.defaultChatId}')
        else:
            if type_ch == 'logs':
                chat_id = int(f'2000000{self.LogsChatId}')
        # chat_id = self.vk.method("messages.searchConversations", {"q": 'База Неко | Логи', "count": 1})['items'][0]['peer']['id']
        # chat_id = self.vk.messages.searchConversations(q='База Неко | Логи', count=1)['items'][0]['peer']['local_id']
        # print(chat_id)
        if attachment != None:
            id_ = self.vk.method("messages.send", {"peer_id": chat_id, "message": message, "attachment": attachment, "random_id": 0})
        else:
            # self.vk.method("messages.send", {"peer_id": id, "message": message, "random_id": 0})
            id_ = self.vk.method("messages.send", {"peer_id": chat_id, "message": message, "random_id": random.randint(-3254672,32546547)})
            # print(id_)
        return id_, chat_id
    
    
    def delete_message(self, id_, chat_id):
        self.vk.method("messages.delete", {"peer_id": chat_id, 'message_ids': id_})

    def ping(self):
        q = self.vk.method('account.getProfileInfo', {'v': self.v})
        return q
    
    def get_status(self):
        return self.vk.method("status.get", {'group_id': self.group_id})['text']


    def set_status(self, status):
        self.vk.method("status.set", {"text": status, 'group_id': self.group_id})

    def groups_set_on_the_wall(self, info):
        self.vk.method('wall.edit', {'owner_id': f'-{self.group_id}',
                                     'post_id': self.admin_post,
                                     'v': self.v,
                                     'message': info,
                                     'friends_only': 0,
                                     'attachments': []})

    def repost_wall(self, post_id):
        self.send_message('Вышел новый арт в группе!', 'beseda', f'wall-{self.group_id}_{post_id}')

    def account_getProfileInfo(self):
        q = self.vk.method('account.getProfileInfo', {'v': self.v})
        oss_ = os.getcwd()
        if not os.path.exists(f'modules{dir_pref}jsons{dir_pref}'):os.mkdir(f'modules{dir_pref}jsons{dir_pref}')
        os.chdir(f'modules{dir_pref}jsons{dir_pref}')
        with open("account_getProfileInfo.json", "w") as outfile:json.dump(q, outfile, indent=4)
        os.chdir(oss_)
        if q['verification_status'] == 'verified': q['verification_status'] = "✅ (verified)"
        else:q['verification_status'] = "❌ (not verified)"
        return [q['id'], q['first_name'], q['last_name'], q['screen_name'], q['status'], q['verification_status']]
        print(q)

    def notifications_get(self):
        q = self.vk.method('notifications.get', {'v': self.v,
                                                 'count': 2})
        oss_ = os.getcwd()
        os.chdir(f'modules{dir_pref}jsons{dir_pref}')
        with open(f"notifications_get.json", "w") as outfile:json.dump(q, outfile, indent=4)
        os.chdir(oss_)
        print(q)
        pass


    def notifications_sendMessage(self):
        q = self.vk_servise_auth.method('notifications.sendMessage',
                                                 {'v': self.v,
                                                  'user_ids': 435600030,
                                                 'message': 'Типо тестовое сооющение в уведомлениях',
                                                 'group_id': 223280125,
                                                 'fragment': 'vk.com/app123456#LOL'})
        print(q)

    def secure_checkToken(self):
        q = self.vk_servise_auth.method('secure.checkToken',
                                                 {'v': self.v,
                                                  'token': self.servise_auth_token})
        print(q)

    def secure_sendSMSNotification(self):
        q = self.vk_servise_auth.method('secure.sendSMSNotification',
                                                 {'v': self.v,
                                                  'user_id': 435600030,
                                                  'message': 'This message has been sent successfully to the server and will be sent to the server again in the next 24 hours.'})
        print(q)
