class NotPostingImages(Exception):
    pass
