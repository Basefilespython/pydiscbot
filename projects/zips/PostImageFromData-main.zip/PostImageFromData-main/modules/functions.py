import os
import time
from modules.Classes import NotPostingImages
from modules.Classes import Colors
import random
import requests
import json
import vk_api

username = 'BSNIKChannel'
tn = '9b4dacfb605d41ea0e1b99a952fc4e95e330814c'

if str(os.name) == "nt":dir_pref = "\\"
else:dir_pref = "/"

image_exctensions = ['jpeg','jpg','png','gif','tiff']

def information_about_cpu():
    r = requests.get(f'https://www.pythonanywhere.com//api/v0/user/BSNIKChannel/cpu/',headers={'Authorization': f'Token {tn}'}).text
    t = json.loads(r)

    return f'''Общее использование процессора в день (секунды): {round(t["daily_cpu_total_usage_seconds"], 1)}/{t["daily_cpu_limit_seconds"]}
Следующий сброс: {t['next_reset_time'].replace('T',' ')}'''

def prints_in_console():
    a = ''
    st_or_id = get_console()
    if st_or_id != 'Скрипт запущен локально':
        r = requests.get(f'https://www.pythonanywhere.com//api/v0/user/{username}/consoles/{int(get_console())}/get_latest_output/',headers={'Authorization': f'Token {tn}'}).text
        r =json.loads(r)


        if str(r.get('output')) != '''\r\nPreparing execution environment... OK\r\nSpam, spam, spam, sausage, eggs, spam and spam... OK\r\nLoading Bash interpreter...\u001b[;H\u001b[2J\u001b[0;37m22:03 ~\u001b[0;33m \u001b[1;32m$ \u001b[0;37m\r\u001b[K\u001b[0;37m22:03 ~\u001b[0;33m \u001b[1;32m$ \u001b[0;37m''':
            if '|' in r:
                if 'Время последнего обновления' not in r:
                    if '' != r:
                        a = '|' + str(list(r.split('\r'))[-1]).split('|')[-2] + '|' + str(list(r.split('\r'))[-1]).split('|')[-1].replace(' "}', '')
                    else:a = 'Консоль в режиме ожидания.'
                else:pass
        elif r.get('error') is not None:
            a = 'Консоль ещё не была создана'
        else:a = r
        return a
    return st_or_id

def get_console():
    r = requests.get(f'https://www.pythonanywhere.com//api/v0/user/{username}/consoles/',headers={'Authorization': f'Token {tn}'}).text
    # print(r)
    if r != '[]':
        return json.loads(r)[0]['id']
    return 'Скрипт запущен локально'

def get_offset_for_script(sep, length):
    q = 100/sep
    x = q * length / 100
    a = [int(i*x) for i in range(1,sep+1)]
    return a


def except_errors(error, msg = None, metod = 1):

        code = str(error).split(']')[0].replace('[','')
        inf = (str(error).replace(f'[{code}] ', '')).split(':')[0]
        if 'user revoke access for this token.' in str(error):
            status = 'Пользователь отменил доступ к этому токену.'
        
        elif 'Incorrect token' in str(error):
            status = 'Токен не корректен.'
        
        elif 'invalid access_token' in str(error):
            status = 'Токен был записан не правильно'
            
        
        elif 'no access_token passed.' in str(error):
            status = 'Токен не был передан, введите его в config.json'
        
        elif ' could not access to this community' in str(error):
            status = 'Не хватет прав'
        
        elif 'access_token was given to another ip address' in str(error):
            status = 'Токен был создан для другого IP, замените токен'
        
        elif 'invalid message param' in str(error):
            status = 'Параметр message вызвал ошибку'
        
        elif 'Unknown method passed' in str(error):
            status = 'Метод не был найден. (Обнаружена проблема с токеном! Немедленно замените его!)'
        
        elif 'only for vk apps' in str(error):
            status = 'Только для Vk apps'
        
        elif 'access to the wall is closed' in str(error):
            status = 'Доступ к этой стене вам закрыт'
        
        elif 'only group admin could access this method' in str(error):
            status = 'Вы не администратор этой группы'
        
        elif " You don't have access to this chat" in str(error):
            status = "Вы не имеете доступа к этому чату"
        
        elif 'can not notify this user' in str(error):
            status = 'Не могу уведомить этого пользователя'
        
        elif 'you should be a group administrator' in str(error):
            status = 'Вы не администратор этой группы'

        elif 'share post forbidden' in str(error):
           status = 'Невозможно зарепостить пост, который ещё не вышел.'

        elif 'edit time expired' in str(error):
           status = 'Время редактирования истекло.'
        
        elif 'Permission to perform this action is denied' in str(error):
            status = 'Указанная беседа не была найдена у пользователя'

        elif 'post or comment deleted' in str(error):
            status = 'Нужный пост не был найден.'
        
        elif 'Application is not installed in community' in str(error):
            status = 'Приложение не установлено в сообществе'
        
        else:
            try:status = (str(error).replace(f'[{code}] ', '')).split(': ')[1]
            except IndexError:status = (str(error).replace(f'[{code}] ', ''))

        if metod == 2:
            return status

        indentation = 55
        con  = round(indentation-round(len([i for i in msg]))) - 1
        con_ = round((indentation + 5)-round(len([i for i in status]))) - 1
        code_= round((indentation + 0)-round(len([i for i in f'{code} ({inf})']))) - 1
        print(f'''┌{"―"*(indentation+5)}┐
┊ Тип: {msg}{con*' '}┊
┊ Код: {code} ({inf}){code_*' '}┊
┊ {status}{con_*' '}┊        
└{"―"*(indentation+5)}┘''')




def send_message(user, message, type_, attachment = None):
    try:
        user.send_message(message, type_, attachment)
    except vk_api.exceptions.ApiError as error:
        if type_ != 'logs': 
            except_errors(error, 'Отправить сообщение в беседу')


def set_online(user):
    user.vk.method('account.setOnline', {'v': user.v})


def valiadate_token(user):
    try:
        user.ping()
        return True
    except vk_api.exceptions.ApiError as error:
        except_errors(error, 'Проверка токена')
        return False





def get_info_about_guild(user, guild_id):
    data = user.groups_getById(guild_id)[0]
    # print(data)
    name = data['name']
    description = data['description']
    adress = data['screen_name']
    if data['verified']:
        name = name + '✅'
    return name, description, adress, guild_id


def get_info_about_user_in_guild(user, guild_id):
    data = user.groups_getById(guild_id)[0]
    # print('get_info_about_user_in_guild',data)
    is_closed, type_ = data['is_closed'], data['type']
    
    try:
        is_admin = data['is_admin']
        is_member=data['is_member']
        is_advertiser = data['is_advertiser']
    except KeyError:
        is_admin = is_member = is_advertiser = f'{Colors.red}ACCESS DENIED [groups]{Colors.white}'# groups
    
    # try:
    #    is_member = data['is_member']
    # except KeyError:
    #     is_member = f'{Colors.red}Нет прав [groups]{Colors.white}'# groups
        
    # print(data.get('deactivated'), r_can_post)
    
    if data.get('deactivated') is None:
        banned_ =  ''
        if is_member != f'{Colors.red}ACCESS DENIED [groups]{Colors.white}':
            can_post = (f'{Colors.green}Может{Colors.white}' if data['can_post'] == 1 else f'{Colors.red}Не может{Colors.white}')
        else:can_post = f'{Colors.red}ACCESS DENIED [groups]{Colors.white}'
            
    else:
        banned_message = str(data["deactivated_message"]).split("\n\n")[0]
        banned_ = f'''{Colors.red}Заблокировано по причине: {banned_message}{Colors.white}'''
        can_post = f'{Colors.red}Не может{Colors.white}'
    
    
    # is_closed = ('Открыта' if not is_closed else 'Закрыта')
    if is_closed == 0: is_closed = 'Открыта'
    elif is_closed == 1: is_closed = 'Закрыта'
    elif is_closed == 2: is_closed = 'Частная'
    
    if type_ == 'group':
        type_ = 'Группа'
    elif type_ == 'page':
        type_ = 'Страница'
    elif type_ == 'event':
        type_ = 'Мероприятие'
    type_ = ('Группа' if type_ == 'group' else f'{type_}')
    # is_member = ('Участник' if is_member else 'Не участник')
    if is_admin:
        
        if is_admin != f'{Colors.red}ACCESS DENIED [groups]{Colors.white}':
            admin_level = data['admin_level']
            if admin_level == 3:
                admin_level = 'Администратор'
            elif admin_level == 2:
                admin_level = 'Редактор'
            elif admin_level == 1:
                admin_level = 'Модератор'
            
            if is_advertiser == 1:
                admin_level = admin_level + ', Рекламодатель'
        else:
            admin_level = f'{Colors.red}ACCESS DENIED [groups]{Colors.white}'
    else:
        if is_member:
            admin_level = 'Участник'
        else:admin_level = 'Не Участник'
    # print('can_post', can_post)
    return is_closed, type_, admin_level, banned_, can_post


def set_new_information_in_description(user, s):
    data = user.groups_getById(user.group_id)[0]
    

    address, name, description, group_id = data['screen_name'], data['name'], data['description'], data['id']
    # print(address, name, description, group_id)
    # address, name, description, group_id = user.groups_getSettings(user.group_id)
    sep = "-"*15
    if f'{sep}' in str(description):
        description = list(description.split(sep))[0]
        if s == None:
            description_ = description + f'\n\n{sep}\n{information_about_cpu()}'
        else:description_ = description + f'\n\n{sep}\n{s}'
    else:
        if s == None:description_ = description + f'\n\n{sep}\n{information_about_cpu()}'
        else:description_ = description + f'\n\n{sep}\n{s}'
    description_ = description_ + f'\nВремя последнего обновления: {time.strftime("%m.%d.%Y, %H:%M:%S", time.localtime())}\n{prints_in_console()}'
    try:
        user.groups_setDescription(group_id, description_)
    except vk_api.exceptions.ApiError as error:
        except_errors(error, 'Изменить информацию в описании сообщества.')

def set_new_information_on_the_wall(user):
    try:
        text = user.groups_getOnTheWall()
    except vk_api.exceptions.ApiError as error:
        except_errors(error, 'Изменить информацию на стене, user.groups_getOnTheWall()')
        text = ''
        
    sep = "-"*15
    if f'{sep}' in str(text):
        text = list(text.split(sep))[0]
        text_ = text + f'\n\n{sep}\n{information_about_cpu()}'
    else:
        text_ = text + f'\n\n{sep}\n{information_about_cpu()}'
    text_ = text_ + f'''
{time.strftime("%m.%d.%Y, %H:%M:%S", time.localtime())}'''
 

    try:
        user.groups_set_on_the_wall(text_)
    except vk_api.exceptions.ApiError as error:
        except_errors(error, 'Изменить информацию на стене')


def make_post(user, photo, text):
    # try:
        return user.make_post(photo, text)['post_id']
    # except vk_api.exceptions.ApiError as error:
    #     except_errors(error, 'Сделать пост')
    #     return 0
        


def set_new_repost_wall(user, post_id):
    time.sleep(5)
    try:
        user.send_message('Вышел новый арт в группе!', 'beseda', f'wall-{user.group_id}_{post_id}')
    except vk_api.exceptions.ApiError as error:
        except_errors(error, 'Репост в беседу')

def picture_send(user, picture, pictures_folder_directory):
    try:
        return user.picture_send(picture, pictures_folder_directory)
    except vk_api.exceptions.ApiError as error:
        except_errors(error, 'Отправление изображения на сервера')
        return ''

def user_secure_sendSMSNotification(user):
    try:
        user.secure_sendSMSNotification()
    except vk_api.exceptions.ApiError as error:
        except_errors(error, 'Отправить SMS Notification')


def secure_checkToken(user):
    try:
        user.secure_checkToken()
    except vk_api.exceptions.ApiError as error:
        except_errors(error, 'Проверить токен')

def notifications_get(user):
    try:
        user.notifications_get()
    except vk_api.exceptions.ApiError as error:
        except_errors(error, 'Получить уведомления пользователя')

def notifications_sendMessage(user):
    try:
        user.notifications_sendMessage()
    except vk_api.exceptions.ApiError as error:
        except_errors(error, 'Отправить сообщение в уведомления')


def account_getAppPermissions(user, user_id = None):
    if user_id is None:
        user_id = user.user_id
        
    try:
        user.account_getAppPermissions(user_id)
    except vk_api.exceptions.ApiError as error:
        except_errors(error, 'Получить разрешения приложения для пользователя')





def remove_pictures():
    try:
        os.rmdir('pictures')
    except OSError:
        os.chdir(f'{os.getcwd()}{dir_pref}pictures')
        for entry in os.scandir(os.getcwd()):
            if entry.is_file():
                os.remove(entry.name)

def get_images_in_folder(w_directory):
    pictures = []
    for entry in os.scandir(w_directory):
        if entry.is_file():
            if str(entry.name).split('.')[-1] in image_exctensions:
                    pictures.append(entry.name)
    return pictures

def get_local_ip_address():
    r = requests.get(f'https://api.ipify.org?format=json')
    if r.status_code != 200: return f'ERROR ({r.status_code})'
    return (r.text).split('"')[3]


def check_files(working_dir):
    if os.path.exists(working_dir):
        pictures = []
        print('Нужная папка была найдена.')
        skan = os.scandir(working_dir)
        if len(list(skan)) != 0:
            pictures = get_images_in_folder(working_dir)
            # print(f'Количество найденных изображений: {len(pictures)}')
            # print(f'{"-"*5}')
            if len(pictures) != 0:return True
            else: return False
        else:
            return False
            # raise NotPostingImages('Нету изображений которые необходимо постить... ')
    else:
        os.mkdir(working_dir)
        print('Нужная папка НЕ была найдена.')
        return False

def get_random_image(working_directory):
    pictures = get_images_in_folder(working_directory)
    picture = random.choice(pictures)
    return picture

if __name__ == '__main__':
    print(f'-{prints_in_console()}-')