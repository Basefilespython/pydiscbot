# -*- coding: utf-8 -*-
import vk_api
import time
import requests
from vk_api.longpoll import VkLongPoll, VkEventType, VkChatEventType
from vk_api.exceptions import ApiError
from threading import Thread
import json

"""
Пример не работает с дефолтным app_id

Подробнее об ограничении доступа к сообщениям:
https://vk.com/dev/messages_api

Обсуждение:
https://github.com/python273/vk_api/issues/219
"""





def get_guild_name(vk_api, user, guild_id):
    guild_id = int(guild_id)
    # print(guild_id)
    try:
        d = vk_api.method('groups.getById', {'group_id': guild_id,'v': user.v})
        name = str(d[0]['name']).encode('unicode-escape').decode('unicode-escape')
        return name
    except Exception as e:
        return f'ERROR {e}'

def get_dialog_name(vk_api, user, dialog_id):
        name = vk_api.method('messages.getChat', {'chat_id': dialog_id,'v': user.v})['title']
        return name

def get_user_FLname(vk_api, user, user_id):
    user = vk_api.method("users.get", {"user_ids": user_id}) # вместо 1 подставляете айди нужного юзера
    if user == []:
        return get_guild_name(vk_api, user, user_id)
    if user == '[]':return f'ERROR: {user_id} not is a valid user'

    fullname = user[0]['first_name'] +  ' ' + user[0]['last_name']
    return fullname



def der_lofng_start(vk_api, user_):
    while True:
        try:
            lofng(vk_api, user_)
        except requests.exceptions.ConnectionError:pass
        except requests.exceptions.ReadTimeout:pass
        except ApiError as error:
            print(error)
            if '[15]' in str(error):
                print(f'''
┌{"―"*5} Error in LongPool: {"―"*5}
┊ Не хватает прав
└{"―"*10}''')
                raise SystemExit
            else:pass
        # except Exception as err:
        #     print("Error calling lofng:", err)

def longpoll_start(vk_api, user_):
    try:
        Thread(target=der_lofng_start, args=(vk_api, user_), name= 'LongPoolStart').start()
    except SystemExit:
        pass


def lofng(vk_api, user_):
    """ Пример использования longpoll

        https://vk.com/dev/using_longpoll
        https://vk.com/dev/using_longpoll_2
    """


    # vk_session = vk_api.VkApi(login, password)

    # try:
    #     vk_session.auth(token_only=True)
    # except vk_api.AuthError as error_msg:
    #     print(error_msg)
    #     return
    time.sleep(30)

    longpoll = VkLongPoll(vk_api)

    for event in longpoll.listen():

        if event.type == VkEventType.MESSAGE_NEW:
            print(f'\n┌{"―"*5} Новое сообщение: {"―"*5}')
            izb = False
            if event.from_me:
                print(f'┊ От меня для: ', end='')

            elif event.to_me:
                try:
                    if int(user_.user_id) == int(event.user_id):
                        izb = True
                        print(f'┊ От меня в ', end='')
                    else:print(f'┊ Для меня от:', end='')
                except:
                    if int(user_.user_id) == int(event.peer_id):
                        izb = True
                        print(f'┊ От меня в ', end='')
                    else:print(f'┊ Для меня от:', end='')

            if event.from_user:
                if izb == True:print(f' Избранное')
                else:print(f' {get_user_FLname(vk_api, user_, event.user_id)} ┊ в личных сообщениях')
            elif event.from_chat:
                # print(event.user_id)
                print(f' {get_user_FLname(vk_api, user_, event.user_id)} ┊ в беседе _{get_dialog_name(vk_api, user_, event.chat_id)}_ (Chat ID: {event.chat_id})')
            elif event.from_group:
                print(f'┊ группы _{get_guild_name(vk_api, user_, event.group_id)}_ (https://vk.com/club{event.group_id})')

            if event.attachments != {}:

                ft = False
                try:
                    if event.attachments['attach1_type'] == 'wall':print(f'┊ Переслано: https://vk.com/wall{event.attachments["attach1"]}')
                    ft = True
                except Exception:pass
                try:
                    if event.attachments['attach1_type'] == 'sticker':print(f'┊ Стикер: https://vk.com/sticker/1-{event.attachments["attach1"]}-512b')
                    ft = True
                except KeyError:pass
                if ft == False:

                    types_f  = ['photo', 'video', 'audio', 'doc']
                    types_i = []

                    lens = int(len(event.attachments)/2)
                    # print((event.attachments).keys())
                    # print(list(((event.attachments).keys()))[-1])
                    for t in event.attachments:
                        if event.attachments[t] in types_f:
                            print(event.attachments[t])
                            types_i.append(event.attachments[t])

                    # print(types_i)
                    lst = []

                    photos = []
                    videos = []
                    audios = []
                    docs = []
                    for t in event.attachments:
                        # print('103',event.attachments[t])
                        if event.attachments[t] in types_i:
                            print('105', t, event.attachments[t], event.attachments[t.replace('_type','')])
                            if '_type' not in event.attachments[t]:

                                if event.attachments[t] == 'photo':photos.append(event.attachments[t.replace('_type','')])
                                elif event.attachments[t] == 'audio':audios.append(event.attachments[t.replace('_type','')])
                                elif event.attachments[t] == 'video':videos.append(event.attachments[t.replace('_type','')])
                                elif event.attachments[t] == 'doc':docs.append(event.attachments[t.replace('_type','')])
                                else:print('122 else',event.attachments[t])
                                # lst.append({f'{event.attachments[t]}': f"{event.attachments[t.replace('_type','')]}"})



                    ee = '\n'

                    a = []
                    # for q in lst:
                    # print(lst[0])#.keys())

                    # for i in range(len(lst)):
                    #     print(lst[i])
                    #     # print(list(i.keys())[0], list(i.values())[0])
                    #     ee = ee + '┊ Тип:'

                    # print(f'┊ Доп.файлы: {ee} ┊ Количество: {lens}')
                    if len(photos) != 0:
                        ee = ee + '┊ Тип: photos'
                        for i in photos:
                            ee = ee + f'\n┊ ┊ https://vk.com/album{i}'
                        ee = ee + '\n'
                    if len(audios) != 0:
                        ee = ee + '┊ Тип: audios'
                        for i in audios:
                            ee = ee + f'\n┊ ┊ https://vk.com/audio{i}'
                        ee = ee + '\n'
                    if len(videos) != 0:
                        ee = ee + '┊ Тип: video'
                        for i in photos:
                            ee = ee + f'\n┊ ┊ https://vk.com/video{i}'
                        ee = ee + '\n'
                    if len(docs) != 0:
                        ee = ee + '┊ Тип: docs'
                        for i in photos:
                            ee = ee + f'\n┊ ┊ https://vk.com/doc{i}'
                        ee = ee + ''


                    print(f'┊ Доп.файлы:  {ee}')

            if event.text != '':
                if '\n' in event.text: event.text = event.text.replace('\n', '\n┊ ')
                print(f'┊ Текст: \n┊ {event.text}') # ┊ Доп.файлы:  {'attach1_type': 'photo', 'attach1': '435600030_457252045', 'attach2_type': 'photo', 'attach2': '435600030_457251924'}

            print(f'└{"―"*21}')

        elif event.type == VkEventType.USER_TYPING:
            # print('Печатает ', end='')

            if event.from_user:
                pass
                # print(event.user_id)
            elif event.from_group:
                pass
                # print('администратор группы', event.group_id)

        elif event.type == VkEventType.USER_TYPING_IN_CHAT:
            pass
            # print('Печатает ', event.user_id, 'в беседе', event.chat_id)

        elif event.type == VkEventType.USER_ONLINE:
            print('Пользователь', event.user_id, 'онлайн', event.platform)

        elif event.type == VkEventType.USER_OFFLINE:
            print('Пользователь', event.user_id, 'оффлайн', event.offline_type)
        elif event.type == VkEventType.CHAT_UPDATE:
            if event.update_type == VkChatEventType.TITLE:
                print('event.update_type == VkChatEventType.TITLE')

        # elif event.type == VkChatEventType.MESSAGES_COUNTER_UPDATE:
        #     pass

        elif event.type == VkEventType.READ_ALL_INCOMING_MESSAGES:pass
        elif event.type == VkEventType.PEER_FLAGS_RESET:pass
        elif event.type == VkEventType.MESSAGE_EDIT:pass
        elif event.type == VkEventType.MESSAGES_COUNTER_UPDATE:pass
        elif event.type == VkEventType.MESSAGE_FLAGS_SET:pass
        elif event.type == VkEventType.READ_ALL_OUTGOING_MESSAGES:pass

        else:
            if event.type == 90:
                print(f'''
┌{"―"*5}Пользователь от/подписался на хоста: {"―"*5}
┊ Кто: {get_user_FLname(vk_api, user_, event.raw[2])}
┊ User ID: {event.raw[2]})
└{"―"*21}
''')

            print(event.type, event.raw[1:], event.raw, event.timestamp, event.type_id)


if __name__ == '__main__':
    der_lofng_start()