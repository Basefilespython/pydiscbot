import os
import shutil
def unzip():
    if not os.path.exists('PostImageFromData-main.zip'):raise FileNotFoundError('No such file')
    import zipfile
    with zipfile.ZipFile('PostImageFromData-main.zip', 'r') as zip_ref:
        print(os.getcwd())
        zip_ref.extractall(os.getcwd())
    os.remove('PostImageFromData-main.zip')
# unzip()
    for filename in os.scandir('PostImageFromData-main'):
        if filename.is_file():
            shutil.copy(rf'PostImageFromData-main/{filename.name}', os.getcwd())
        else:
            os.mkdir(filename.name)
            for filename_ in os.scandir(rf'PostImageFromData-main/{filename.name}'):
                if filename_.is_file():
                    shutil.copy(rf'PostImageFromData-main/{filename.name}/{filename_.name}', fr'{os.getcwd()}/{filename.name}')
                else:
                    os.mkdir(f'{os.getcwd()}/{filename.name}/{filename_.name}')
                    print(f'{filename_.name} {os.getcwd()}/{filename.name}/{filename_.name}/')
                    for filename__ in os.scandir(rf'PostImageFromData-main/{filename.name}/{filename_.name}'):
                        if filename__.is_file():
                            print(rf'PostImageFromData-main/{filename.name}/{filename_.name}/{filename__.name} -> {os.getcwd()}/{filename.name}/{filename_.name}/{filename__.name}')
                            shutil.copy(rf'PostImageFromData-main/{filename.name}/{filename_.name}/{filename__.name}', fr'{os.getcwd()}/{filename.name}/{filename_.name}/{filename__.name}')
                        
                        else:
                            os.mkdir(filename__.name)
                            print(f'{filename_.name} {os.getcwd()}/{filename.name}/{filename_.name}/{filename__.name}')
                            for filename___ in os.scandir(rf'PostImageFromData-main/{filename.name}/{filename_.name}/{filename__.name}'):
                                if filename___.is_file():
                                    shutil.copy(rf'PostImageFromData-main/{filename.name}/{filename_.name}/{filename__.name}/{filename___.name}', fr'{os.getcwd()}/{filename.name}/{filename_.name}/{filename__.name}/{filename___.name}')
    
    try:
        os.remove('PostImageFromData-main')
    except PermissionError as _:
        if os.name == 'nt':os.system(f'cd "{os.getcwd()}" && rd /S /Q PostImageFromData-main')
        elif os.name == 'linux':os.system(f'cd "{os.getcwd()}" && rm -rf PostImageFromData-main')

if __name__ == '__main__':
    unzip()
