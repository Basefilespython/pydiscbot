
url = 'https://github.com/Basefilespython/pydiscbot/raw/main/projects/zips/PostImageFromData-main.zip'


import os
import http
import shutil
import urllib
from urllib.request import HTTPError

black = "\033[30m"
red = "\033[31m"
green = "\033[32m"
yellow = "\033[33m"
blue = "\033[34m"
violet = "\033[35m"
turquoise = "\033[36m"
white = "\033[37m"
st = "\033[37"




class Update():
    def __init__(self, url_):
        self.url = url_
        
    def downloading(self, url, name_file):
        url = url.replace(" ", "%20")

        if "?size=" in url:
            ind = url.find("?size=")
        else:
            if "?extra=" in url:
                ind = url.find("?extra=")
            else:
                ind = len(url)

        print('\r', end='')

        try:
            urllib.request.urlretrieve(str(url), name_file)
            print(f"{green}[+] 200: {blue}{name_file}{white}  URL: {url[0:ind]}")
            status = '200'
            err_code = ''

        except HTTPError as err_code:
            print(
                f"{red}[-] {red}{err_code.code}: {blue}{name_file}{white}  URL: {url[0:ind]}")
            status = f'{err_code.code}'

        except urllib.error.URLError as err_code:
            if "[WinError 10054]" in str(err_code):
                print(
                    f"{red}[-] {red}522: {blue}{name_file}{white}  URL: {url[0:ind]}")
                status = f'522'

            elif "[Errno 99]" in str(err_code):
                print(
                    f"{red}[-] {red}524: {blue}{name_file}{white}  URL: {url[0:ind]}")
                status = f'524'

            elif "[SSL: WRONG_VERSION_NUMBER]" in str(err_code):
                print(
                    f"{red}[-] {red}526: {blue}{name_file}{white}  URL: {url[0:ind]}")
                status = f'526'

            elif "[Errno 11001]" in str(err_code):
                print(
                    f"{red}[-] {red}101: {blue}{name_file}{white}  URL: {url[0:ind]}")
                status = f'101'

            elif "[WinError 10060]" in str(err_code):
                print(
                    f"{red}[-] {red}524: {blue}{name_file}{white}  URL: {url[0:ind]}")
                status = f'524'

            elif "[Errno 104]" in str(err_code):
                print(
                    f"{red}[-] {red}524: {blue}{name_file}{white}  URL: {url[0:ind]}")
                status = f'524'

            elif "<urlopen error retrieval incomplete:" in str(err_code):
                print(
                    f"{violet}[?] 103: {blue}{name_file}{white}  URL: {url[0:ind]}")
                status = f'103'

            elif '[WinError 10053]' in str(err_code):
                print(
                    f"{violet}[?] 103: {blue}{name_file}{white}  URL: {url[0:ind]}")
                status = '103'

            else:
                print('\r', end='')
                err_code = str(err_code).replace(
                    '<',
                    '').replace(
                    '>',
                    '').replace(
                    'urlopen error ',
                    '')
                print(
                    f"{violet}[?] ___ ('{err_code}): {blue}{name_file}{white}  URL: {url[0:ind]}")
                status = f'___ ({err_code})'
        except OSError as err_code:
            if "[Errno 28]" in str(err_code):
                print(
                    f"{red}[-] {red}700: {blue}{name_file}{white}  URL: {url[0:ind]}")
                status = f'700'
            elif '[WinError 10053]' in str(err_code):
                print(
                    f"{violet}[?] 103: {blue}{name_file}{white}  URL: {url[0:ind]}")
                status = '103'
            else:
                err_code = str(err_code).replace(
                    '<',
                    '').replace(
                    '>',
                    '').replace(
                    'urlopen error ',
                    '')
                print(
                    f"{violet}[?] ___ ('{err_code}): {blue}{name_file}{white}  URL: {url[0:ind]}")
                status = f'___ ({err_code})'

        except http.client.RemoteDisconnected as err_code:
            print(
                f"{violet}[-] {violet}RemoteDisconnected: {blue}{name_file}{white}  URL: {url[0:ind]}")

            status = f'101'

        except ConnectionResetError as err_code:
            print(
                f"{violet}[-] {violet}ConnectionResetError: {blue}{name_file}{white}  URL: {url[0:ind]}")
            status = f'101'

        except ValueError as err_code:
            print(
                f"{violet}[?] ValueError: {blue}{name_file}{white}  URL: {url[0:ind]}")
            status = f'102'

        except KeyboardInterrupt as err_code:
            print(
                f"{red}[!] KeyboardInterrupt: {blue}{name_file}{white}  URL: {url[0:ind]}")
            status = '999'

        except FileExistsError as err_code:
            print(
                f"{violet}[-] FileExistsError: {blue}{name_file}{white}  URL: {url[0:ind]}")
            status = '200'
        return status


    def unzip(self):
        if not os.path.exists('PostImageFromData-main.zip'):raise FileNotFoundError('No such file')
        import zipfile
        with zipfile.ZipFile('PostImageFromData-main.zip', 'r') as zip_ref:
            # print(os.getcwd())
            zip_ref.extractall(os.getcwd())
        os.remove('PostImageFromData-main.zip')
        for filename in os.scandir('PostImageFromData-main'):
            if filename.is_file():
                shutil.copy(rf'PostImageFromData-main/{filename.name}', os.getcwd())
            else:
                os.mkdir(filename.name)
                for filename_ in os.scandir(rf'PostImageFromData-main/{filename.name}'):
                    if filename_.is_file():
                        shutil.copy(rf'PostImageFromData-main/{filename.name}/{filename_.name}', fr'{os.getcwd()}/{filename.name}')
                    else:
                        os.mkdir(f'{os.getcwd()}/{filename.name}/{filename_.name}')
                        # print(f'{filename_.name} {os.getcwd()}/{filename.name}/{filename_.name}/')
                        for filename__ in os.scandir(rf'PostImageFromData-main/{filename.name}/{filename_.name}'):
                            if filename__.is_file():
                                # print(rf'PostImageFromData-main/{filename.name}/{filename_.name}/{filename__.name} -> {os.getcwd()}/{filename.name}/{filename_.name}/{filename__.name}')
                                shutil.copy(rf'PostImageFromData-main/{filename.name}/{filename_.name}/{filename__.name}', fr'{os.getcwd()}/{filename.name}/{filename_.name}/{filename__.name}')
                            
                            else:
                                os.mkdir(filename__.name)
                                # print(f'{filename_.name} {os.getcwd()}/{filename.name}/{filename_.name}/{filename__.name}')
                                for filename___ in os.scandir(rf'PostImageFromData-main/{filename.name}/{filename_.name}/{filename__.name}'):
                                    if filename___.is_file():
                                        shutil.copy(rf'PostImageFromData-main/{filename.name}/{filename_.name}/{filename__.name}/{filename___.name}', fr'{os.getcwd()}/{filename.name}/{filename_.name}/{filename__.name}/{filename___.name}')
        
        try:
            os.remove('PostImageFromData-main')
        except PermissionError as _:
            if os.name == 'nt':os.system(f'cd "{os.getcwd()}" && rd /S /Q PostImageFromData-main')
            elif os.name == 'linux':os.system(f'cd "{os.getcwd()}" && rm -rf PostImageFromData-main')
        except IsADirectoryError:
            if os.name == 'nt':os.system(f'cd "{os.getcwd()}" && rd /S /Q PostImageFromData-main')
            elif os.name == 'linux':os.system(f'cd "{os.getcwd()}" && rm -rf PostImageFromData-main')
            
    def start(self):
        status = self.downloading(self.url, 'PostImageFromData-main.zip')
        if status == '200':self.unzip()
        else:
            status = self.downloading(self.url, 'PostImageFromData-main.zip')
            if status != '200':
                print(f'The script cannot be updated due to status {status}')
            else:self.unzip()

if __name__ == '__main__':
    U = Update(url)
    U.start()
