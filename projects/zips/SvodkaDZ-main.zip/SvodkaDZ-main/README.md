# SvodkaDZ

`SvodkaDZ` - это Telegram-бот, который отсылает домашнее задание на следующий, сегодняшний, вчерашний день. Кроме вышеперечисленных заданий бот способен отправлять данные об других домашних задниях, если такие есть в самом дневнике.

## Команды

- /help - Выводит информацию обо всех ВИДИМЫХ командах.
- /nexthomework - Что задано на следующий день.
- /weather - Погода
- /myid - Ваш ID
- /chatid - ID беседы
- /config - Информация об конфиге бота


## How to build?


1. **Клонируйте репозиторий:**
    ```bash
    git clone https://github.com/BSNIKYT/SvodkaDZ.git
    cd SvodkaDZ
    ```

2. **Установите зависимости (если они есть):**
    ```bash
    pip install -r requirements.txt
    ```

3. **Запустите скрипт:**
    ```bash
    python main.py
    ```
   
   Или, если у вас есть скрипт, который компилирует что-то:
    ```bash
    python main.py
    ```

4. **Дополнительные параметры (если есть):**
    - Укажите дополнительные параметры, если они необходимы для запуска.
    - Например:
        ```bash
        python ваш_скрипт.py --параметр значение
        ```


## Author

https://vk.com/id435600030

## Python version?

Old version of Jarvis was built with Python.<br>
The last Python version commit can be found [here](https://github.com/BSNIKYT/SvodkaDZ/commit/main).

## License

This work is licensed under [CC BY-NC 4.0](http://creativecommons.org/licenses/by-nc/4.0/?ref=chooser-v1)<br>
See LICENSE.txt file for more details.
