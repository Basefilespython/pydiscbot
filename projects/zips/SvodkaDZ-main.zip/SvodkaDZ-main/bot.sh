#!/bin/bash

set -e

if [[ $# -lt 1 ]] || [ $1 == help ]; then
	echo "arguments: bot [init|start|stop/kill|restart|udpate|info/status|log] [silent]"
	echo "init: create python venv and update repo"
	echo "start: run the bot"
	echo "stop/kil: stop the bot if the instance exists"
	echo "restart: same as kill & start"
	echo "update: pull changes from git and update pip packages"
	echo "status/info: check whether the bot is running. note: if the bot is dead and python process is not, it will show that the bot is still alive"
	echo "log: display logs from previous (or current) running instance"
	echo "silent: disable logging"
	exit $( [[ $# -ne 1 ]] )
fi

HM=/home/ssh/SvodkaDZ
PID=""
SILENT=$2

function upd_pip_git {
	$HM/venv/bin/pip install --quiet -r $HM/requirements.txt
	git -C $HM pull
}

function check_running {
	PID=$( pgrep -f $HM/venv/bin/python3 )
	return $?
}

function kill_if {
	if $( check_running ); then
		kill $PID
		RET=$?
	else
		RET=-1
	fi
	return $RET
}

function start_bot {
	REST=`pwd`
	cd $HM
	CMD="$HM/venv/bin/python3 $HM/main.py"
	if [ "$1" == silent ]; then
		$CMD > /dev/null 2>&1 &
	else
		echo $( date ) >> ./start.log
		$CMD  >> ./start.log &
	fi
	disown
	cd $REST
}

if [ $1 == init ]
then
	mkdir -p $HM/venv
	python3 -m venv $HM/venv
fi

if [ $1 == init ] || [ $1 == update ] || [ $1 == restart ]
then
	echo updating
	upd_pip_git
fi

if [ $1 == stop ] || [ $1 == kill ] || [ $1 == restart ]
then
	echo trying to kill instance
	if check_running; then
		if kill_if; then 
			echo "killed successfully"
		else
			echo "could not kill previous instance"
		fi
	else
		echo "no running instance found"
	fi
fi

if [ $1 == start ] || [ $1 == restart ]
then
	echo starting...
	start_bot $SILENT
fi

if [ $1 == info ] || [ $1 == status ]
then
	echo info:
	if $( check_running ); then
		echo "bot is running"
	else
		echo "bot is not running"
	fi
fi

if [ $1 == log ]
then
	cat out.log
fi

