import platform
import urllib.request
import time
import os
import telebot
import random
import requests
import traceback
from telebot import types
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, InputFile
from datetime import datetime as datetime_, timezone, timedelta
from modules.weather.weather import WeaherConfigEror
from threading import Thread
from modules.functions import EditConfigHandler
from modules.functions import send_local_data, send_custom_keyboard, is_school_day, get_ip_info, \
    get_information_about_M, rezerve_logs_stek_no_log, days_and_weeks_until_targetS, send_command_in_cmd, check_internet
from modules.functions import set_settings_configuration

check_internet()


WDir = os.getcwd()


bot, C, M, F, L, SEND_TIME_LOGGER, MESSAGE_LOGGER, MODULE, CALLBACK_LOGGER, EVENT_LOGGER, S, H = set_settings_configuration()




def add_temporary_InlineKeyboard(aaa):
    text1, text2, text3 = aaa[0], aaa[1], aaa[2]
    markup_old_now_next_dz = InlineKeyboardMarkup()
    markup_old_now_next_dz.add(InlineKeyboardButton(text=text1, callback_data=f'old-dz'),
                        InlineKeyboardButton(text=text2, callback_data=f'now-dz'),
                        InlineKeyboardButton(text=text3, callback_data=f'next-dz'))
    return markup_old_now_next_dz





@bot.callback_query_handler(func=lambda call:True)
def callback_query(call):
    req = call.data.split('_')
    CLB = EditConfigHandler(bot, C)
    CALLBACK_LOGGER.info(command = '_', autor_log= f'{call.message.chat.id}.{call.message.from_user.id}', text = req[0])
    print(req)
    
    
    if req[0] == 'unseen-dz':
        bot.delete_message(call.message.chat.id, call.message.message_id)
    elif req[0] == 'old-dz':
            time_now = str(datetime_.now()).split(' ')[0]
            new_time = M.stat_old_date(time_now)

            bot.reply_to(chat_id=call.message.chat.id,  text = M.get_homework_by_date(new_time), reply_markup = add_temporary_InlineKeyboard(['Вчера', 'Сегодня', 'Завтра']), parse_mode = 'html')
    elif req[0] == 'next-dz':
            time_now = str(datetime_.now()).split(' ')[0]
            new_time = M.stat_next_date(time_now)
            bot.reply_to(chat_id=call.message.chat.id, text = M.get_homework_by_date(new_time), reply_markup = add_temporary_InlineKeyboard(['Вчера', 'Сегодня', 'Завтра']), parse_mode = 'html')
    elif req[0] == 'now-dz':
        tes = M.get_homework_by_date(M.stat_now_date())
        if tes == '': tes = 'NONE'
        bot.reply_to(chat_id=call.message.chat.id, text = tes, reply_markup = add_temporary_InlineKeyboard(['Вчера', 'Сегодня', 'Завтра']), parse_mode = 'html')


    elif req[0] == 'unseen-edit':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        
    elif req[0] in ['token-m', 'token-t', 'senler-morning', 'senler-evening', 'weather-lang', 'weather-city']:
        if call.message.chat.type == 'private':
            CLB.Sorting(req[0], call.message)
        else:bot.reply_to(message = call.message, text = 'Эта команду нужно вводить только в лс бота.')   
    
    elif 'SendCustomHomework.' in req[0]:
        id_ = str(req[0].split('.')[1])
        try:
            bot.edit_message_text(message_id= call.message.message_id, chat_id=call.message.chat.id, text= M.get_homework_by_date(id_), parse_mode = 'html', reply_markup = send_custom_keyboard(F, id_))
            # print(req[0], id_)
        except telebot.apihelper.ApiTelegramException:pass


        
        

@bot.message_handler(commands=['qqa'])
def welcome(message):
    bot.register_next_step_handler(bot.send_message(message.chat.id,'Please send me message'),test)


def test(message):
    bot.send_message(message.chat.id, f'You send me message -> {message.text}')


@bot.message_handler(commands=['events'])
def day_do(message):
    try:
        bot.reply_to(message=message, text = days_and_weeks_until_targetS(), parse_mode = 'html')
        L.info(command = 'events', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')
    except Exception as err:
        on_error_in_code(message, str(err), 'True')
        L.error(command = 'events', autor_log = f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message = str(err))


@bot.message_handler(commands=['start'])
def start(message):
    """
    Обработчик команды "/start" для запуска бота.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        None

    Процесс выполнения:
        1. Записывает информацию о команде в лог.
        2. Вызывает функцию обработки команды "/help" (help_def).

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """

    L.info(command = 'start', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')
    help_def(message)

@bot.message_handler(commands=['del'])
def del_message(message):
    """
    Обработчик команды "/del" для удаления сообщений в чате.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        None

    Процесс выполнения:
        1. Пытается удалить сообщение, на которое была отправлена команда "/del".
        2. Удаляет сообщение пользователя, отправившего команду.
        3. В случае возникновения ошибки при удалении сообщений, исключение обрабатывается, и выполнение продолжается.

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """
    try:
        bot.delete_message(chat_id = message.chat.id, message_id = message.reply_to_message.id)
        bot.delete_message(chat_id=message.chat.id, message_id=message.id)
        L.info(command = 'del', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully deleted {message.reply_to_message.id}')
    except Exception:
        try:bot.delete_message(chat_id=message.chat.id, message_id=message.id)
        except Exception:pass




@bot.message_handler(commands=['pin'])
def pin_message(message):
    """
    Закрепляет сообщение в чате Telegram.

    Аргументы:
    - message: Объект сообщения от Telegram, который содержит информацию о запросе.

    Пример использования:
        /pin [в ответ на сообщение, которое нужно закрепить]

    Возвращает:
    - В случае успеха отправляет сообщение об успешном закреплении.
    - В случае ошибки отправляет сообщение об ошибке.

    Обработка ошибок:
    - В случае отсутствия атрибутов или недостаточных прав выводит соответствующее сообщение об ошибке.

    Пример использования:
    pin_message(message)

    """
    try:
        bot.pin_chat_message(chat_id=message.chat.id, message_id=message.reply_to_message.message_id)
        bot.reply_to(message = message, text= f'Успех!\nПользователь: <i><a href="tg://user?id={message.from_user.id}">{message.from_user.full_name}</a></i> закрепил сообщение.', parse_mode='html')
        L.info(command = 'pin', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully pinned')
    except AttributeError as err:
        on_error_in_code(message, 'Вы должны обязательно указать какое сообщение нужно закрепить.')
        L.error(command = 'pin', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы должны обязательно указать какое сообщение нужно закрепить.')
    except telebot.apihelper.ApiTelegramException as err:
        if 'not enough rights to manage pinned messages in the chat' in str(err):
            msg = 'Не хватает прав!'
            L.error(command = 'pin', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Не хватает прав!', code = 403, error_message='forbidden')
        else:
            L.error(command = 'pin', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'telebot.apihelper.ApiTelegramException', code = 1, error_message = str(err))
            msg = str(err)   
        
        on_error_in_code(message, msg)
    except Exception as err:
        on_error_in_code(message, str(err), 'True')
        L.error(command = 'pin', autor_log = f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message = str(err))


def send_console(message, command):
    # print(command)
    try:
        attribute = command.split(' ')
        # print(f'{attribute}')
        if attribute[2] == '--help':
            msg = 'Использование:\n<pre><code class="language-python">/config cmd ВАША_КОМАНДА</code></pre>'
            bot.reply_to(message = message, text= msg, parse_mode='html')
            L.info(command = 'config cmd help', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended')
        else:
            command = command.replace('/config cmd ', '')
            # print(command)
            try:
                out = send_command_in_cmd(command)
                sendM(bot, message, f'Успех!\nБыло отправленно: {command}')
                sendM(bot, message, f'{out}')
                L.info(command = 'config cmd INPUT_COMMAND', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'Command: {out}')
            except Exception as err:
                on_error_in_code(message, str(err), 'True')
                L.error(command = 'config cmd INPUT_COMMAND', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'Exception Command: {out}', code = 0, error_message=str(err) + '\n'+ str(traceback.format_exc()))

    except IndexError as err:
        if 'list index out of range' in str(err):
            on_error_in_code(message, f'Использование:\n<pre><code class="language-python">/config cmd ВАША_КОМАНДА</code></pre>')
            L.error(command = 'config cmd [attribute]', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы должны отправить атрибут!', code = 404, error_message=f'not found {command}')
        else:
            print(traceback.format_exc())
            on_error_in_code(message, str(err), 'True')
            L.error(command = 'config cmd [attribute]', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'IndexError', code = 4, error_message=f'not found {command}')
    except Exception as err:
        on_error_in_code(message, str(err), 'True')
        L.error(command = 'config cmd [attribute]', autor_log = f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message = str(err) + '\n'+ str(traceback.format_exc()))


def send_logs(message, text):
    """
    Отправляет логи хоста в чат Telegram в зависимости от указанных атрибутов.

    Аргументы:
    - message: Объект сообщения от Telegram, который содержит информацию о запросе.
    - text: Текст сообщения с атрибутами для выполнения команды.

    Примеры использования:
    1. Отправить справку о доступных атрибутах:
        /config logs --help

    2. Получить текстовый формат логов:
        /config logs text

    3. Получить файл с логами:
        /config logs file

    Атрибуты:
    - --help: Выводит справку по доступным атрибутам.
    - text: Возвращает текстовый формат логов в виде сообщения.
    - file: Отправляет файл с логами хоста в виде документа.

    Возвращает:
    - В зависимости от выполненной команды, отправляет сообщение с текстом логов или документ с файлом логов.

    Обработка ошибок:
    - В случае отсутствия атрибутов выводит сообщение об ошибке.
    - В случае неудачной попытки открытия файла логов выводит соответствующее сообщение об ошибке.

    Пример использования:
    send_logs(message, "/config logs text")
    """
    try:
        attribute = text.split(' ')
        if attribute[2] == '--help':
            msg = 'Список всех аттрибутов:\n/config logs --help\n/config logs text\n/config logs file'
            bot.reply_to(message = message, text= msg, parse_mode='html')
            L.info(command = 'config logs help', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended')
        elif attribute[2] == 'text':
            try:
                with open("modules/MainScript.log", "r") as file1:
                    lines = []
                    for line in file1:
                        lines.append(line.strip())
                    data = '\n'.join(lines)
                    data = data.replace('<', '_(_').replace('>', '_)_')             
                    
                    if len(data) > 4095:
                        for x in range(0, len(data), 4095):
                            bot.send_message(chat_id = message.chat.id, text=f'''<pre><code class="language-python">{data[x:x+4095]}</code></pre>''', parse_mode='html')
                            time.sleep(2)

                    else:
                        bot.reply_to(message, text=f'''Успех!\n<pre><code class="language-python">{data}</code></pre>''', parse_mode='html')
                    
                    L.info(command = 'config logs text', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended')
                    
            except FileNotFoundError as err:
                print(traceback.format_exc())
                on_error_in_code(message, 'Файл не был найден в дирректории.')
                L.error(command = 'config logs text', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'FileNotFoundError', code = 0, error_message=str(err))
            except Exception as err:
                on_error_in_code(message, str(err), 'True')
                L.error(command = 'config logs text', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message=str(err) + '\n'+ traceback.format_exc())
               
        elif attribute[2] == 'file':
            try:
                with open("modules/MainScript.log",'rb') as myzip:bot.send_document(chat_id=message.chat.id, document=myzip, caption='Логи хоста')
            except FileNotFoundError as err:
                print(traceback.format_exc())
                on_error_in_code(message, 'Файл не был найден в дирректории.')
                L.error(command = 'config logs file', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'FileNotFoundError', code = 0, error_message=str(err))
        else:
            bot.reply_to(message = message, text= f'Аттрибут не определен!\n\nСписок всех аттрибутов:\n/config logs --help\n/config logs text\n/config logs file')
            L.error(command = 'config logs [attribute]', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Команда конфига не определена!', code = 404, error_message=f'not found {attribute[2]}')
    except IndexError as err:
        if 'list index out of range' in str(err):
            on_error_in_code(message, f'Аттрибут не определен!\n\nСписок всех аттрибутов:\n/config logs --help\n/config logs text\n/config logs file')
            L.error(command = 'config [attribute]', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы должны отправить атрибут!', code = 404, error_message=f'not found {text}')
        else:
            print(traceback.format_exc())
            on_error_in_code(message, str(err), 'True')
            L.error(command = 'config logs [attribute]', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'IndexError', code = 4, error_message=f'not found {attribute[2]}')

@bot.message_handler(commands=['rezerve_logs'])
def rezerve_send_logs(message):
    try:rezerve_logs_stek_no_log(message, bot)
    except Exception as err:on_error_in_code(message, str(err), 'True')
        
def send_bool_is_school_day(message):
    bot.reply_to(message = message, text= f'Ответ:\n<code>{is_school_day()}</code>', parse_mode='html')
    L.info(command = 'config is_school_day', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended {is_school_day()}')


def send_zip(message):
    """
    Отправляет zip-архив с файлами в личное сообщение Telegram.

    Аргументы:
    - message: Объект сообщения от Telegram, который содержит информацию о запросе.

    Пример использования:
        /send_zip

    Возвращает:
    - В случае успеха отправляет zip-архив с файлами в личное сообщение.
    - В случае ошибки отправляет сообщение об ошибке.

    Обработка ошибок:
    - В случае отсутствия доступа, отправляет сообщение об ошибке доступа.
    - Если команда не введена в личном сообщении, отправляет сообщение с инструкцией по использованию.

    Пример использования:
    send_zip(message)

    """
    if message.from_user.id in C.access_users:
        if message.chat.type == 'private':
            file_name_ = "zip_file_to_send_admin.zip"
            try:
                from zipfile import ZipFile
                
                if os.path.exists(file_name_):os.remove(file_name_)
                
                with ZipFile(file_name_, "a") as myzip:
                    for file in os.listdir(os.getcwd()):
                        if file_name_ != file:
                            myzip.write(file)
                
                with open(file_name_,'rb') as myzip:
                    bot.send_document(chat_id=message.chat.id, document=myzip, caption='TEST!12')
           
                os.remove(file_name_)
                L.info(command = 'zip', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended')
            except:
                if os.path.exists(file_name_):os.remove(file_name_)
        else:
            on_error_in_code(message, 'Эту команду нужно прописывать в лс с ботом!')
            L.error(command = 'zip', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Эту команду нужно прописывать в лс с ботом!', code = 7, error_message='no private error')
    else:
        on_error_in_code(message, 'Вы не имеете доступа к этой команде!')
        L.error(command = 'zip', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы не имеете доступа к этой команде!', code = 403, error_message='forbidden')
        

  
        
        
@bot.message_handler(commands=['unpin'])
def unpin_message(message):
    """
    Обработчик команды "/unpin" для открепления сообщения в чате.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        None

    Процесс выполнения:
        1. Записывает информацию о команде в лог.
        2. Пытается открепить сообщение, на которое указывает ответ пользователя.
        3. В случае успешного открепления, отправляет уведомление об успехе и записывает информацию в лог.
        4. В случае ошибки, отправляет уведомление об ошибке и записывает информацию в лог.

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """
    try:
            L.info(command = 'unpin', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully pinned {message.reply_to_message.message_id}')
            bot.unpin_chat_message(chat_id=message.chat.id, message_id=message.reply_to_message.message_id)
            bot.reply_to(message = message, text= f'Успех!\nПользователь: <i><a href="tg://user?id={message.from_user.id}">{message.from_user.full_name}</a></i> открепил сообщение.', parse_mode='html')
    except AttributeError as err:
        on_error_in_code(message, 'Вы должны обязательно указать какое сообщение нужно закрепить.')
        L.error(command = 'unpin', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы должны обязательно указать какое сообщение нужно закрепить.')
    except telebot.apihelper.ApiTelegramException as err:
        if 'not enough rights to manage unpinned messages in the chat' in str(err):
            msg = 'Не хватает прав!'
            L.error(command = 'unpin', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы должны обязательно указать какое сообщение нужно закрепить.')
        else:
            L.error(command = 'unpin', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'telebot.apihelper.ApiTelegramException', code = 1, error_message = str(err))
            msg = str(err)
        
        on_error_in_code(message, msg)
    except Exception as err:
        on_error_in_code(message, str(err), 'True')
        L.error(command = 'unpin', autor_log = f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message = str(err))



@bot.message_handler(commands=['neko'])
def send_neko(message):
    """
    Обработчик команды "/neko" для отправки случайного арта с nekos в чат пользователя.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        Exception: В случае ошибки при получении или отправке арта.

    Example:
        /neko

    Процесс выполнения:
        1. Получает список nekos из удаленного JSON-файла.
        2. Выбирает случайный URL арта.
        3. Формирует имя файла для сохранения.
        4. Загружает арт по URL.
        5. Отправляет арт в чат с прикреплением к сообщению.
        6. Удаляет временный файл.
        7. Логирует успешную отправку.

    Примечание:
        - Функция предназначена для ответа на команду "/neko" от пользователя.
        - Использует библиотеки telebot, requests, random и urllib.
        - Для корректной работы требуется наличие файла telebot_nice_nekos.json с URL-ами артов.
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """
    try:
        nekos = requests.get('https://raw.githubusercontent.com/Basefilespython/pydiscbot/main/projects/data/telebot_nice_nekos.json')
        nekos = (nekos.content).decode("utf-8").replace('\n', '').replace(' ', '').replace('"', '').replace('[', '').replace(']', '').split(',')
        url = random.choice(nekos)
        name_file = f'nekos.{url.split("/")[-1].split("?")[0]}'
        urllib.request.urlretrieve(url, f'''{name_file}''')
        

        bot.send_photo(photo = InputFile(f'{name_file}'), caption=f'<a href="{url}/">Держи!</a>\nОбщее количество артов: {len(nekos)}', chat_id=message.chat.id, parse_mode= 'html')
        os.remove(name_file)
        L.info(command = 'neko', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended {name_file}')
    except Exception as err:
        L.error(command = 'neko', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message=str(err))
        on_error_in_code(message, str(err), 'True')




@bot.message_handler(commands=['weather'])
def weather_(message):
    """
    Обработчик команды "/weather" для отправки информации о погоде в чат пользователя.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        None

    Процесс выполнения:
        1. Импортирует модуль `weather` из пакета `modules`.
        2. Запрашивает данные о погоде с использованием функции `get_weather` из модуля `weather`.
        3. В случае успешного получения данных, отправляет информацию о погоде в чат.
        4. В случае ошибки при получении данных, отправляет сообщение об ошибке в чат.

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """
    try:
        from modules.weather import weather
        data = weather.get_weather(Config=C, index=1)
        bot.reply_to(message = message, text= data)
        L.info(command = 'weather', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended')
        
    except WeaherConfigEror as err:
        err = str(err)
        if 'The city was not found.' == err:
            print(f'''WeatherConfigError: {C.weather['city']} was not found on the server.''')
            msg = f'''Конфиг был неправильно определен:\n{C.weather['city']} не был найден на сервере.'''
        elif 'The city has not been determined.' == err:
            print(f'''WeatherConfigError: Значение не определено!''')
            msg = f'''Конфиг был неправильно определен:\nЗначение не определено!.'''
        else:
            msg = err
        on_error_in_code(message, msg)
        L.error(command = 'weather', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'WeaherConfigEror', code = 7, error_message=str(err))
    except requests.exceptions.ReadTimeout as err:
        on_error_in_code(message, 'Задержка со стороны сервера...')
        L.error(command = 'weather', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'requests.exceptions.ReadTimeout', code = 2, error_message=str(err))
    except Exception as err:
        on_error_in_code(message, str(err), 'True')
        L.error(command = 'weather', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message=str(err))
        


@bot.message_handler(commands=['nexthomework'])
def send_next_homework(message):
    """
    Обработчик команды "/nexthomework" для отправки домашнего задания на следующую дату.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        None

    Процесс выполнения:
        1. Получает текущую дату.
        2. Вычисляет следующую дату с использованием функции `stat_next_date` из модуля `M`.
        3. Отправляет домашнее задание на следующую дату в чат.

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """
    try:
        time_now = str(datetime_.now()).split(' ')[0]
        new_time = M.stat_next_date(time_now)
        data = M.get_homework_by_date(new_time)
        bot.reply_to(message=message, text=data, parse_mode='html')
        L.info(command = 'nexthomework', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended {new_time}')
    except Exception as err:
        traceback.print_exc()
        L.error(command = 'nexthomework', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'Exception ({new_time})', code = 0, error_message=str(err))


@bot.message_handler(commands=['homework'])
def send_custom_homework(message):
    """
    Обработчик команды "/homework" для отправки домашнего задания на указанную дату.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        None

    Процесс выполнения:
        1. Проверяет, была ли команда "/homework" введена с указанием даты.
        2. Извлекает дату из текста сообщения.
        3. Проверяет формат даты с использованием функции `out_formated_data`.
        4. Если формат даты корректен, отправляет домашнее задание на указанную дату в чат.
        5. В случае ошибки, отправляет сообщение с описанием правильного формата.

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """
    def send_error(bot_, message_, text_):
        L.error(command = 'homework', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Несоответствие формату!')
        try:
            bot_.reply_to(message = message_, text= text_, parse_mode= 'html')
        except Exception as err:
            on_error_in_code(message, str(err), 'True')
    error_text= 'Вы должны отправить дату в соответствии формату\n/homework <code>[ДАТА]-[МЕСЯЦ]-[ГОД]</code>\nПример: /homework 01-01-24'
    
    if message.text != '/homework':
        try:
            time = message.text.split(' ')[1]
        except IndexError:
            time = ''
            
        if time != '':
            BOOL, return_data = out_formated_data(time)
            if bool(BOOL) == True:
                try:
                    return_data_ = return_data
                    out_M = M.get_homework_by_date(return_data)
                    out_MK= send_custom_keyboard(F, return_data_)
                    bot.reply_to(message = message, text= out_M, parse_mode = 'html', reply_markup = out_MK)
                    L.info(command = 'homework', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended ({return_data})')
                except Exception as e:
                    L.error(command = 'homework', autor_log= f'{message.chat.id}.{message.from_user.id}', text = return_data, code = 0, error_message = str(e) + '\n'+ traceback.format_exc())
                    pass
            else:send_error(bot_=bot, message_= message, text_ = error_text)
        else:send_error(bot_=bot, message_= message, text_ = error_text)
    else:send_error(bot_=bot, message_= message, text_ = error_text)


@bot.message_handler(commands=['all'])
def mention_all_memders(message):
    """
    Функция для отправки списка участников чата в чат пользователя.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        list: Список идентификаторов участников чата.

    Raises:
        None

    Процесс выполнения:
        1. Вызывает функцию send_all_members модуля S, предположительно определенного в модуле S.
        2. Для каждого идентификатора участника чата:
            - Вызывает метод bot.get_chat_member для получения информации о пользователе.
            - Извлекает необходимые данные о пользователе (идентификатор, имя, фамилия, статус бота).
            - Форматирует информацию в виде строки HTML и добавляет в общую строку s.
        3. Логгирует количество участников и отправляет сформированный список в чат пользователя.

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
        - Использует функцию send_all_members из модуля S и метод bot.get_chat_member из telebot.
    """
    if message.chat.type != 'private':
        members = S.send_all_members(message)
        s = ''
        for member_id in members:
            _ = bot.get_chat_member(chat_id=message.chat.id, user_id=member_id)
            user_id = _.user.id
            is_bot = _.user.is_bot
            name1 = _.user.first_name
            username=_.user.username
            last_name = _.user.last_name

            

            if str(name1) != 'None':
                name = name1
            else:
                if str(last_name) != 'None':
                    name = last_name
                else:name == f'@{username}'
            
            s = s +  f'''
    <a href="tg://user?id={user_id}">{name} {(last_name if str(last_name) != 'None' else '')} {('(БОТ)' if is_bot else '')}</a>   <code>{user_id}</code>'''

        L.info(command = 'all', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended (count: {len(members)})')
        bot.reply_to(message = message, text= s, parse_mode='html')
        
    else:
        on_error_in_code(message, 'Эту команду нужно прописывать в беседе с ботом!')
        L.error(command = 'all', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Эту команду нужно прописывать в беседе с ботом!', code = 7, error_message='private error')

@bot.message_handler(commands=['myid'])
def send_next_homework(message):
    """
    Обработчик команды "/myid" для отправки идентификатора пользователя в чат.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        None

    Процесс выполнения:
        1. Пытается извлечь идентификатор и объект пользователя:
            - Если есть ответ на сообщение и есть идентификатор пользователя, использует их.
            - В противном случае, использует идентификатор и объект пользователя отправителя.
        2. Отправляет сообщение в чат пользователя с информацией об идентификаторе в виде HTML.
        3. Логгирует результат выполнения команды.

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """
    try:
        try:
            if message.reply_to_message.user.id:
                user_id = message.reply_to_message.user.id
                user = message.reply_to_message.user
                reply_ = True
            else:
                user_id = message.from_user.id
                user = message.from_user
                reply_ = False
        except AttributeError:
            reply_ = False
            user_id = message.from_user.id
            user = message.from_user
        bot.reply_to(message = message, text= f'ID <i><a href="tg://user?id={user_id}">{user.full_name}</a></i>: {user_id}', parse_mode='html')
        L.info(command = 'myid', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended ({reply_})')
    except Exception as err:
        bot.reply_to(message = message, text= f'Ошибка!\n<code>{err}</code>', parse_mode='html')
        L.error(command = 'myid', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message=str(err))

  
@bot.message_handler(commands=['chatid'])
def send_next_homework(message):
    """
    Обработчик команды "/chatid" для отправки идентификатора чата в ответ на команду пользователя.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        None

    Процесс выполнения:
        1. Отправляет сообщение в чат пользователя с идентификатором текущего чата.
        2. Логгирует результат выполнения команды.

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """
    try:
        bot.reply_to(message = message, text= f'ID этого чата: {message.chat.id}')
        L.info(command = 'chatid', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended')
    except Exception as err:
        bot.reply_to(message = message, text= f'Ошибка: {err}')
        L.error(command = 'chatid', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message=str(err))

    


@bot.message_handler(commands=['autor'])
def send_autor(message):
    """
    Обработчик команды "/autor" для отправки информации об авторе бота.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        None

    Процесс выполнения:
        1. Формирует строку с информацией об авторе, включая ссылку на профиль автора в Telegram и ссылку на репозиторий на GitHub.
        2. Пытается отправить сформированную информацию в чат в виде HTML-разметки.
        3. Обрабатывает возможное исключение, если отправка сообщения не удалась.

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """
    s = f'''
1.<i><a href="tg://user?id={974408314}">...</a></i>
2.<i><a href="tg://user?id={959970015}">...</a></i>
GitHub: <a href="https://github.com/BSNIKYT/SvodkaDZ/tree/main">Repository</a>
'''
    try:
        bot.reply_to(message = message, text= s, parse_mode='html')
        L.info(command = 'autor', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')
    except:pass


@bot.message_handler(commands=['config'])
def config(message):
    """
    Обработчик команды /config для управления настройками бота.

    Args:
        message (telegram.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        Exception: Возникает, если произошла ошибка при выполнении команды.

    Эта функция обрабатывает команду /config для управления различными настройками бота.
    Пользователи с доступом могут выполнять команды для получения информации, создания архива,
    завершения работы бота, получения логов и других операций.

    Команды:
    1. /config --help - Вывести список всех доступных команд.
    2. /config info - Получить информацию о текущих настройках бота.
    3. /config zip - Создать архив с данными бота и отправить его пользователю.
    4. /config shutdown - Завершить работу бота.
    5. /config logs [attribute] - Получить логи бота с опциональным указанием атрибута.
    6. /config usersM - Получить информацию о пользователях авторизованных  в М.
    7. /config ip - Получить информацию о текущем IP-адресе бота.
    8. /config about - Получить информацию об авторизованных пользователях и другие детали.
    9. /config impfiles - Отправить важные файлы (например, конфигурацию) пользователю.

    Note:
        Для выполнения некоторых команд требуется приватный чат с ботом.

    Example:
        Пример использования:
        ```
        /config --help
        ```

    """
    text = message.text.replace(f'@{bot.get_me().username}','')
    all_config_commands = '''Список всех команд:
/config --help
/config info
/config zip
/config shutdown
/config logs [attribute]
/config usersM
/config ip
/config about
/config impfiles
/config is_school_day
/config cmd [attribute]
'''
    if message.from_user.id in C.access_users:
        if text != '/config':
            try:
                command = text.split(' ')[1]
                
                if command == '--help':
                    bot.reply_to(message = message, text= all_config_commands, parse_mode='html')
                    L.info(command = 'config help', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')
                elif command == 'status':
                    send_status_M(message)
                elif command == 'info':
                    send_condig_info(message)
                elif command == 'zip':
                    send_zip(message)
                elif command == 'is_school_day':
                    send_bool_is_school_day(message)
                elif command == 'shutdown':
                    send_shutdown(message)
                elif command == 'cmd':
                    send_console(message, text)
                elif command == 'logs':
                    send_logs(message, text)
                elif command == 'usersM':
                    if message.chat.type == 'private':
                        if 'access_users' in C.access_user_prems[f'{message.from_user.id}']:
                            text_ = get_information_about_M(M)
                            bot.reply_to(message = message, text= text_, parse_mode='html')
                            L.info(command = 'config usersM', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')
                        else:
                            on_error_in_code(message, 'Вы не имеете доступа к этой команде!')
                            L.error(command = 'config usersM', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы не имеете доступа к этой команде!', code = 403, error_message='forbidden')
                    else:
                        on_error_in_code(message, 'Эту команду нужно прописывать в лс с ботом!')
                        L.error(command = 'config usersM', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Эту команду нужно прописывать в лс с ботом!', code = 7, error_message='no private error')

                elif command == 'stopbot':
                    send_stop_bot(message)
                elif command == 'ip':
                    text_ = get_ip_info()
                    bot.reply_to(message = message, text= text_, parse_mode='html')
                    L.info(command = 'config ip', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')
                    
                elif command == 'about':
                    U1Name, U2Name = *M.all_names[0], *M.all_names[1]
                    data = f'''    Авторизован как:
        1. <code>{U1Name}</code>
        2. <code>{U2Name}</code>
        
        Подробнее:
        /config usersM'''
                    data = data + '\n' + send_local_data()
                    
                    bot.reply_to(message = message, text= data, parse_mode='html')
                    L.info(command = 'config about', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')
                elif command == 'impfiles':
                    if 'config' in C.access_user_prems.get(f'{message.from_user.id}'):
                        with open("main.py",'rb') as myzip:bot.send_document(chat_id=message.chat.id, document=myzip, caption='Главный файл')
                        with open("config.json",'rb') as myzip:bot.send_document(chat_id=message.chat.id, document=myzip, caption='Конфиг')
                        with open("data/data.json",'rb') as myzip:bot.send_document(chat_id=message.chat.id, document=myzip, caption='Дата-файл')
                        L.info(command = 'config impfiles', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')
                    else:
                        on_error_in_code(message, f'Вы не имеете доступа к этому разделу!')
                        L.error(command = 'config impfiles', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы не имеете доступа к этому разделу!', code = 403, error_message='forbidden')
                else:
                    on_error_in_code(message, f'Команда конфига не определена!\n\n{all_config_commands}')
                    L.error(command = 'config [attribute]', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Команда конфига не определена!', code = 404, error_message=f'not found {command}')
            
            except IOError as err:
                on_error_in_code(message, str(err), 'True')
                L.critical(command = 'config [attribute]', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'IOError', code = 6, error_message=str(err) + '\n' + traceback.format_exc())

            except TelebotAccessExit as err:raise TelebotAccessExit(err)
            except Exception as err:
                on_error_in_code(message, str(err), 'True')
                L.critical(command = 'config [attribute]', autor_log= f'{message.chat.id}.{message.from_user.id}', text = text, code = 0, error_message=str(err) + '\n' + traceback.format_exc())
                
        else:
            on_error_in_code(message, f'Команда конфига не определена!\n\n{all_config_commands}')
            L.error(command = 'config [attribute]', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Команда конфига не определена!', code = 404, error_message=f'not found {text}')
    else:
        on_error_in_code(message, f'Вы не имеете доступа к этой команде!')
        L.error(command = 'config', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы не имеете доступа к этой команде!', code = 403, error_message='forbidden')


def send_status_M(message):
    if message.from_user.id in C.access_users:
        U1Name, U2Name = *M.all_names[0], *M.all_names[1]
        statuses = M.all_statuses
        text = f'''
<b>{U1Name}</b>
    Student Profile Data StatusCode: <code>{statuses[0][0]}</code>
    Userinfo StatusCode: <code>{statuses[0][1]}</code>
    
<b>{U2Name}</b>
    Student Profile Data StatusCode: <code>{statuses[1][0]}</code>
    Userinfo StatusCode: <code>{statuses[1][1]}</code>
        '''
        bot.reply_to(message = message, text= text, parse_mode='html')
    else:
       on_error_in_code(message, f'Вы не имеете доступа к этой команде!')
       L.error(command = 'config info', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы не имеете доступа к этой команде!', code = 403, error_message='forbidden')




def send_condig_info(message):
    """
    Обработчик команды "/config" для отправки информации о конфигурации бота в чат пользователя.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        None

    Процесс выполнения:
        1. Проверяет, имеет ли отправитель доступ к данной команде.
        2. Формирует текст с информацией о конфигурации, включая токены, доступные чаты, пользователей с доступом и настройки времени рассылки.
        3. Создает объект InlineKeyboardMarkup для отправки встроенной клавиатуры.
        4. Проверяет наличие привилегий у пользователя и, если они есть, добавляет соответствующие кнопки для редактирования.
        5. Отправляет сформированный текст и клавиатуру в чат пользователя.
        6. В случае отсутствия доступа пользователя к команде, отправляет сообщение об ошибке.

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """
    if message.from_user.id in C.access_users:
        text = f'''
<b>КОНФИГ</b>

<b><tg-emoji emoji-id="5368324170671202286">🚩</tg-emoji> Токен МЭШ:</b>
    {(f'<code>{C.mech_token}</code>'if message.from_user.id == 974408314 else 'https://vk.cc/ctjHUs') if message.chat.type == 'private' else "ЗАСЕКРЕЧЕНО"}
    
<b><tg-emoji emoji-id="5368324170671202286">🚩</tg-emoji> Токен Telegram:</b> 
    {f'            <code>{C.telegram_token}</code>' if message.chat.type == 'private' else "ЗАСЕКРЕЧЕНО"}'''
        text2 = '''
<tg-emoji emoji-id="5368324170671202286">🚩</tg-emoji> Доступные рабочие чаты:'''
        for discussion_id in C.access_discussions:
                text2 = text2 + f'''
            <i><code>{discussion_id}</code></i>'''
        
        text3 = '''
<b><tg-emoji emoji-id="5368324170671202286">🚩</tg-emoji> У кого есть доступ к конфигу:</b>'''
        for user_id_ in C.access_users:
            try:
                user = bot.get_chat_member(user_id=user_id_, chat_id=message.chat.id).user.full_name
            except telebot.apihelper.ApiTelegramException as err:
                if 'Bad Request: user not found' in str(err):
                    msg = 'В ГРУППЕ'
                else:msg = str(err).replace("A request to the Telegram API was unsuccessful. Error code: 400. Description: ", "")
                user = f'ОШИБКА ({msg})'
            text3 = text3 + f'''
                <i><a href="tg://user?id={user_id_}">{user}</a></i> ({user_id_})'''
        
        text4 = f'''
<b><tg-emoji emoji-id="5368324170671202286">🚩</tg-emoji> Время отправления свод{'ок' if len(C.sending_post)>1 else 'ки'}:</b>
            Утро: <code>{C.sending_post['morning']}</code>
            Вечер: <code>{C.sending_post['evening']}</code>
<b><tg-emoji emoji-id="5368324170671202286">🚩</tg-emoji> Погода:</b>
            Язык: <code>{C.weather['weather_language']}</code>
            Город: <code>{C.weather['city']}</code>

'''
        sended = text + text2 + text3 + text4
        
        mark_send = InlineKeyboardMarkup()
        
        if C.access_user_prems.get(f'{message.from_user.id}') != None:
            mark_send = InlineKeyboardMarkup()
            
            if 'token' in C.access_user_prems.get(f'{message.from_user.id}'):
                mark_send.add(types.InlineKeyboardButton(text=f'✅ Token МЭШ', callback_data=f'token-m'), InlineKeyboardButton(text=f'✅ Token Telegram', callback_data=f'token-t'),)
            else:
                mark_send.add(types.InlineKeyboardButton(text=f'❌ Token МЭШ'), InlineKeyboardButton(text=f'❌ Token Telegram'))
            
            if 'sending_post' in C.access_user_prems[f'{message.from_user.id}']:
                mark_send.add(types.InlineKeyboardButton(text=f'✅ Edit Morning', callback_data=f'senler-morning'), InlineKeyboardButton(text=f'✅ Edit Evening', callback_data=f'senler-evening'))
            else:
                mark_send.add(types.InlineKeyboardButton(text=f'❌ Edit Morning'), InlineKeyboardButton(text=f'❌ Edit Evening'))
            
            if 'other' in C.access_user_prems[f'{message.from_user.id}']:
                mark_send.add(types.InlineKeyboardButton(text=f'✅ Weather lang', callback_data=f'weather-lang'), InlineKeyboardButton(text=f'✅ Weather City', callback_data=f'weather-city'))
            else:
                mark_send.add(types.InlineKeyboardButton(text=f'❌ Weather lang'), InlineKeyboardButton(text=f'❌ Weather City'))
            
            L.info(command = 'config info', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')
            bot.reply_to(message = message, text= sended, parse_mode='html', reply_markup = mark_send)
        else:
            bot.reply_to(message = message, text= sended, parse_mode='html')
        L.info(command = 'config info', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')

    else:
       on_error_in_code(message, f'Вы не имеете доступа к этой команде!')
       L.error(command = 'config info', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы не имеете доступа к этой команде!', code = 403, error_message='forbidden')

import os


def send_shutdown(message):
    """
    Обработчик команды "/shutdown" для выключения операционной системы.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        None

    Процесс выполнения:
        1. Проверяет, имеет ли отправитель доступ к данной команде.
        2. Определяет операционную систему и выполняет соответствующую команду для выключения.
        3. Отправляет ответ в чат пользователя об успешном выполнении команды.
        4. В случае отсутствия доступа пользователя к команде, отправляет сообщение об ошибке.

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """
    if message.from_user.id in C.access_users:
        
        system_platform = platform.system()
        def send_CHUTDOWN(system_platform):
            if system_platform == 'Windows':
                os.system(f'shutdown /s /t 30 /c "{message.from_user.first_name} {message.from_user.last_name} запустил выключение копьютера."')  # Выключение Windows
                bot.reply_to(message = message, text= f'Успех!')
                L.info(command = 'config shutdown', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'OS: {system_platform}')
            elif system_platform == 'Linux' or system_platform == 'Darwin':
                os.system('sudo shutdown -h now')  # Выключение Linux или Mac
                bot.reply_to(message = message, text= f'Успех!')
                L.info(command = 'config shutdown', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'OS: {system_platform}')
            else:
                print(f"Unsupported operating system: {system_platform}")
                on_error_in_code(message, f'Выключение операционной системы не поддерживается:\n{system_platform}')
                L.error(command = 'config shutdown', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Выключение операционной системы не поддерживается', code = 404, error_message=f'{system_platform} (not Windows, Linux, Mac)')
        def Q(message):
            if (message.text != 'Отмена') or (message.text != '/cancel'):
                if message.text.lower() in [ 'Да'.lower(), 'Yes'.lower(), 'OK'.lower()]:send_CHUTDOWN(system_platform)     
                else:bot.reply_to(message = message, text = 'Вы отменили действие.')
            else:bot.reply_to(message = message, text = 'Вы отменили действие.')
                
        bot.register_next_step_handler(bot.reply_to(message=message,  text = 'Вы уверены?', parse_mode = 'html'), Q)
    
    else:
        on_error_in_code(message, f'Вы не имеете доступа к этой команде!')
        L.error(command = 'config shutdown', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы не имеете доступа к этой команде!', code = 403, error_message='forbidden')

def send_stop_bot(message):
    """
    Обработчик команды "/config stopbot" для выключения операционной системы.

    Args:
        message (telebot.types.Message): Объект сообщения от пользователя.

    Returns:
        None

    Raises:
        None

    Процесс выполнения:
        1. Проверяет, имеет ли отправитель доступ к данной команде.
        2. Определяет операционную систему и выполняет соответствующую команду для выключения.
        3. Отправляет ответ в чат пользователя об успешном выполнении команды.
        4. В случае отсутствия доступа пользователя к команде, отправляет сообщение об ошибке.

    Примечание:
        - Дополнительные комментарии в коде могут быть добавлены для более подробного объяснения логики работы.
    """
    if message.from_user.id in C.access_users:

        try:
            bot.reply_to(message = message, text= f'Успех!')
            L.info(command = 'config stopbot', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully stopped')
            raise TelebotAccessExit(f'{message.from_user.id}')
        except IOError as err:
                on_error_in_code(message, str(err), 'True')
                L.critical(command = 'config stopbot', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'IOError', code = 6, error_message=str(err) + '\n' + traceback.format_exc())
        except TelebotAccessExit as err:raise TelebotAccessExit(err)
        except Exception as err:
                on_error_in_code(message, str(err), 'True')
                L.critical(command = 'config stopbot', autor_log= f'{message.chat.id}.{message.from_user.id}', text = '', code = 0, error_message=str(err) + '\n' + traceback.format_exc())
    else:
        on_error_in_code(message, f'Вы не имеете доступа к этой команде!')
        L.error(command = 'config stopbot', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы не имеете доступа к этой команде!', code = 403, error_message='forbidden')
           

def send_message_morning(bot):
    """
    Функция для отправки утренней сводки.

    Параметры:
    - bot: Объект бота TeleBot.

    Процесс выполнения:
    1. В бесконечном цикле проверяет текущее время и ожидает, пока не совпадет с утренним временем отправки.
    2. Получает информацию о домашнем задании и погоде.
    3. Формирует текст сообщения и отправляет его в доступные чаты с помощью бота.
    4. Записывает информацию о выполнении в лог.

    Примечание:
    - Использует отдельный поток для выполнения, чтобы не блокировать основной поток бота.

    """
    print(f"Запуск займера утренней сводки ({C.sending_post['morning']}) ...")
    while True:
        while str(time.strftime("%H:%M:%S", time.localtime())) != C.sending_post['morning']:time.sleep(1)
        if is_school_day():
            
            homework_info = M.get_homework_by_date(M.stat_now_date())
            
            try:
                from modules.weather import weather
                weather_info = f'''
                
    📋 Сводка по погоде:
    {weather.get_weather(Config=C, index=2)}'''

            except Exception as e:
                weather_info = f'{e}'
                SEND_TIME_LOGGER.critical(command = 'send_message_morning', autor_log= f'console', text = 'weather module error in message_morning', code = 0, error_message=str(e))
            
            try:
                from modules.functions import days_and_weeks_until_targetS
                info_events = f'''
{days_and_weeks_until_targetS()}'''
            except Exception as e:
                info_events = f'{e}'
                SEND_TIME_LOGGER.critical(command = '_', autor_log= f'console', text = 'events module error in message_evening', code = 0, error_message=str(e) + '\n' + traceback.format_exc())   
                
                
            info = f'{homework_info}\n{"-"*100}\n{info_events}\n\n{"-"*100}{weather_info}'
            def send_m(chatid_, text_):
                try:
                    bot.send_message(chat_id = chatid_, text = text_, parse_mode = 'html', reply_markup = send_custom_keyboard(F, str(datetime_.now()).split(' ')[0]))
                    SEND_TIME_LOGGER.info(command = 'send_message_morning', autor_log= f'console', text = f'Успешно отправлено в {chatid_} !')
                except telebot.apihelper.ApiTelegramException as err:
                    SEND_TIME_LOGGER.critical(command = 'send_message_morning', autor_log= f'console', text = 'send_m func error in message_morning', code = 1, error_message=str(err))
                except Exception as err:
                    SEND_TIME_LOGGER.critical(command = 'send_message_morning', autor_log= f'console', text = 'send_m func error in message_morning', code = 0, error_message=str(err))
                    
            if len(C.access_discussions) > 0:
                if len(C.access_discussions) == 1:
                    send_m(C.access_discussions, info)
                else:
                    for id_ in C.access_discussions:
                        send_m(id_, info)
                print(f'[{str(time.strftime("%H:%M:%S", time.localtime()))}] Запуск вечерней рассылки...')
        
        else:
            SEND_TIME_LOGGER.info(command = '_', autor_log= f'send_message_morning', text = f'Дата {datetime_.now(timezone(timedelta(hours=3))).strftime("%Y-%m-%d %H-%M-%S")} является не рабочей, рассылка отменена.')
        time.sleep(5)


def send_message_evening(bot):
    """
    Функция для отправки вечерней сводки.

    Параметры:
    - bot: Объект бота TeleBot.

    Процесс выполнения:
    1. В бесконечном цикле проверяет текущее время и ожидает, пока не совпадет с вечерним временем отправки.
    2. Получает информацию о домашнем задании и погоде на следующий день.
    3. Формирует текст сообщения и отправляет его в доступные чаты с помощью бота.
    4. Записывает информацию о выполнении в лог.

    Примечание:
    - Использует отдельный поток для выполнения, чтобы не блокировать основной поток бота.

    """
    print(f"Запуск займера вечерней сводки ({C.sending_post['evening']}) ...")
    while True:
        while str(time.strftime("%H:%M:%S", time.localtime())) != C.sending_post['evening']:time.sleep(1)
        if is_school_day():
                
            homework_info = M.get_homework_by_date(M.stat_next_date(M.stat_now_date()))
            
            try:
                from modules.weather import weather
                weather_info = f'''
                
📋 Сводка по погоде:
{weather.get_weather(Config=C, index=2)}'''

            except Exception as e:
                weather_info = f'{e}'
                SEND_TIME_LOGGER.critical(command = '_', autor_log= f'console', text = 'weather module error in message_evening', code = 0, error_message=str(e) + '\n' + traceback.format_exc())
            
            try:
                from modules.functions import days_and_weeks_until_targetS
                info_events = f'''
{days_and_weeks_until_targetS()}'''
            except Exception as e:
                info_events = f'{e}'
                SEND_TIME_LOGGER.critical(command = '_', autor_log= f'console', text = 'events module error in message_evening', code = 0, error_message=str(e) + '\n' + traceback.format_exc())   
                
                
            info = f'{homework_info}\n{"-"*100}\n{info_events}\n\n{"-"*100}{weather_info}'
            def send_m(chatid_, text_):
                try:
                    bot.send_message(chat_id = chatid_, text = text_, parse_mode = 'html', reply_markup = send_custom_keyboard(F, str(datetime_.now()).split(' ')[0]))
                    SEND_TIME_LOGGER.info(command = 'send_message_evening', autor_log= f'console', text = f'Успешно отправлено в {chatid_} !')
                except telebot.apihelper.ApiTelegramException as err:
                    SEND_TIME_LOGGER.critical(command = 'send_message_evening', autor_log= f'console', text = 'send_m func error in message_morning', code = 1, error_message=str(err))
                except Exception as err:
                    SEND_TIME_LOGGER.critical(command = 'send_message_evening', autor_log= f'console', text = 'send_m func error in message_morning', code = 0, error_message=str(err))

            if len(C.access_discussions) > 0:
                if len(C.access_discussions) == 1:
                    send_m(C.access_discussions, info)
                else:
                    for id_ in C.access_discussions:
                        send_m(id_, info)
                print(f'[{str(time.strftime("%H:%M:%S", time.localtime()))}] Запуск вечерней рассылки...')
        else:SEND_TIME_LOGGER.info(command = '_', autor_log= f'send_message_evening', text = f'Дата {datetime_.now(timezone(timedelta(hours=3))).strftime("%Y-%m-%d %H-%M-%S")} является не рабочей, рассылка отменена.')
        time.sleep(5)



def pull_new_loor_to_send_dz(bot):
    """
    Функция для запуска двух потоков отправки сводок (утренней и вечерней).

    Параметры:
    - bot: Объект бота TeleBot.

    Процесс выполнения:
    1. Запускает два отдельных потока (утренней и вечерней сводок) с использованием функций send_message_morning и send_message_evening.

    Примечание:
    - Используется для старта отправки сводок в определенные моменты времени.
    - Логирует стартовую информацию в лог.

    """
    SEND_TIME_LOGGER.info(command = '_', autor_log= f'console', text = 'STARTING ALL THREADS')
    Thread(target=send_message_morning, args=(bot,), name='send_message_morning').start()
    Thread(target=send_message_evening, args=(bot,), name='send_message_evening').start()
pull_new_loor_to_send_dz(bot)



     
calendar = {1 : 31, 2 : 28, 3 : 31, 4 : 30, 5 : 31,6 : 30, 7 : 31, 8 : 31, 9 : 30, 10: 31, 11: 30, 12: 31}
def out_formated_data(data):
    """
    Функция для форматирования введенной даты и проверки ее корректности.

    Параметры:
    - data: Строка, представляющая введенную дату в формате [ДЕНЬ]-[МЕСЯЦ]-[ГОД].

    Возвращает:
    - BOOL: Булево значение, указывающее на успешность форматирования даты.
    - return_data: Строка, представляющая отформатированную дату в формате YYYY-MM-DD. В случае ошибки, возвращает 'Falure'.

    Процесс выполнения:
    1. Проверяет длину строки без дефисов. Если длина равна 8 или 6, продолжает выполнение.
    2. Пытается разделить строку на компоненты (день, месяц, год) и форматирует их.
    3. Проверяет корректность дня, месяца и года. Если что-то неверно, возвращает 'Falure'.
    4. Возвращает отформатированную дату и булево значение в зависимости от успешности операции.

    Примечание:
    - Возвращаемые значения в формате (BOOL, return_data).
    - В случае ошибки, возвращается 'Falure'.

    Пример использования:
    - BOOL, return_data = out_formated_data("01-01-24")
    - Если BOOL равно True, return_data равно "2024-01-01".
    - Если BOOL равно False, return_data равно "Falure".
    """
    BOOL = True

    if (len(''.join(data.split('-'))) == 8) or (len(''.join(data.split('-'))) == 6):

        try:

            splt = data.split('-')

            day, month, year = splt[0], splt[1], splt[2]

            if int(month) < 10:month = f'0{int(month)}'
            if int(day) < 10:day = f'0{int(day)}'
            if int(year) < 10:year = f'0{int(year)}'

            yearN, monthN, dayN = None, None, None
            if (len(''.join(year.split())) == 4) or (len(''.join(year.split())) == 2): 

                if len(''.join(year.split())) == 4:
                    yearN = year
                elif len(''.join(year.split())) == 2:
                    yearN = int(f"20{year}")
                
                if len(''.join(month.split())) == 2:
                    monthN = month
                if len(''.join(day.split())) == 2:
                    dayN = day


            if (yearN == None) or (monthN == None) or (dayN == None):
                BOOL = False
                return_data = 'Falure'  
            elif int(dayN) <= calendar[int(monthN)]:
                if int(monthN) < 10:monthN = f'0{int(monthN)}'
                if int(dayN) < 10:dayN = f'0{int(dayN)}'
                return_data = f'{yearN}-{monthN}-{dayN}' 
            else:
                BOOL = False
                return_data = 'Falure'

        except Exception as err:
            MODULE.error(command = 'out_formated_data', autor_log= f'code', text = 'Exception', code = 0, error_message=str(err))
            BOOL = False
            return_data = 'Falure' 
      
    else:

        BOOL = False
        return_data = 'Falure'

    return BOOL, return_data






@bot.message_handler(content_types=['document'])
def handle_document(message):
    H.handle_document(message)

@bot.message_handler(content_types=['photo'])
def handle_photo(message):
    H.handle_photo(message)

@bot.message_handler(content_types=['animation'])
def handle_animation(message):
    H.handle_animation(message)

@bot.message_handler(content_types=['audio'])
def handle_audio(message):
    H.handle_audio(message)

@bot.message_handler(content_types=['video'])
def handle_video(message):
    H.handle_video(message)

@bot.message_handler(content_types=['sticker'])
def handle_sticker(message):
    H.handle_sticker(message)

@bot.message_handler(content_types=['contact'])
def handle_contact(message):
    H.handle_contact(message)
    
    
    

import json
@bot.message_handler(content_types=['new_chat_members'])
def new_chat_members(message):
    EVENT_LOGGER.info(command = 'new_chat_members', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'''{message.json['from']['first_name']} ({message.json['from']['id']})  added  {message.json['new_chat_participant']['first_name']} ({message.json['new_chat_participant']['id']})''')
    if message.json['new_chat_participant']['is_bot'] == True:
        if message.json['new_chat_participant']['id'] == bot.get_me().id:
            add_new_member_in_data(message)
            
    # json.dump(message.json, open('5565543.json', 'w'), indent=4, default=list)
    
@bot.message_handler(commands=['new_log_discussion'])
def new_log_discussion_def(message):
    if message.from_user.id in C.access_users:
        out, err = S.add_new_log_discussion(message.chat.id)
        if out == 'OK':
            bot.reply_to(message, 'Успех!')
        else:
            on_error_in_code(message, str(err), 'True')
    else:
        on_error_in_code(message, f'Вы не имеете доступа к этой команде!')
        L.error(command = 'new_log_discussion', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы не имеете доступа к этой команде!', code = 403, error_message='forbidden')




CONTENT_TYPES = ["text", "audio", "document", "photo", "sticker", "video", "video_note", "voice", "location", "contact",
                 "new_chat_members", "left_chat_member", "new_chat_title", "new_chat_photo", "delete_chat_photo",
                 "group_chat_created", "supergroup_chat_created", "channel_chat_created", "migrate_to_chat_id",
                 "migrate_from_chat_id", "pinned_message"]


@bot.message_handler(commands=['help', 'команды'])
def help_def(message):
        info = ''
        for com in bot.get_my_commands():
            info = info + f'''
/{com.command} - {com.description}'''
        bot.reply_to(message, f'''
Commands: 
{info}          
    ''')

def get_all_administrators_in_chat(message):
    """
    Функция для получения списка администраторов чата.

    Параметры:
    - message: Объект сообщения от пользователя (тип Message).

    Возвращает:
    - Строку, содержащую информацию о всех администраторах чата в формате HTML.

    Процесс выполнения:
    1. Используя метод бота get_chat_administrators, получает список администраторов чата.
    2. Формирует строку, включающую информацию о каждом администраторе, в виде HTML-текста.
    3. Возвращает сформированную строку с информацией о всех администраторах.

    Примечание:
    - Информация о каждом администраторе включает в себя его статус, имя, фамилию, username (если есть),
      идентификатор пользователя и отметку "БОТ", если администратор является ботом.
    - Информация оформлена в виде списка с использованием звездочек для обозначения статуса администратора.

    Пример использования:
    - Администратор отправляет боту команду "/get_admins".
    - Бот возвращает информацию о всех администраторах чата в формате HTML.

    """
    sts = '''
'''
    owner_ = ''
    admins_=''
    for _ in bot.get_chat_administrators(message.chat.id):
        user_id = _.user.id
        is_bot = _.user.is_bot
        name1 = _.user.first_name
        username=_.user.username
        last_name = _.user.last_name
        status = _.status
        

        if str(name1) != 'None':
            name = name1
        else:
            if str(last_name) != 'None':
                name = last_name
            else:name == f'@{username}'
        
        if status == 'creator':status_ = '⭐⭐⭐'
        elif status == 'administrator':status_ = '⭐⭐'
        else:status_ = '⭐'
        
        if status == 'creator': owner_= f'''
        {status_} <a href="tg://user?id={user_id}">{name} {(last_name if last_name != 'None' else '')} {('(БОТ)' if is_bot else '')}</a>   <code>{user_id}</code>'''
        else:
            admins_ = admins_ +  f'''
        {status_} <a href="tg://user?id={user_id}">{name} {(last_name if str(last_name) != 'None' else '')} {('(БОТ)' if is_bot else '')}</a>   <code>{user_id}</code>'''
    
    sts = f'''{owner_}{admins_}'''
        
    return sts


@bot.message_handler(commands=['admins', 'админы'])
def all_users_in_chat_mention(message):
    if message.chat.type != 'private':
        bot.reply_to(message = message, text= get_all_administrators_in_chat(message), parse_mode = 'html')
        L.info(command = 'admins', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')
    else:
        on_error_in_code(message, 'Эту команду нужно прописывать в беседе с ботом!')
        L.error(command = 'all', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Эту команду нужно прописывать в беседе с ботом!', code = 7, error_message='private error')

    
@bot.message_handler(commands=['test'])
def test_message(message):
    print(bot.get_chat_member_count(message.chat.id))
    print(bot.get_chat_members_count(message.chat.id))
    L.info(command = 'test', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')
    L.error(command = 'test', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы не имеете доступа к этой команде!', code = 403, error_message='forbidden')

@bot.message_handler(commands=['fuck', 'соси', 'выебать'])
def fuck_mentioned_person(message):
    who = ' '.join(message.text.split()[1:])
    try:
        bot.send_message(message.chat.id, f"да, соси хуй, {who}!")
        bot.delete_message(message.chat.id, message.message_id)
        L.info(command = 'fuck', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfully sended')
    except:print(f"could not fuck ({who})")


@bot.message_handler(commands=['elem', 'chem', 'element', 'описание'])
def chemistry_send(message): 
    data = {"index": [
                "период", "группа+(подгруппа)", "электронная формула", "тип", "высший оксид", "водородное соедининение?", "гидроксид", # строение атома
                "агрегат. состояние", "цвет", "запах", "растворимость", "электропроводность", "теплопроводность", "t плавления", "t кипения", # физ свойства 
                ],

            "li": ["2", "IA", "1s2 2s1", "металл", "Li2O", "хз", "LiOH",
                   "Твёрдое", "Серебристо-белый", "нет", "нет", "хз", "хз", "Низкая", "Высокая"],
            "na": ["3", "IA", "1s2 2s2 2p6 3s1", "металл", "Na2O", "хз", "NaOH",
                   "Твёрдое", "Серебристо-белый", "нет", "нет", "хз", "хз", "Низкая", "Высокая"],
            "k": ["4", "IA", "1s2 2s2 2p6 3s2 3p6 4s1", "металл", "K2O", "хз", "KOH",
                   "Твёрдое", "Серебристо-белый", "нет", "нет", "хз", "хз", "Низкая", "Высокая"],
            "be": ["2", "IIA", "1s2 2s2", "металл", "BeO", "хз", "Be(OH)2",
                   "Твёрдое", "Серебристо-белый", "нет", "нет", "хз", "хз", "Высокая", "Высокая"],
            "mg": ["3", "IIA", "1s2 2s2 2p6 3s2", "металл", "MgO", "хз", "Mg(OH)2",
                   "Твёрдое", "Серебристо-белый", "нет", "нет", "хз", "хз", "Высокая", "Высокая"],
            "ca": ["4", "IIA", "1s2 2s2 2p6 3s2 2p6 4s2", "металл", "cao", "хз", "ca(oh)2",
                   "Твёрдое", "Серебристо-белый", "нет", "нет", "хз", "хз", "Высокая", "Высокая"],
            "al": ["3", "IIIA", "1s2 2s2 2p6 3s2 3p1", "металл", "Al2O3", "хз", "Al(OH)3",
                   "Твёрдое", "Серебристо-белый", "нет", "нет", "хорошая", "хз", "Высокая", "Высокая"],

            "c": ["2", "IVA", "1s2 2s2 2p2", "Неметалл", "CO2", "CH4", "хз",
                  "Твёрдое", "разный (Алмаз, уголь, графит и т.п.)", "нет", "нет", "нет", "Слабая", "Высокая", "Очень высокая"],
            "si": ["3", "IVA", "1s2 2s2 2p6 3s2 3p2", "Неметалл", "SiO2", "SiH4", "хз",
                   "Твёрдое", "Коричневый или тёмно-серый", "нет", "нет", "нет", "Средняя", "Высокая", "Очень высокая"],
            "n": ["2", "VA", "1s2 2s2 2p2", "Неметалл", "N2O5", "NH3", "",
                  "Газообразное", "Прозрачный", "нет", "Малорастворим", "нет", "хз", "Ооооооооочень низкая", "Очень Низкая"],
            "p": ["3", "VA", "1s2 2s2 2p6 3s2 3p3", "Неметалл", "P2O5", "PH3 ???", "хз",
                  "Твёрдое", "Желтый/Белый/Красный/Чёрный (Аллотропный)", "хз", "нет", "нет", "нет", "Низкая", "Низкая"],
            "o": ["2", "VIA", "1s2 2s2 2p4", "Неметалл", "хз", "H2O2", "HOH", 
                  "Газообразное", "Прозрачный", "нет", "Слаборастворим", "нет", "слабая", "Оооооочень низкая", "Очень низкая"],
            "s": ["3", "VIA", "1s2 2s2 2p6 3s2 3p4", "Неметалл", "SO3", "H2S", "хз", 
                  "Твёрдое", "Желтый", "тухлые яйца", "Нерастворима", "нет", "слабая", "Низкая", "Средняя"],
            "f": ["2", "VIIA", "1s2 2s2 2p5", "неметалл", "хз", "HF", "хз",
                  "Газообразное", "бледно-жёлтого цвета", "резкий запах", "нет", "хз", "хз", "низкая", "низкая"],
            "cl": ["3", "VIIA", "1s2 2s2 2p6 3s2 3p5", "неметалл", "Cl2O7", "HCl", "HClO4",
                   "Газообразное", "желтовато-зелёного цвета", "резким запахом", "слабо растворяется в воде", "хз", "хз", "низкая", "низкая"]
    }
    data_metal =  {
            "index": ["реакции с галлогенами", "реакции с кислородом", "реакции с водородом", "реакции с водой", "реакции с кислотой", "доп. реакции"],

            "li": ["2Li + Cl2 -> 2LiCl", "4Li + O2 -> 2Li2O", "2Li + H2 -> 2LiH", "2Li + 2H20 -> 2LiOH + H2", "2Li + 2HCl -> 2LiCl + H2", "хз"],
            "na": ["2Na + Cl2 -> 2NaCl", "2Na + O2 -> Na2O2", "2Na + H2 -> 2NaH", "2Na + 2H20 -> 2NaOH + H2", "2Na + 2HCl -> 2NaCl + H2", "хз"],
            "k": ["2K + Cl2 -> 2KCl", "Образует различные соединения: K2O, K2O2, K2O4", "2K + H2 -> 2KH", "2K + 2H20 -> 2KOH + H2", "2K + 2HCl -> 2KCl + H2", "хз"],
            "be": ["Be + Cl2 -> BeCl2", "2Be + O2 -> 2BeO",  "Не реагирует", "Не реагирует", "Be + 2HCl -> BeCl2 + H2", "Be + 2NaOH + 2H2O -> Na2[Be(OH)4] + H2"],
            "mg": ["Mg + Cl2 -> MgCl2", "2Mg + O2 -> 2MgO", "Mg + H2 -> MgH2", "Mg + H2O -> MgO + H2", "Mg + 2HCl -> MgCl2 + H2", "-----------"],
            "ca": ["Ca  + Cl2 -> CaCl2", "2Ca + O2 -> 2CaO", "Ca + H2 -> CaH2", "Ca + 2H2O -> Ca(OH)2 + H2", "Ca + 2HCl -> CaCl2 + H2", "хз"],
            "al": ["2Al + 3Cl2 -> 2AlCl3", "4Al + 3O2 -> 2Al2O3", "Не реагирует", "2Al + 6H2O -> 2Al(OH)3 + 3H2", "2Al + 6HCL -> 2AlCl3 + 3H2",
                   "2Al + 2NaOH + 6H2O -> 2Na[Al(OH)4] + 3H2"],
    }
    data_nonmetal =  {
            "index": ["Окислительные свойства", "Восстановительные свойства"],

            "c": ["2C + Ca -> CaC2 \n    C + 2H2 -> CH4", "C + O2 -> CO2 \n    2C + O2 -> 2CO \n    C + 2CuO -> CO2 + 2Cu"],
            "si": ["Si  + 2Mg -> Mg2Si", "Si + 2F2 -> SiF4\n    Si + O2 -> SiO2\n    Si + 2 NaOH + H2O -> Na2SiO3 + 2H2"],
            "n": ["3Mg + N2 -> Mg3N2\n    2Al + N2 -> 2AlN\n    N2 + 3H2 -> 2NH3", "N2 + O2 -> 2NO"],
            "p": ["3Ca + 2P -> Ca3P2", "4P + 5O2 -> 2P2O5\n    2P + 3S -> P2S3\n    6P + 5KCLO3 -> 5KCl + 3P2O5"],
            "o": ["2Mg   + O2 -> 2MgO\n    C + O2 -> CO2\n    4P + 5O -> 2P2O5\n    2H2 + O2 -> 2H2O", "2F2 + 2H2O -> 4HF + O2"],
            "s": ["2Na + S -> Na2S\n    2Al + 3S -> Al2S3\n    H2 + S -> H2S", "S + O2 -> SO2 \n    S + 3F2 -> SF6"],
            "f": ["2F2 + Xe -> XeF4\n    2F2 + 2H2O -> 4HF + O2\n    F2 + H2 -> 2HF", "хз"],
            "cl": ["2Na + Cl2 -> 2NaCl\n    2Fe + 3Cl2 -> 2FeCl3\n    H2 + Cl2 -> 2HCl\n    2NaI + Cl2 -> 2NaCl + I2", "3F2 + Cl2 -> 2ClF3"]
    }
    all_ = '\n'.join([f'<code>/elem {i.title()}</code>' for i in data if str(i) != 'index'])
    elem = f"\nСписок всех аттрибутов:\n{all_}"
    try:
        element = message.text.split()[1].lower()
        if element not in data:
            bot.reply_to(message = message, text= f'Недопустимый элемент!\n\n{elem}')
            L.error(command = 'elem [attribute]', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Команда конфига не определена!', code = 404, error_message=f'not found {element}')
        elif element == '--help':
            bot.reply_to(message = message, text= elem, parse_mode='html')
            L.info(command = 'elem help', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended')
        else:
            # print([f'{i}:\n    {j}\n' for i, j in zip(data["index"], data[element])])
            ret_str = "".join([f'<b>{i}</b>:\n    <code>{j}</code>\n' for i, j in zip(data["index"], data[element])]) + '\n' + \
                    (lambda __data__: "".join([f'<b>{i}</b>:\n    <code>{j}</code>\n' for i, j in zip(__data__["index"], __data__[element])])) \
                        (data_metal if element in data_metal else data_nonmetal)
            L.info(command = f'elem {element}', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended')
            bot.reply_to(message = message, text= ret_str, parse_mode='html')

    except IndexError as err:
        if 'list index out of range' in str(err):
            bot.reply_to(message=message, text = f'Элемент отсутствует!{elem}', parse_mode='html')
            L.error(command = 'config [attribute]', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Вы должны отправить атрибут!', code = 404, error_message=f'not found {message.text}', parse_mode='html')
    except Exception as err:
        on_error_in_code(message, str(err), 'True')
        L.error(command = 'elem [attribute]', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message= str(err) + '\n' + str(traceback.format_exc()))



def add_new_member_in_data(message):
    if message.chat.type == 'private':
        try:
            S.add_new_member(message, bot)
            MODULE.debug(command = 'S.add_new_member', autor_log= f'{message.chat.id}.{message.from_user.id}', text = '_')
        except Exception as err:
            traceback.print_exc()
            MODULE.error(command = 'S.add_new_member', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message=str(err) + '\n'+ traceback.format_exc())
        
@bot.message_handler(content_types='text')
def message_reply(message):
    """
    Обрабатывает текстовые сообщения от пользователя в чате Telegram.

    Аргументы:
    - message: Объект сообщения от Telegram, который содержит информацию о запросе.

    Пример использования:
        Любое текстовое сообщение в чате Telegram.

    Возвращает:
    - В зависимости от текста сообщения выполняет соответствующие действия.

    Обработка ошибок:
    - В случае ошибки при добавлении нового участника сообщества выводит сообщение об ошибке и логирует исключение.

    Пример использования:
    message_reply(message)

    """
    add_new_member_in_data(message)
    
    MESSAGE_LOGGER.info(command = '_', autor_log= f'{message.chat.id}.{message.from_user.id}', text = message.text)
    if message.text:
        if message.text in  ('хелп', 'помощь', 'commands'):
            help_def()
            
        elif message.text in ('бот', 'Бот'):
            bot.reply_to(message=message, text = f'''На месте ✅''', parse_mode='html')
        
        

        
        
# 0 - Exception
# 1 - telebot.apihelper.ApiTelegramException
# 2 - requests.exceptions.ReadTimeout
# 3 - requests.exceptions.ConnectionError
# 4 - IndexError
# 5 - NotReplyException
# 6 - IOError
# 7 - WeaherConfigEror


class TelebotAccessExit(Exception):pass

def sendM(bot, message, data):
    data = data.replace('<', '_(_').replace('>', '_)_')
    if len(data) > 4095:
        for x in range(0, len(data), 4095):
            bot.send_message(chat_id = message.chat.id, text=f'''<pre><code class="language-python">{data[x:x+4095]}</code></pre>''', parse_mode='html')
            time.sleep(2)

    else:
        bot.reply_to(message, text=f'''Успех!\n<pre><code class="language-python">{data}</code></pre>''', parse_mode='html')


def on_error_in_code(message, text, value = 'False'):
    def is_bot_admin(message, value = 'False'):
        if value == 'True':
            if message.from_user.id in C.access_users:
                try:
                    bot.reply_to(message = message, text= fr'Traceback:<pre><code class="language-python">{str(traceback.format_exc())}</code></pre>', parse_mode='html')
                except:pass
    try:
        bot.reply_to(message = message, text= f'Ошибка!\n<code>{text}</code>', parse_mode='html')
        is_bot_admin(message, value)
    except telebot.apihelper.ApiTelegramException as err:
        err = str(err)
        if 'Too Many Requests' in err:
            err = 'Too Many Requests'
            try:
                bot.reply_to(message = message, text= f'Ошибка!\n<code>{err}</code>', parse_mode='html')
                is_bot_admin(message)
            except Exception as err:
                if 'Too Many Requests' in str(err):
                    print('Слишком много запросов!')

 
        
if __name__ == '__main__':
    print(f'@{bot.get_me().username}')
    print(f'[ {str(time.strftime("%H:%M:%S", time.localtime()))} ]')
    L.info(command = '_', autor_log= f'console', text = 'Code is running...')
    exit_ = 'False'
    
    
    while exit_ == 'False':
        try:
            bot.polling(none_stop=True, interval=0)
        except TelebotAccessExit as err:
            print(f'Пользователь {err} выключил бота')
            exit_ = 'True'
            L.critical(command = 'bot.polling', autor_log= f'host', text = 'TelebotAccessExit', code = 'CUSTOM', error_message=f'Пользователь {err} выключил бота')
            raise TelebotAccessExit(f'Пользователь {err} выключил бота')
        except telebot.apihelper.ApiTelegramException as err:
            L.error(command = 'bot.polling', autor_log= f'console', text = 'telebot.apihelper.ApiTelegramException', code = 1, error_message=str(err) + '\n'+ traceback.format_exc())
        except requests.exceptions.ReadTimeout as err:
            L.error(command = 'bot.polling', autor_log= f'console', text = 'requests.exceptions.ReadTimeout', code = 2, error_message=str(err) + '\n'+ traceback.format_exc())
        except requests.exceptions.ConnectionError as err:
            L.error(command = 'bot.polling', autor_log= f'console', text = 'requests.exceptions.ConnectionError', code = 3, error_message=str(err) + '\n'+ traceback.format_exc())
            check_internet()
        except Exception as err: 
            L.error(command = 'bot.polling', autor_log= f'console', text = 'Exception', code = 0, error_message=str(err) + '\n'+ traceback.format_exc())
