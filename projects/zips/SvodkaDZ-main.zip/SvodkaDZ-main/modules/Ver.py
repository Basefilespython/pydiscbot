import os
import json
from typing import Any
import requests

class Versions():
    def __init__(self, L = None, version_file_path = str(os.path.join(os.getcwd(), 'data', 'application.json'))) -> None:
        self.L = L
        if self.L is None:
            class L_():
                def info(self, command, autor_log, text):pass
            self.L = L_()

        with open(version_file_path) as f:Ldata = json.load(f)['version']
        self.VERSION_MAIN = Ldata.get('version_main')
        self.VERSION_FUNCTIONS = Ldata.get('version_functions')
        self.VERSION_GETDZ = Ldata.get('version_getdz')
        self.VERSION_LOGGER = Ldata.get('version_logger')
        self.VERSION_MECH = Ldata.get('version_mech')
        self.VERSION_WEATHER = Ldata.get('version_weather')
        
        self.VERSION_MAIN, self.VERSION_FUNCTIONS = f'{self.VERSION_MAIN}?main.py', f'{self.VERSION_FUNCTIONS}?functions.py'
        self.VERSION_GETDZ, self.VERSION_LOGGER = f'{self.VERSION_GETDZ}?get_dz.py', f'{self.VERSION_LOGGER}?logger.py'
        self.VERSION_MECH, self.VERSION_WEATHER = f'{self.VERSION_MECH}?mech', f'{self.VERSION_WEATHER}?weather'

    def download_new_file(self, filename):
        pass
        
    def actuall_version(self, version, filename):
        self.L.info(command = '_', autor_log= f'console', text = f'The current version of the script ({filename}) has been found {version}')
        print(f'Actual version {filename}: {version}')
    
    def old_version(self, Sversion, Nversion, filename):
        self.L.info(command = '_', autor_log= f'console', text = f'The outdated version detected {filename} ({Sversion}): --> {Nversion}')
        ch = input(f'The outdated version detected {filename} ({Sversion}): --> {Nversion}\nDownload now? (Y/N)')
        if ch == 'Y':
            self.download_new_file(filename)
        
    
    def get_N_version(self, link):
        error = ''
        try:
            text_ = requests.get(link).text
            if text_ != '404: Not Found':
                nversion = json.loads(text_)["ver"]
            else:
                nversion = 'None'
                error = text_
        except Exception as error_:
            nversion = 'None'
            error = str(error_)
        return nversion, error
    
    def sravnenie_blyat(self, nversion, sversion_):
            sversion = sversion_.split('?')[0]
            s1, s2, s3, n1, n2, n3 = (
            str(sversion).split(".")[0],
            str(sversion).split(".")[1],
            str(sversion).split(".")[2],
            str(nversion).split(".")[0],
            str(nversion).split(".")[1],
            str(nversion).split(".")[2])
            if s1 >= n1:
                if s2 >= n2:
                    if s3 >= n3:self.actuall_version(nversion, sversion_.split('?')[-1])
                    else:self.old_version(sversion, nversion, sversion.split('?')[-1])
                else:self.old_version(sversion, nversion, sversion.split('?')[-1])
            else:self.old_version(sversion, nversion, sversion.split('?')[-1])
    
    def check(self):
        for sversion in [self.VERSION_MAIN, self.VERSION_FUNCTIONS, self.VERSION_GETDZ, self.VERSION_LOGGER, self.VERSION_MECH, self.VERSION_WEATHER]:
            filename = sversion.split('?')[0]
            nversion, error = self.get_N_version(f'https://raw.githubusercontent.com/Basefilespython/pydiscbot/main/projects/ver/SvodkaDZ/{sversion.split("?")[-1].replace(".py", "")}.json')
            if (nversion != 'None') and (sversion.split("?")[0] != 'None'):
                self.sravnenie_blyat(nversion, sversion)
            else:
                if sversion.split("?")[0] == 'None':
                    error = 'Information not found'
                print(f'Error [{sversion.split("?")[0]}][{sversion.split("?")[-1]}]: {error}')
                
    
if __name__ == '__main__':
    V = Versions()
    V.check()
