import os
import sys
import json
import time
import psutil
import socket
import getpass
import calendar
import platform
import requests
import traceback
import subprocess
from functools import wraps
from datetime import datetime
from datetime import date, timedelta
from telebot.types import  InlineKeyboardMarkup, InlineKeyboardButton


def send_command_in_cmd(command):
    out = str(subprocess.run(command, shell=True, capture_output=True, text=True).stdout)
    if out == '':
        out = 'Не отправлено ответа'
    return out

def get_screen_resolution():
    """
    Получает разрешение экрана.

    Возвращает строку с разрешением в формате 'ширина x высота' или сообщение об ошибке, если разрешение не удалось определить.
    """
    if platform.system() == 'Windows' or os.getenv("DISPLAY", default="None") != "None": 
        try:
            import tkinter as tk
            root = tk.Tk()
            width = root.winfo_screenwidth()
            height = root.winfo_screenheight()
            root.destroy()
            info_ = f'{width} × {height}'
        except Exception as err:
            traceback.print_exc()
            info_ = 'Error: {}'.format(err)
    else:
        try:
            size = os.get_terminal_size()
            info_ = f'NO SCREEN\n\tTTY resolution: {size.columns} х {size.lines}'
        except IOError as err:
            info_ = f'IOError: {err}'
    return info_

def get_battery_info():
    status, battery_, time_left = 'Unknown', 'unknown', 'unknown'
    try:
        battery = psutil.sensors_battery()
        status = "Charging" if battery.power_plugged else "Discharging"
        time_left = f"{battery.secsleft / 60:.2f} minutes" if not battery.power_plugged and battery.secsleft != psutil.POWER_TIME_UNKNOWN else None
        # info_str = f"Battery Status: {status}, Battery Percentage: {battery.percent}%, Time left: {time_left}" if time_left else f"Battery Status: {status}, Battery Percentage: {battery.percent}%"
        # info_str = [status, battery.percent, time_left]
        return [status, battery.percent, time_left]
    except Exception as e:
        return [status, battery_, time_left]

def get_system_info():
    """
    Получает информацию о системе.

    Возвращает словарь с различной информацией о системе, такой как OS, версия, процессор, память, диск и т. д.
    """
    
    battery = get_battery_info()
    screen_info = get_screen_resolution()
    system_info = {
        'System': platform.system(),
        'Node Name': platform.node(),
        'Release': platform.release(),
        'Version': platform.version(),
        'Machine': platform.machine(),
        'Processor': platform.processor(),
        'Hostname': socket.gethostname(),
        'IP Address': socket.gethostbyname(socket.gethostname()),
        'Screen Info' : screen_info,
        'CPU Cores': psutil.cpu_count(logical=False),
        'CPU Threads': psutil.cpu_count(logical=True),
        'CPU Usage (%)': psutil.cpu_percent(),
        'RAM Total (MB)': round(psutil.virtual_memory().total / (1024 * 1024), 2),
        'RAM Used (MB)': round(psutil.virtual_memory().used / (1024 * 1024), 2),
        'RAM Free (MB)': round(psutil.virtual_memory().available / (1024 * 1024), 2),
        'Disk Total (GB)': round(psutil.disk_usage('/').total / (1024 ** 3), 2),
        'Disk Used (GB)': round(psutil.disk_usage('/').used / (1024 ** 3), 2),
        'Disk Free (GB)': round(psutil.disk_usage('/').free / (1024 ** 3), 2),
        'Battery Status': battery[0],
        'Battery Percent' : battery[1],
        'Battery TimeLeft' : battery[2]
    }
    return system_info

def send_local_data():
    """
    Отправляет локальные данные.

    Возвращает строку с отформатированной информацией о системе или сообщение об ошибке, если данные не удалось получить.
    """
    try:
        info = get_system_info()
        output = f'''
    <b>System:</b>
        OS: <code>{info['System']}</code>
        Node Name: <code>{info['Node Name']}</code>
        Release: <code>{info['Release']}</code>
        Version: <code>{info['Version']}</code>
        Machine: <code>{info['Machine']}</code>
        Processor: 
    <code>{info['Processor'] if info['Processor'] != '' else "Нет данных"}</code>
        Hostname: <code>{info['Hostname']}</code>
        IP Address: <code>{info['IP Address']}</code>

    <b>CPU:</b>
        Ядра: <code>{info["CPU Cores"]}</code>   
        Логических процессоров: <code>{info["CPU Threads"]}</code>
        Использование (%): <code>{info["CPU Usage (%)"]}</code>
                    
    <b>RAM:</b>                                                         
        Всего (GB): <code>{round(info["RAM Total (MB)"]/1000)}</code>                 
        Использование (%): <code>{round((100*info["RAM Used (MB)"])/info["RAM Total (MB)"], 2)}%</code> 

    <b>User:</b>
        Пользователь: <code>{getpass.getuser()}</code>                                                       
        
    <b>Disk:</b>
        Всего (GB): <code>{info["Disk Total (GB)"]}</code>
        Забито (GB): <code>{info["Disk Used (GB)"]}</code>              
        Использование (%): <code>{round((100*info["Disk Used (GB)"])/info["Disk Total (GB)"], 2)}%</code>

    <b>Screen:</b>
        Resolution: <code>{info["Screen Info"]}</code>
        
    <b>Battery:</b>
        Percent: <code>{info["Battery Status"]}</code>
        Status: <code>{info["Battery Percent"]}</code>
        Time Left: <code>{info["Battery TimeLeft"]}</code>
    '''
    except Exception as err:
        traceback.print_exc()
        output = err

    return output

def get_information_about_M(M):
    M1, M2 = M.get_users()
    output1 = f'''
    <b>User1:</b>
        ID: <code>{M1.id}</code>
        first_name: <code>{M1.first_name}</code>
        middle_name: <code>{M1.middle_name}</code>
        last_name: <code>{M1.last_name}</code>
        birthdate: <code>{M1.birthdate}</code>
        email: <code>{M1.email}</code>
        person_id:<code>{M1.person_id}</code>
        school_id: <code>{M1.school_id}</code>
        age: <code>{M1.age}</code>
        sex: <code>{M1.sex}</code>
        login: <code>{M1.login}</code>
        class_name: <code>{M1.class_name}</code>
    '''
    
    output2 = f'''
    <b>User2:</b>
        ID: <code>{M2.id}</code>
        first_name: <code>{M2.first_name}</code>
        middle_name: <code>{M2.middle_name}</code>
        last_name: <code>{M2.last_name}</code>
        birthdate: <code>{M2.birthdate}</code>
        email: <code>{M2.email}</code>
        person_id:<code>{M2.person_id}</code>
        school_id: <code>{M2.school_id}</code>
        age: <code>{M2.age}</code>
        sex: <code>{M2.sex}</code>
        login: <code>{M2.login}</code>
        class_name: <code>{M2.class_name}</code>
    '''
    return f'''
{output1}

{output2}'''


class Config:
    def __init__(self, config_file = 'config.json'):
        """
        Инициализирует объект конфигурации.

        Параметры:
        - config_file (str): Путь к файлу конфигурации в формате JSON.
        """
        self.config_file = config_file
        with open(config_file) as f:
            data = json.load(f)
        self.data = data
        self.mech_token = data['token']['MECH']
        self.mech_token2 = data['token']['MECH2']
        
        self.telegram_token = data['token']['TELEGRAM']
        self.logs_discussion = data['logs_discussion']
        self.access_discussions = data['work_discussion']
        
        self.access_users = data['access_users']
        self.access_user_prems = data['access_user_prems']
        
        self.download_all_images = data['download_all_images']
        
        self.sending_post = data['sending_post']
        
        self.weather = data['other']['weather']
        self.emotions = data['other']['emotions']
        
    def load(self):
        """
        Загружает конфигурацию из файла JSON.
        """
        with open(self.config_file) as f:
            data = json.load(f)
        self.data = data
        self.mech_token = data['token']['MECH']
        self.telegram_token = data['token']['TELEGRAM']
        self.logs_discussion = data['logs_discussion']
        self.access_discussions = data['work_discussion']
        
        self.access_users = data['access_users']
        self.access_user_prems = data['access_user_prems']
        
        self.download_all_images = data['download_all_images']
        
        self.sending_post = data['sending_post']
        
        self.weather = data['other']['weather']
        self.emotions = data['other']['emotions']
    
    def upload(self, new_data):
        """
        Загружает новые данные в файл конфигурации JSON.

        Параметры:
        - new_data: Новые данные для загрузки.
        """
        json.dump(new_data, open(self.config_file, 'w'), indent=4, default=list)
        with open(self.config_file) as f:
            data = json.load(f)
        self.data = data
        self.mech_token = data['token']['MECH']
        self.telegram_token = data['token']['TELEGRAM']
        self.logs_discussion = data['logs_discussion']
        self.access_discussions = data['work_discussion']
        
        self.access_users = data['access_users']
        self.access_user_prems = data['access_user_prems']
        
        self.download_all_images = data['download_all_images']
        
        self.sending_post = data['sending_post']
        
        self.weather = data['other']['weather']
        self.emotions = data['other']['emotions']

    def edit_config_file(self, attribute_form, value, az = 1):
        if az == 1:
            self.data[attribute_form[0]] = value
        elif az == 2:
            az1, az2 = attribute_form[0], attribute_form[1]
            self.data[az1][az2] = value
        elif az == 3:
            az1, az2, az3 = attribute_form[0], attribute_form[1], attribute_form[2]
            self.data[az1][az2][az3] = value
        json.dump(self.data, open(self.config_file, 'w'), indent=4, default=list)
        self.load()
    
    


class AllFunctionsDataHandler():
    """
    Класс AllFunctionsDataHandler предоставляет различные функции для работы с датами.

    Методы:
    - get_old_days(time_old, time_now=None): Возвращает количество дней между двумя датами.
    - get_next_date_by_day_and_date(date_, days): Возвращает новую дату после указанного количества дней.
    - get_index_date(data): Возвращает количество дней от определенной даты до текущей даты.
    - get_old_date_by_day_and_date(date_, days): Возвращает дату, предшествующую указанной дате на заданное количество дней.
    - get_day_nedeli_by_date(date_): Возвращает день недели для указанной даты.
    - get_all_dates_by_day_and_date(now=str(datetime.now())): Выводит даты и дни недели для определенного диапазона дней.
    """
    def get_old_days(self, time_old, time_now=None):
        """
        Возвращает количество дней между двумя датами.

        Параметры:
        - time_old (str): Строка с датой в формате 'YYYY-MM-DD'.
        - time_now (str, optional): Строка с текущей датой в формате 'YYYY-MM-DD'. По умолчанию - текущая дата.

        Возвращает:
        - int: Количество дней между указанными датами.
        """
        if time_now is None:
            time_now = str(date.today())
        aa = date.fromisoformat(time_now)
        bb = date.fromisoformat(time_old)
        old_days = abs(aa - bb).days
        return old_days

    def get_next_date_by_day_and_date(self, date_, days):
        """
        Возвращает новую дату после указанного количества дней.

        Параметры:
        - date_ (str): Строка с начальной датой в формате 'YYYY-MM-DD'.
        - days (int): Количество дней для прибавления к начальной дате.

        Возвращает:
        - datetime.date: Новая дата после указанного количества дней.
        """
        input_date = date.fromisoformat(date_)
        delta = timedelta(days=int(days))
        new_date = input_date + delta
        return new_date

    def get_index_date(self, data):
        """
        Возвращает количество дней от определенной даты до текущей даты.

        Параметры:
        - data (str): Строка с датой в формате 'YYYY-MM-DD'.

        Возвращает:
        - int: Количество дней от указанной даты до текущей даты.
        """
        return self.get_old_days('2023-01-01', data)

    def get_old_date_by_day_and_date(self, date_, days):
        """
        Возвращает дату, предшествующую указанной дате на заданное количество дней.

        Параметры:
        - date_ (str): Строка с начальной датой в формате 'YYYY-MM-DD'.
        - days (int): Количество дней для вычитания из начальной даты.

        Возвращает:
        - datetime.date: Дата, предшествующая указанной дате на заданное количество дней.
        """
        input_date = date.fromisoformat(date_)
        delta = timedelta(days=int(days))
        new_date = input_date - delta
        return new_date

    def get_day_nedeli_by_date(self, date_):
        """
        Возвращает день недели для указанной даты.

        Параметры:
        - date_ (str): Строка с датой в формате 'YYYY-MM-DD'.

        Возвращает:
        - str: Название дня недели (например, 'Понедельник').
        """
        ind = date_.isoweekday()
        day_nedeli = ''
        if ind == 1:
            day_nedeli = 'Пн'
        elif ind == 2:
            day_nedeli = 'Вт'
        elif ind == 3:
            day_nedeli = 'Ср'
        elif ind == 4:
            day_nedeli = 'Чт'
        elif ind == 5:
            day_nedeli = 'Пт'
        elif ind == 6:
            day_nedeli = 'Сб'
        elif ind == 7:
            day_nedeli = 'Вс'
        return day_nedeli

    def get_all_dates_by_day_and_date(self, now = str(datetime.now())):
        """
        Выводит даты и дни недели для определенного диапазона дней.
        """
        now = now.split(' ')[0]
        index = self.get_index_date(now)
        day_nedeli = self.get_day_nedeli_by_date(date.fromisoformat(now))
        one, two = index - 2, index + 3
        otpr = []
        for index_day in range(one, two):
            if index_day < index:
                day_ = self.get_old_date_by_day_and_date(now, index - index_day)
            elif index_day > index:
                day_ = self.get_next_date_by_day_and_date(now, index_day - index)
            else:
                day_ = now
            day_nedeli = self.get_day_nedeli_by_date(date.fromisoformat(str(day_)))
            otpr.append([index_day, str(day_), day_nedeli])
        return otpr

def send_custom_keyboard(F, data):
    """
    Функция для отправки кастомной клавиатуры.

    Параметры:
    - F (AllFunctionsDataHandler): Объект класса AllFunctionsDataHandler.
    - data: Данные для отправки клавиатуры.

    Возвращает:
    - InlineKeyboardMarkup: Кастомная клавиатура.
    """
    datas = F.get_all_dates_by_day_and_date(now = data)
    markup_old_now_next_dz = InlineKeyboardMarkup()
    markup_old_now_next_dz.add(
                            InlineKeyboardButton(text=f'{datas[0][1]} [{datas[0][2]}]', callback_data=f'SendCustomHomework.{datas[0][1]}'),
                            InlineKeyboardButton(text=f'{datas[1][1]} [{datas[1][2]}]', callback_data=f'SendCustomHomework.{datas[1][1]}'))
    
    markup_old_now_next_dz.add(InlineKeyboardButton(text=f'{datas[2][1]} [{datas[2][2]}]', callback_data=f'SendCustomHomework.{datas[2][1]}'))
    markup_old_now_next_dz.add(
                            InlineKeyboardButton(text=f'{datas[3][1]} [{datas[3][2]}]', callback_data=f'SendCustomHomework.{datas[3][1]}'),
                            InlineKeyboardButton(text=f'{datas[4][1]} [{datas[4][2]}]', callback_data=f'SendCustomHomework.{datas[4][1]}'))
    return markup_old_now_next_dz



        
def is_school_day():
    """
    Определяет, является ли текущий день школьным, исключая дни каникул.

    Returns:
        bool: Возвращает True, если сегодня школьный день, и False в противном случае.
    """
    today = datetime.now().date().isoformat()
    year = datetime.now().date().year

    def get_weekends(year):
        """
        Получает список выходных дней для указанного года.

        Args:
            year (int): Год для получения выходных дней.

        Returns:
            list: Список выходных дней в формате 'YYYY-MM-DD'.
        """
        weekends = []
        cal = calendar.Calendar(firstweekday=calendar.MONDAY)

        for month in range(1, 13):
            for day in cal.itermonthdays2(year, month):
                if day[0] != 0 and day[1] in [5, 6]:
                    weekends.append(date(year, month, day[0]).isoformat())

        return weekends

    weekends = get_weekends(year)

    school_holidays = [
        {"начало": "02-19", "конец": "02-25"},
        {"начало": "04-08", "конец": "04-14"},
        {"начало": "05-01", "конец": "05-05"},
        {"начало": "06-01", "конец": "08-31"},
        {"начало": "12-28", "конец": "01-07"},
    ]

    for holiday in school_holidays:
        start_date = f'{year}-{holiday["начало"]}'

        if holiday["конец"] == '01-07':
            year = str(int(year) + 1)

        end_date = f'{year}-{holiday["конец"]}'
        # print(f'{start_date} <= {today} <= {end_date}')
        if (start_date <= today <= end_date) or (today in weekends):
            return False
    return True
    


def get_ip_info():
    try:
        key_ = '39430947b2dc928327bb4ba30df4213d'
        response = requests.get(f'''http://api.ipapi.com/api/{requests.get(f"https://ipinfo.io").json()['ip']}?access_key={key_}''')
        
        ip_info = response.json()
        

        return f'''
    <b>Information about IP:</b>
        IP: <code>{ip_info['ip']}</code>
        Continent Name: <code>{ip_info['continent_name']}</code>
        City: <code>{ip_info['city']}</code>
        Country: <code>{ip_info['country_name']}</code>
        Region: <code>{ip_info['region_name']}</code>
        Lang: <code>{ip_info['location']['languages'][0]['name']}</code>
    '''
    except Exception as err:
        return f'''
    <b>Information about IP:</b>
        Error: <code>{err}</code>
    '''

def days_and_weeks_until_targetS():
    def skl_nedeli(число):
        if число % 10 == 1 and число % 100 != 11:
            форма = "неделя"
        elif 2 <= число % 10 <= 4 and (число % 100 < 10 or число % 100 >= 20):
            форма = "недели"
        else:
            форма = "недель"
        return f"{число} {форма}"
    def skl_name(число):
        if число % 10 == 1 and число % 100 != 11:
            форма = "день"
        elif 2 <= число % 10 <= 4 and (число % 100 < 10 or число % 100 >= 20):
            форма = "дня"
        else:
            форма = "дней"
        return f"{число} {форма}"
    def days_and_weeks_until_target(target_date):
        try:
            # Get the current date
            today = datetime.now()

            # Convert the target date string to a datetime object
            target_date = datetime.strptime(target_date, "%Y-%m-%d")

            # Calculate the difference in days
            az = str(target_date.date() - today.date()).replace(" days, 0:00:00", "")
            days_difference = (target_date - today).days

            # Calculate the number of weeks and remaining days
            weeks_until_target = days_difference // 7
            remaining_days = days_difference % 7

            return weeks_until_target, remaining_days, az
        except ValueError:
            return "Invalid date format. Please use the 'YYYY-MM-DD' format."

# # Example usage
# target_date = "2024-05-28"
# weeks, remaining_days, az = days_and_weeks_until_target("2024-05-28")
# print(f"There are approximately {weeks} weeks and {remaining_days} days until the target date.")

# weeks, remaining_days, az = days_and_weeks_until_target("2024-04-17")
# print(f"There are approximately {weeks} weeks and {remaining_days} days until the target date.")

    data_ = {
        "2024-04-17" : "Сдача проектов",
        "2024-05-28" : "Экзамен - Русский язык",
        "2024-05-31" : "Экзамен - Математика (база/профиль)",
    }
    
    zxc = '<b>Сводка по событиям:</b>'
    for dat in data_:
        information =  data_[dat]
        z1, z2, z3 = days_and_weeks_until_target(dat)
        zxc = zxc + f'''

Событие: <b>{information}</b>
Осталось: <code>{skl_nedeli(z1)}</code> или <code>{skl_name(int(z3))}</code> до <b>{(datetime.strptime(dat, "%Y-%m-%d").strftime("%d.%m.%Y"))}</b>'''     
    return zxc
    
# if __name__ == "__main__":days_and_weeks_until_targetS()

def rezerve_logs_stek_no_log(message, bot, C):
    if message.from_user.id in C.access_users:
        err = ''
        try:
            with open("modules/MainScript.log", "r") as file1:
                lines = []
                for line in file1:lines.append(line.strip())
                data = '\n'.join(lines)
                data = data.replace('<', '_(_').replace('>', '_)_')
                if len(data) > 4095:
                    for x in range(0, len(data), 4095):
                            bot.send_message(chat_id = message.chat.id, text=f'''<pre><code class="language-python">{data[x:x+4095]}</code></pre>''', parse_mode='html')
                            time.sleep(2)
                else:
                    bot.reply_to(message, text=f'''Успех!\n<pre><code class="language-python">{data}</code></pre>''', parse_mode='html')
        except Exception as e:
            err = err+'\n'+traceback.format_exc()
        try:
            with open("modules/MainScript.log",'rb') as myzip:bot.send_document(chat_id=message.chat.id, document=myzip, caption='Логи хоста')
        except Exception as e:
            err = err+f'\n{"-"*10}\n'+traceback.format_exc()
        if err !='':
            bot.reply_to(message, text=f'''Произошла ошибка с одним из компонентов.\n<pre><code class="language-python">{err}</code></pre>''', parse_mode='html')

class Handles():
    def __init__(self, val_, WDir, bot, MODULE):
        self.val = val_
        self.WDir = WDir
        self.bot = bot
        self.MODULE = MODULE
    
    def handle_sticker(self,message):
        pass
    
    def handle_contact(self,message):
        pass

    def handle_photo(self, message):
        try:
            if self.val != 'True':
                kFolder = 'pictures'
            else:
                kFolder = 'nekoDB'
                
            name_dir = os.path.join(os.getcwd(), 'attachments', str(int(message.chat.id)), kFolder)
            for d in ['attachments', str(int(message.chat.id)), kFolder]:
                if not os.path.exists(d):
                    os.mkdir(d)
                os.chdir(d)
            os.chdir(self.WDir)

            file_info = self.bot.get_file(message.photo[len(message.photo) - 1].file_id)
            downloaded_file = self.bot.download_file(file_info.file_path)

            src = os.path.join(name_dir, str(file_info.file_path).replace('photos/',''))
            # os.chdir(src)
            while not os.path.exists(src):
                try:
                    with open(src, 'wb') as new_file:new_file.write(downloaded_file)
                except FileExistsError:src = src + '_'
            self.MODULE.info(command = 'handle_photo', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfull downloading')
            os.chdir(self.WDir)
        except Exception as err:
            self.MODULE.error(command = 'handle_photo', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message=str(err) + '\n'+ traceback.format_exc())

    def handle_document(self, message):
        try:
            if self.val != 'True':
                kFolder = 'document'
            else:
                kFolder = 'nekoDB'
                
            name_dir = os.path.join(os.getcwd(), 'attachments', str(int(message.chat.id)), kFolder)
            for d in ['attachments', str(int(message.chat.id)), kFolder]:
                if not os.path.exists(d):
                    os.mkdir(d)
                os.chdir(d)
            os.chdir(self.WDir)

            # os.chdir(WDir)
            file_info = self.bot.get_file(message.document.file_id)
            downloaded_file = self.bot.download_file(file_info.file_path)

            src = os.path.join(name_dir, message.document.file_name)
            # os.chdir(src)
            while not os.path.exists(src):
                try:
                    with open(src, 'wb') as new_file:new_file.write(downloaded_file)
                except FileExistsError:src = src + '_'
            self.MODULE.info(command = 'handle_document', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfull downloading')
            os.chdir(self.WDir)
        except Exception as err:
            self.MODULE.error(command = 'handle_document', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message=str(err) + '\n' + traceback.format_exc())

    
        
    def handle_animation(self, message):
        try:
            if self.val != 'True':
                kFolder = 'animation'
            else:
                kFolder = 'nekoDB'
                
            name_dir = os.path.join(os.getcwd(), 'attachments', str(int(message.chat.id)), kFolder)
            for d in ['attachments', str(int(message.chat.id)), kFolder]:
                if not os.path.exists(d):
                    os.mkdir(d)
                os.chdir(d)
            os.chdir(self.WDir)
                
                
            file_info = self.bot.get_file(message.animation.file_id)
            downloaded_file = self.bot.download_file(file_info.file_path)
            src = os.path.join(name_dir, str(file_info.file_path).replace('animations/',''))

            while not os.path.exists(src):
                try:
                    with open(src, 'wb') as new_file:new_file.write(downloaded_file)
                except FileExistsError:src = src + '_'
            self.MODULE.info(command = 'handle_animation', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfull downloading')
            os.chdir(self.WDir)
        except Exception as err:
            self.MODULE.error(command = 'handle_animation', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message=str(err) + '\n' + traceback.format_exc())

    
    def handle_audio(self, message):
        try:
            if self.val != 'True':
                kFolder = 'audio'
            else:
                kFolder = 'nekoDB'
                
            name_dir = os.path.join(os.getcwd(), 'attachments', str(int(message.chat.id)), kFolder)
            for d in ['attachments', str(int(message.chat.id)), kFolder]:
                if not os.path.exists(d):
                    os.mkdir(d)
                os.chdir(d)
            os.chdir(self.WDir)
            
            file_info = self.bot.get_file(message.audio.file_id)
            downloaded_file = self.bot.download_file(file_info.file_path)

            src = os.path.join(name_dir, message.audio.file_name)
            while not os.path.exists(src):
                with open(src, 'wb') as new_file:
                    try:
                        new_file.write(downloaded_file)
                    except FileExistsError:src = src + '_'
            self.MODULE.info(command = 'handle_audio', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfull downloading')
            os.chdir(self.WDir)
        except Exception as err:
            self.MODULE.error(command = 'handle_audio', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message=str(err) + '\n' + traceback.format_exc())

    
    def handle_video(self, message):
        try:
            if self.val != 'True':
                kFolder = 'video'
            else:
                kFolder = 'nekoDB'
                
            name_dir = os.path.join(os.getcwd(), 'attachments', str(int(message.chat.id)), kFolder)
            for d in ['attachments', str(int(message.chat.id)), kFolder]:
                if not os.path.exists(d):os.mkdir(d)
                os.chdir(d)
            os.chdir(self.WDir)
            
            file_info = self.bot.get_file(message.video.file_id)
            downloaded_file = self.bot.download_file(file_info.file_path)

            src = os.path.join(name_dir, message.video.file_name)
            while not os.path.exists(src):
                with open(src, 'wb') as new_file:
                    try:new_file.write(downloaded_file)
                    except FileExistsError:src = src + '_'
                    
            self.MODULE.info(command = 'handle_video', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'successfull downloading')
            os.chdir(self.WDir)
        except Exception as err:
            self.MODULE.error(command = 'handle_video', autor_log= f'{message.chat.id}.{message.from_user.id}', text = 'Exception', code = 0, error_message=str(err))



class EditConfigHandler():
    def __init__(self, bot, C):
        self.bot = bot
        self.config = C
        
    def edit_config_M(self, message):
        # print(message.json)
        json.dump(message.json, open('5565543.json', 'w'), indent=4, default=list)
        
        if (message.text != 'Отмена') or (message.text != '/cancel'):
            if message.chat.type == 'private':
                def get_token(message):
                    token_Q = message.text
                    def Q(message):
                        if (message.text != 'Отмена') or (message.text != '/cancel'):
                            if message.text.lower() in [ 'Да'.lower(), 'Yes'.lower(), 'OK'.lower()]:
                                print(f'Active tokenM {token_Q}')
                                self.config.edit_config_file(('token', 'MECH'), token_Q, 2)
                        else:
                            self.bot.reply_to(message = message, text = 'Вы отменили действие.')
                
                    self.bot.register_next_step_handler(self.bot.reply_to(message=message,  text = 'Вы правильно указали?', parse_mode = 'html'), Q)
                self.bot.register_next_step_handler(self.bot.send_message(chat_id = message.chat.id,  text = 'Введите новый Mтокен, иначе Отмена', parse_mode = 'html'), get_token)
            else:
                self.bot.reply_to(message = message, text = 'Эта команду нужно вводить только в лс бота.')
        else:
            self.bot.reply_to(message = message, text = 'Вы отменили действие.')
            
            
    def edit_config_T(self, message):
        json.dump(message.json, open('5565543.json', 'w'), indent=4, default=list)
        
        if (message.text != 'Отмена') or (message.text != '/cancel'):
            if message.chat.type == 'private':
                def get_token(message):
                    token_Q = message.text
                    def Q(message):
                        if (message.text != 'Отмена') or (message.text != '/cancel'):
                            if message.text.lower() in [ 'Да'.lower(), 'Yes'.lower(), 'OK'.lower()]:
                                print(f'Active tokenT {token_Q}')
                                self.config.edit_config_file(('token', 'TELEGRAM'), token_Q, 2)
                        else:
                            self.bot.reply_to(message = message, text = 'Вы отменили действие.')
                
                    self.bot.register_next_step_handler(self.bot.reply_to(message=message,  text = 'Вы правильно указали?', parse_mode = 'html'), Q)
                self.bot.register_next_step_handler(self.bot.send_message(chat_id = message.chat.id,  text = 'Введите новый Tтокен, иначе Отмена', parse_mode = 'html'), get_token)
            else:
                self.bot.reply_to(message = message, text = 'Эта команду нужно вводить только в лс бота.')
        else:
            self.bot.reply_to(message = message, text = 'Вы отменили действие.') 
            
            
    def edit_config_senler_morning(self, message):
        json.dump(message.json, open('5565543.json', 'w'), indent=4, default=list)
        
        if (message.text != 'Отмена') or (message.text != '/cancel'):
            if message.chat.type == 'private':
                def get_token(message):
                    token_Q = message.text
                    def Q(message):
                        if (message.text != 'Отмена') or (message.text != '/cancel'):
                            if message.text.lower() in [ 'Да'.lower(), 'Yes'.lower(), 'OK'.lower()]:
                                print(f'Active morning time {token_Q}')
                                self.config.edit_config_file(('sending_post', 'morning'), token_Q, 2)
                        else:
                            self.bot.reply_to(message = message, text = 'Вы отменили действие.')
                
                    self.bot.register_next_step_handler(self.bot.reply_to(message=message,  text = 'Вы правильно указали?', parse_mode = 'html'), Q)
                self.bot.register_next_step_handler(self.bot.send_message(chat_id = message.chat.id,  text = 'Введите новое утреннее время, иначе Отмена', parse_mode = 'html'), get_token)
            else:
                self.bot.reply_to(message = message, text = 'Эта команду нужно вводить только в лс бота.')
        else:
            self.bot.reply_to(message = message, text = 'Вы отменили действие.')     

    def edit_config_senler_evening(self, message):
        json.dump(message.json, open('5565543.json', 'w'), indent=4, default=list)
        
        if (message.text != 'Отмена') or (message.text != '/cancel'):
            if message.chat.type == 'private':
                def get_token(message):
                    token_Q = message.text
                    def Q(message):
                        if (message.text != 'Отмена') or (message.text != '/cancel'):
                            if message.text.lower() in [ 'Да'.lower(), 'Yes'.lower(), 'OK'.lower()]:
                                print(f'Active evening time {token_Q}')
                                self.config.edit_config_file(('sending_post', 'evening'), token_Q, 2)
                        else:
                            self.bot.reply_to(message = message, text = 'Вы отменили действие.')
                
                    self.bot.register_next_step_handler(self.bot.reply_to(message=message,  text = 'Вы правильно указали?', parse_mode = 'html'), Q)
                self.bot.register_next_step_handler(self.bot.send_message(chat_id = message.chat.id,  text = 'Введите новое вечернее время, иначе Отмена', parse_mode = 'html'), get_token)
            else:
                self.bot.reply_to(message = message, text = 'Эта команду нужно вводить только в лс бота.')
        else:
            self.bot.reply_to(message = message, text = 'Вы отменили действие.')

    def edit_config_weather_lang(self, message):
        json.dump(message.json, open('5565543.json', 'w'), indent=4, default=list)
        
        if (message.text != 'Отмена') or (message.text != '/cancel'):
            if message.chat.type == 'private':
                def get_token(message):
                    token_Q = message.text
                    def Q(message):
                        if (message.text != 'Отмена') or (message.text != '/cancel'):
                            if message.text.lower() in [ 'Да'.lower(), 'Yes'.lower(), 'OK'.lower()]:
                                print(f'Active RU {token_Q}')
                                self.config.edit_config_file(('other', 'weather', 'weather_language'), token_Q, 3)
                        else:
                            self.bot.reply_to(message = message, text = 'Вы отменили действие.')
                
                    self.bot.register_next_step_handler(self.bot.reply_to(message=message,  text = 'Вы правильно указали?', parse_mode = 'html'), Q)
                self.bot.register_next_step_handler(self.bot.send_message(chat_id = message.chat.id,  text = 'Введите новое значение языка, иначе Отмена', parse_mode = 'html'), get_token)
            else:
                self.bot.reply_to(message = message, text = 'Эта команду нужно вводить только в лс бота.')
        else:
            self.bot.reply_to(message = message, text = 'Вы отменили действие.')

    def edit_config_weather_city(self, message):
        json.dump(message.json, open('5565543.json', 'w'), indent=4, default=list)
        
        if (message.text != 'Отмена') or (message.text != '/cancel'):
            if message.chat.type == 'private':
                def get_token(message):
                    token_Q = message.text
                    def Q(message):
                        if (message.text != 'Отмена') or (message.text != '/cancel'):
                            if message.text.lower() in [ 'Да'.lower(), 'Yes'.lower(), 'OK'.lower()]:
                                print(f'Active city {token_Q}')
                                self.config.edit_config_file(('other', 'weather', 'city'), token_Q, 3)
                        else:
                            self.bot.reply_to(message = message, text = 'Вы отменили действие.')
                
                    self.bot.register_next_step_handler(self.bot.reply_to(message=message,  text = 'Вы правильно указали?', parse_mode = 'html'), Q)
                self.bot.register_next_step_handler(self.bot.send_message(chat_id = message.chat.id,  text = 'Введите новое значение города, иначе Отмена', parse_mode = 'html'), get_token)
            else:
                self.bot.reply_to(message = message, text = 'Эта команду нужно вводить только в лс бота.')
        else:
            self.bot.reply_to(message = message, text = 'Вы отменили действие.')
   
    def Sorting(self, command, message):
        if command == 'token-m':self.edit_config_M(message)
        elif command == 'token-t':self.edit_config_T(message)
        elif command == 'senler-morning':self.edit_config_senler_morning(message)
        elif command == 'senler-evening':self.edit_config_senler_evening(message)
        elif command == 'weather-lang':self.edit_config_weather_lang(message)
        elif command == 'weather-city':self.edit_config_weather_city(message)



if __name__ == '__main__':
    # print(is_school_day())
    get_ip_info()
    F = AllFunctionsDataHandler()
    send_custom_keyboard(F)
    print(F.get_all_dates_by_day_and_date())
    
    a_ = F.get_old_days('2023-01-01')
    b_ = F.get_old_days('2023-01-01', '2023-01-01')
    print(a_, b_)

    a_ = F.get_next_date_by_day_and_date(str(date.today()), 5)
    b_ = F.get_next_date_by_day_and_date(str(date.today()), 4)
    print(a_, b_)

    a_ = F.get_old_date_by_day_and_date(str(date.today()), 5)
    b_ = F.get_old_date_by_day_and_date(str(date.today()), 4)
    print(a_, b_)
