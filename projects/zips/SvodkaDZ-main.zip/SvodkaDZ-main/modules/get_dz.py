import json
try:
    from modules.mech.student import Student
    from modules.mech.homeworks import Homeworks
    from modules.mech.errors.token import DnevnikTokenError
except:
    from mech.student import Student
    from mech.homeworks import Homeworks
from datetime import datetime as datetime_




calendar = {1 : 31, 2 : 28, 3 : 31, 4 : 30, 5 : 31,6 : 30, 7 : 31, 8 : 31, 9 : 30, 10: 31, 11: 30, 12: 31}


class Mech:
    def __init__(self, Config):
        """
        Инициализация объекта класса Mech.

        Параметры:
        - Config: Объект, содержащий конфигурационные данные, в том числе токены для авторизации.

        Функциональность:
        - Инициализирует объект Mech, создавая два объекта Student и два объекта Homeworks для двух аккаунтов.
        - Выводит информацию о текущих авторизованных аккаунтах.

        Пример использования:
        - Предполагая, что 'config' - это объект, содержащий конфигурационные данные:
            mech_instance = Mech(config)
        """
        self.token_MECH = Config.mech_token
        self.student = Student(token=self.token_MECH)
        self.homework = Homeworks(self.student)
        

        self.token_MECH2 = Config.mech_token2
        self.student2 = Student(token=self.token_MECH2)
        self.homework2 = Homeworks(self.student2)

        print(f'''Авторизован как:
Основной аккаунт: {self.student.first_name} {self.student.last_name}
Второй аккаунт:   {self.student2.first_name} {self.student2.last_name}''')
        self.all_names = [[f'{self.student.first_name} {self.student.last_name}'], [f'{self.student2.first_name}  {self.student2.last_name}']]
        self.all_statuses = [[self.homework.status_code1, self.homework2.status_code2], [self.homework2.status_code1, self.homework2.status_code2]]
    
    def get_users(self):
        return self.student, self.student2

    def stat_next_date(self, old_date):
        """
        Получить следующую дату относительно указанной даты.

        Параметры:
        - self: Экземпляр класса Mech, содержащий этот метод.
        - old_date (str): Исходная дата в формате 'ГГГГ-ММ-ДД'.

        Возвращает:
        - str: Строка, представляющая следующую дату относительно входной даты.

        Функциональность:
        - Принимает исходную дату в формате 'ГГГГ-ММ-ДД'.
        - Вычисляет следующую дату и возвращает ее в том же формате.
        - В случае, если следующая дата находится в следующем месяце или году, корректирует значения месяца и года.

        Пример использования:
        - Предполагая, что 'mech_instance' - это экземпляр класса Mech:
            next_date = mech_instance.stat_next_date('2023-01-15')
            print(next_date)

        Примечания:
        - Функция использует календарь для определения количества дней в месяце.
        - Результат представлен в формате 'ГГГГ-ММ-ДД'.
        """
        yearO, monthO, dayO = old_date.split('-')[0], old_date.split('-')[1], old_date.split('-')[2]
        dayN = int(int(dayO) + 1)
        if dayN > calendar[int(monthO)]:
                
                dayN = f'0{1}'
                monthN = int(monthO)
                yearN = yearO
                if int(monthN) < 10:monthN = f'0{int(monthN)}'
                elif int(monthN) == 12:
                    monthN = f'0{1}'
                    yearN = int(yearO) + 1
                else:
                    monthN = int(monthN) + 1

        elif int(dayO)  < calendar[int(monthO)]:
            monthN = monthO
            dayN = int(int(dayO) + 1)
            if dayN < 10:
                dayN = f'0{dayN}'
            yearN = yearO
        elif int(dayO) == calendar[int(monthO)]:
            yearN = yearO
            monthN = monthO
            if int(monthO) == 12:
                dayN = f'0{1}'
                monthN = f'0{1}'
                yearN = int(yearO) + 1
        else:
            
            print(f'{dayN} > {calendar[int(monthO)]}')
        new_time = f'{yearN}-{monthN}-{dayN}'
        return new_time
    
    def stat_now_date(self):
        """
    Получить текущую дату в формате строки.

    Параметры:
    - self: Экземпляр класса, содержащий этот метод.

    Возвращает:
    - str: Строка, представляющая текущую дату в формате 'ГГГГ-ММ-ДД'.

    Функциональность:
    - Использует модуль datetime для получения текущей даты и времени.
    - Преобразует текущую дату в строку и извлекает только часть с датой (без времени).
    - Возвращает строку с текущей датой.

    Пример использования:
    - Предполагая, что 'instance' - это экземпляр класса, содержащий этот метод:
        current_date = instance.stat_now_date()
        print(current_date)

    Примечания:
    - Функция не принимает дополнительных параметров.
    - Текущая дата представлена в формате 'ГГГГ-ММ-ДД'.
        """
        return str(datetime_.now()).split(' ')[0]
    
    def stat_old_date(self, old_date):
        """
    Получить предыдущую дату относительно указанной даты.

    Параметры:
    - self: Экземпляр класса, содержащий этот метод.
    - old_date (str): Исходная дата в формате 'ГГГГ-ММ-ДД'.

    Возвращает:
    - str: Строка, представляющая предыдущую дату относительно входной даты.

    Функциональность:
    - Принимает исходную дату в формате 'ГГГГ-ММ-ДД'.
    - Вычисляет предыдущую дату и возвращает ее в том же формате.
    - В случае, если предыдущая дата находится в предыдущем месяце или году, корректирует значения месяца и года.

    Пример использования:
    - Предполагая, что 'instance' - это экземпляр класса, содержащий этот метод:
        previous_date = instance.stat_old_date('2023-01-15')
        print(previous_date)

    Примечания:
    - Функция использует календарь для определения количества дней в месяце.
    - Результат представлен в формате 'ГГГГ-ММ-ДД'.
        """
        yearO, monthO, dayO = old_date.split('-')[0], old_date.split('-')[1], old_date.split('-')[2]
        dayN = int(int(dayO) - 1)
        
        
        if int(dayN) == 0:
            # print('int(dayN) == 0')
            if int(int(dayO)-1) == 0 and int(int(monthO)-1) == 0:
                monthN = 12
                dayN = int(int(monthN))
                yearN = int(yearO) - 1
            else:
                dayN = calendar[int(monthO)-1]
                monthN = int(monthO) - 1
                if int(monthN) < 10:
                    monthN = f'0{int(monthN)}'
                yearN = yearO
                if int(monthN) == 12:
                    yearN = int(yearO) - 1
                # print(dayN, monthN, yearN)
        elif int(dayN)  < calendar[int(monthO)]:
            # print('int(dayO)  < calendar[int(monthO)]')
            monthN = monthO
            dayN = int(int(dayO) - 1)
            yearN = yearO
        elif int(dayN) == calendar[int(monthO)]:
            # print(f'int(dayO) ({int(dayN)}) == calendar[int(monthO)] ({calendar[int(monthO)]})')
            yearN = yearO
            monthN = monthO
            if int(monthO) == 1:
                dayN = 1
                monthN = 12
                yearN = int(yearO) - 1
        elif int(dayN) == 0:
            # print(f'int(dayN) ({int(dayN)}) == 0')
            dayN = calendar[int(monthO)]
            monthN = 12
            yearN = int(yearO) - 1
            # print(dayN, monthN, yearN)
            
        else:
            
            print(f'{dayN} > {calendar[int(monthO)]}')
        new_time = f'{yearN}-{monthN}-{dayN}'
        # print(new_time)
        return new_time


    def new_year_date(self):
        
        today = datetime_.now()
        
        # raise
        new_year = datetime_(today.year + 1, 1, 1)
        days_until_new_year = (new_year - today).days
        
        if days_until_new_year <= 13:
            if days_until_new_year == 0:
                return "❄ С Новым Годом! ❄"
            else:
                if days_until_new_year == 1:end_ = 'день'
                elif days_until_new_year >= 2 and days_until_new_year <= 4:end_ = 'дня'
                else:end_ = 'дней'
                
                return f"❄ До Нового Года осталось {days_until_new_year} {end_}. ❄"
        else:
            return ''
    
    def check_spam_new_year(self, time_):
        today = time_#str(datetime_.now()).split(' ')[0]
        
        f_date  = [30, 31, 1, 2, 3, 4, 5, 6, 7]
        if str(today.split('-')[1]) == '12' or str(today.split('-')[1]) == '1':
            if int(today.split('-')[2]) in f_date:return True
        else:return False


    def get_homework_by_date(self, new_time):
        """
    Получить информацию о домашнем задании на конкретную дату.

    Параметры:
    - self: Экземпляр класса, содержащий этот метод.
    - new_time (str): Дата, для которой запрашивается информация о домашнем задании. Должна быть в формате 'ГГГГ-ММ-ДД'.

    Возвращает:
    - str: Отформатированная строка с подробностями домашнего задания для указанной даты.

    Функциональность:
    - Запрашивает информацию из двух экземпляров объектов 'homework' и 'homework2' для получения данных о домашнем задании на указанную дату.
    - Проверяет наличие ошибок при получении данных и формирует отформатированный ответ в соответствии с результатами.
    - Если информация о домашнем задании доступна, функция генерирует строку с подробностями по предметам.
    - Предусмотрена специальная обработка для объединения описаний домашнего задания по группам предметов.
    - Окончательная отформатированная строка включает названия предметов, описания домашнего задания и сообщение, если домашнего задания не найдено.

    Пример использования:
    - Предполагая, что 'instance' - это экземпляр класса, содержащий этот метод:
        result = instance.get_homework_by_date('2023-01-01')
        print(result)

    Примечания:
    - Функция предполагает наличие объектов 'homework' и 'homework2' с соответствующими методами.
    - Формат даты в параметре 'new_time' должен быть 'ГГГГ-ММ-ДД'.
    - Если произошла ошибка во время получения данных, соответствующие сообщения об ошибке возвращаются в результате.

        """
        Homeworks_in_user = list(self.homework.get_homework_by_date(date= new_time))
        Homeworks_in_user2 = list(self.homework2.get_homework_by_date(date= new_time))
        # print(Homeworks_in_user)
        # print(Homeworks_in_user2)
        dz = f'''{self.new_year_date()}

'''
        if (Homeworks_in_user != ['ERROR']) or (Homeworks_in_user2 != ['ERROR']):
            # if Homeworks_in_user != ['ERROR']:
                
                dz = dz + f'''🚨 ДЗ на {new_time.replace('-', '.')}'''
                
                subjects_by_groups = ['Английский язык', 'Индивидуальный проект', 'Программирование', 'Большие данные', 'Информатика']
                if self.check_spam_new_year(new_time):
                        dz = dz + f'''
                📕 Русский язык
                Домашнее задание:
                <a href="https://clck.ru/37MQhw">выполнить</a>
                '''
                else:
                    hw_ = []
                    # dz = dz + f'''🚨 ДЗ на {new_time.replace('-', '.')}'''
                    for i in Homeworks_in_user:
                        qa = {i.subject_name : i.description}
                        if qa not in hw_:
                            hw_.append(qa)
                    for i in Homeworks_in_user2:
                        qa = {i.subject_name : i.description}
                        if qa not in hw_:
                            hw_.append(qa)
                    
                    merged_homeworks = {}
                    all_homeworks = Homeworks_in_user + Homeworks_in_user2
                    if len(all_homeworks) > 0:
                        for homework in all_homeworks:
                            subject_name = homework.subject_name
                            description = homework.description
                            
                            if 'https://' in description:
                                for i in description.split(' '):
                                    if 'https://' in i:
                                        description = description.replace(i, f'</code><a href="{i}">[Click]</a><code>')
                            
                            if subject_name not in merged_homeworks:
                                merged_homeworks[subject_name] = []
                            if description not in merged_homeworks[subject_name]:
                                merged_homeworks[subject_name].append(description)
                                
                        for subject_name in merged_homeworks:
                            if len(merged_homeworks[subject_name]) == 1:
                                    
                                if subject_name in subjects_by_groups:
                                    for i in Homeworks_in_user:
                                        if str(merged_homeworks[subject_name][0]) == str(i.description):group = 'Группа №1'
                                    for i in Homeworks_in_user2:
                                        if str(merged_homeworks[subject_name][0]) == str(i.description):group = 'Группа №2'
                                    hw = f'''
{group}
{merged_homeworks[subject_name][0]}'''
                                else:
                                    hw = f'''
{merged_homeworks[subject_name][0]}'''
                            else:
                                hw = ''
                                i = 1
                                for hw_ in merged_homeworks[subject_name]:
                                    hw = hw + f'''
Группа №{i}: 
{hw_}
'''
                                    i = i + 1
                                    
                            dz = dz + f'''
                📕 {subject_name}
                Домашнее задание:
                <code>{hw}</code>
                    '''
                    else:
                        dz = dz + '''
                
                🎉 Нет домашнего задания!'''
                return dz

        
        
        else:
            print(f'\n\n{"-"*30}\nMODULE: Homework\n[WARNING] Invalids token!!!\n{"-"*30}\n\n')
            dz = f'''🚨 Ошибка! (2)
Небыло получено данных на {new_time.replace('-', '.')}'''
        return dz

if __name__ == '__main__':
    az = str(datetime_.now()).split(' ')[0]
    M = Mech()
    M.get_homework_by_date('2024-01-10')
