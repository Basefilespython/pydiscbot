import os
import shutil
from datetime import datetime, timezone, timedelta
from threading import Thread

log_filename = 'MainScript.log'

_DEBUG: bool = (os.environ.get('FLASK_ENV') == 'development')
_LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), log_filename)

if os.path.exists(_LOG_PATH):
    # ftm = str(datetime.fromtimestamp(os.path.getmtime(_LOG_PATH)).strftime('%d_%m_%Y_%H_%M_%S')) + '.log'
    ftm = f'logfile_{str(datetime.fromtimestamp(os.path.getmtime(_LOG_PATH)).strftime("%Y%m%d_%H%M%S"))}.log'
    logs_directory = os.path.join(os.path.abspath(os.getcwd()), 'logs')
    if not os.path.exists(logs_directory):
        os.mkdir(logs_directory)
    shutil.copyfile(os.path.join(os.path.dirname(__file__), log_filename), os.path.join(logs_directory, ftm))
    
else:
    print(f'File ({_LOG_PATH}) does not exist in {os.getcwd()}')


def STread(self, line):
    def by_error(err):
        err = str(err)
        if 'chat not found' in err:pass
            # print('TelegramLogger: Указанный канал не был найден!')
    if self.C.logs_discussion != 'None':
        data = line + '\n'
        data = data.replace('<', '_(_').replace('>', '_)_')
        if len(data) > 4095:
            for x in range(0, len(data), 4095):
                try:self.bot.send_message(chat_id = self.C.logs_discussion, text=f'''<pre><code class="language-python">{data[x:x+4095]}</code></pre>''', parse_mode='html')
                except Exception as e:
                    Thread(target=by_error, args=(e,), name='by_error').start()
        else:
            try:self.bot.send_message(chat_id = self.C.logs_discussion, text=f'''<pre><code class="language-python">{data}</code></pre>''', parse_mode='html')
            except Exception as e:
                Thread(target=by_error, args=(e,), name='by_error').start()

class NamedWriter:
    """
    Класс для записи сообщений в журнал с различными уровнями логирования.

    Атрибуты:
        name (str): Имя, связанное с регистратором.

    Методы:
        __init__(self, name: str): Инициализирует NamedWriter с указанным именем.
        __call__(self, text: str): Вызывает метод 'info' для удобства.
        _write(self, text: str, level: str, command_: str, code_: str, error_message_: str, autor_log_: str):
            Записывает запись журнала с заданными параметрами.
        trace(self, text: str, command: str, autor_log: str): Записывает запись журнала с уровнем 'TRACE'.
        debug(self, text: str, command: str, autor_log: str): Записывает запись журнала с уровнем 'DEBUG'.
        info(self, text: str, command: str, autor_log: str): Записывает запись журнала с уровнем 'INFO'.
        warning(self, text: str, command: str, autor_log: str): Записывает запись журнала с уровнем 'WARNING'.
        error(self, text: str, command: str, autor_log: str, code: str, error_message: str): Записывает запись журнала с уровнем 'ERROR'.
        critical(self, text: str, command: str, autor_log: str, code: str, error_message: str): Записывает запись журнала с уровнем 'CRITICAL'.
    """
    def __init__(self, name, bot, C):
        """
        Инициализирует экземпляр NamedWriter с указанным именем.

        Args:
            name (str): Имя, связанное с регистратором.
        """
        self.name = name
        self.bot = bot
        self.C = C

    def __call__(self, text: str):
        """
        Вызывает метод 'info' для удобства.

        Args:
            text (str): Текст для записи в журнал.
        """
        return self.info(text)

    def _write(self, text: str, level: str, command_: str = 'None', code_: str = 'None',
               error_message_: str = 'None', autor_log_: str = 'None'):
        """
        Записывает запись журнала с заданными параметрами.

        Args:
            text (str): Текст для записи в журнал.
            level (str): Уровень логирования ('TRACE', 'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL').
            command_ (str): Команда, связанная с записью журнала.
            code_ (str): Код ошибки, связанный с записью журнала.
            error_message_ (str): Сообщение об ошибке, связанное с записью журнала.
            autor_log_ (str): Лог автора, связанный с записью журнала.
        """
        date = datetime.now(timezone(timedelta(hours=3))).strftime('%d.%m.%Y %H:%M:%S')

        if level == 'INFO':
            cc1_, cc2_ = 4, 4
        elif level == 'WARNING':
            cc1_, cc2_ = 2, 3
        elif level == 'ERROR':
            cc1_, cc2_ = 3, 4
        else:
            cc1_, cc2_ = 2, 2

        l1 = f"{date} |{' '*cc1_}{level}{' '*cc2_}| "
        l2 = f"{l1}{self.name}{' '*(45-len(f'{l1}{self.name}'))}| "
        l3 = f"{l2}{command_}{' '*(65-len(f'{l2}{command_}'))}| "
        l4 = f"{l3}{autor_log_}{' '*(94-len(f'{l3}{autor_log_}'))}| "

        line = f"{l4}{text}"
        if level == 'ERROR' or level == 'WARNING':
            line = f"{line}:{code_}"
            if error_message_ != 'None':
                line = f"{line}: {error_message_}"

        with open(_LOG_PATH, 'a', encoding='utf-8') as log:
            log.write(line + '\n')
        
        
        
        Thread(target=STread, args=(self, line,), name='one_time_send_log_to_Telegram').start()
        # if self.C.logs_discussion != 'None':
        #     data = line + '\n'
        #     if len(data) > 4095:
        #         for x in range(0, len(data), 4095):
        #             # self.bot.send_message(chat_id = self.C.logs_discussion, text=f'''{data[x:x+4095]}''', parse_mode='html')
        #             self.bot.send_message(chat_id = self.C.logs_discussion, text=f'''<pre><code class="language-python">{data[x:x+4095]}</code></pre>''', parse_mode='html')
        #     else:
        #         self.bot.send_message(chat_id = self.C.logs_discussion, text=f'''<pre><code class="language-python">{data}</code></pre>''', parse_mode='html')
        #         # self.bot.send_message(chat_id = self.C.logs_discussion, text=f'''{data}''', parse_mode='html')
                   
        #     # L.info(command = 'config logs text', autor_log= f'{message.chat.id}.{message.from_user.id}', text = f'successfully sended')
                    


        if _DEBUG:
            print(line)
    
    # def to_log_discussion(self):
    #     self.bot
        
    def trace(self, text: str, command: str = 'None', autor_log: str = 'None'):
        """
        Записывает запись журнала с уровнем 'TRACE'.

        Args:
            text (str): Текст для записи в журнал.
            command (str): Команда, связанная с записью журнала.
            autor_log (str): Лог автора, связанный с записью журнала.
        """
        if not _DEBUG:
            return
        self._write(text, 'TRACE', command_=command, autor_log_=autor_log)

    def debug(self, text: str, command: str = 'None', autor_log: str = 'None'):
        """
        Записывает запись журнала с уровнем 'DEBUG'.

        Args:
            text (str): Текст для записи в журнал.
            command (str): Команда, связанная с записью журнала.
            autor_log (str): Лог автора, связанный с записью журнала.
        """
        if not _DEBUG:
            return
        self._write(text, 'DEBUG', command_=command, autor_log_=autor_log)

    def info(self, text: str, command: str = 'None', autor_log: str = 'None'):
        """
        Записывает запись журнала с уровнем 'INFO'.

        Args:
            text (str): Текст для записи в журнал.
            command (str): Команда, связанная с записью журнала.
            autor_log (str): Лог автора, связанный с записью журнала.
        """
        self._write(text, 'INFO', command_=command, autor_log_=autor_log)

    def warning(self, text: str, command: str = 'None', autor_log: str = 'None'):
        """
        Записывает запись журнала с уровнем 'WARNING'.

        Args:
            text (str): Текст для записи в журнал.
            command (str): Команда, связанная с записью журнала.
            autor_log (str): Лог автора, связанный с записью журнала.
        """
        self._write(text, 'WARNING', command_=command, autor_log_=autor_log)

    def error(self, text: str, command: str = 'None', autor_log: str = 'None', code: str = 'None', error_message: str = 'None'):
        """
        Записывает запись журнала с уровнем 'ERROR'.

        Args:
            text (str): Текст для записи в журнал.
            command (str): Команда, связанная с записью журнала.
            autor_log (str): Лог автора, связанный с записью журнала.
            code (str): Код ошибки, связанный с записью журнала.
            error_message (str): Сообщение об ошибке, связанное с записью журнала.
        """
        self._write(text, 'ERROR', command_=command, code_=code, error_message_=error_message, autor_log_=autor_log)

    def critical(self, text: str, command: str = 'None', autor_log: str = 'None', code: str = 'None', error_message: str = 'None'):
        """
        Записывает запись журнала с уровнем 'CRITICAL'.

        Args:
            text (str): Текст для записи в журнал.
            command (str): Команда, связанная с записью журнала.
            autor_log (str): Лог автора, связанный с записью журнала.
            code (str): Код ошибки, связанный с записью журнала.
            error_message (str): Сообщение об ошибке, связанное с записью журнала.
        """
        self._write(text, 'CRITICAL', command_=command, code_=code, error_message_=error_message, autor_log_=autor_log)


def get_writer(name, bot, C):
    """
    Возвращает экземпляр NamedWriter с указанным именем.

    Args:
        name (str): Имя, связанное с регистратором.

    Returns:
        NamedWriter: Экземпляр NamedWriter с указанным именем.
    """
    return NamedWriter(name, bot, C)


with open(_LOG_PATH + '.backup', 'w', encoding='utf-8') as backup:
    try:
        backup.write(open(_LOG_PATH, 'r', encoding='utf-8').read())
    except Exception:
        pass

open(_LOG_PATH, 'w').close()
with open(_LOG_PATH, 'a', encoding='utf-8') as log:log.write('        TIME             LEVEL      MODULE          COMMAND                  AUTOR                                TEXT' + '\n')


# logger = get_writer('Trace')

# def trace_(func):
#     def wrapper(message):
#         original_result = func(message)
#         logger.info(f' была вызнана функция {func.__name__} ')
#         return original_result
#     return wrapper
