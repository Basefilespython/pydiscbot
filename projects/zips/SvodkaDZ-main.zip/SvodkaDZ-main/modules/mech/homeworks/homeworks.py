from modules.mech.student import Student
from requests import get
from modules.mech.types import Homework as HomeworkType
import json

class Homeworks:
    def __init__(self, student: Student):
        self.token = student.token
        self.student_id = student.id
        self.status_code1 = student.student_profile_data.status_code
        self.status_code2 = student.userinfo.status_code

    def get_homework_by_date(self, date):
        res = []
        try:
            response = get(
                f"https://school.mos.ru/api/family/web/v1/homeworks?from={date}&to={date}&student_id={self.student_id}",
                headers={
                    "Auth-Token": self.token,
                    "X-Mes-Subsystem": "familyweb"
                }
            )
            
            if response.json()['payload'] != "Text '(False, 'Falure')":
                # with open(f'{date}_homework.json', "w") as outfile:json.dump(list(response.json()['payload']), outfile, indent=4)

                
                
                for homework in response.json()["payload"]:
                    # hw = homework["description"].decode('unicode-escape')
                    # hw = str(homework["description"].replace('%', '\\')).decode('unicode-escape')
                    # print(homework)
                    # print((homework["homework_entry_student_id"]).type())
                    res.append(
                        HomeworkType(
                            id=homework["homework_entry_student_id"],
                            description=homework["description"],
                            subject_id=homework["subject_id"],
                            subject_name=homework["subject_name"],
                            created_at=homework["date_assigned_on"],
                            is_done=homework["is_done"]
                        )
                    )
            else:
                res.append('ERROR')
        except:
            res.append('ERROR')
        return res
