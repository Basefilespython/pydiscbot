import json
class Statisticks():
    def __init__(self, bot, data_file = 'data/data.json'):
        self.data_file = data_file
        with open(data_file) as f:
            # f = f.read()
            self.data = json.load(f)
        self.channels = self.data.get('channels')
        if str(self.channels) == 'None':
            self.data['channels'] = {}
            self.channels = self.data.get('channels')
            json.dumps(self.data)
        
        self.bot = bot
        
        self.config_file = 'config.json'
        with open(self.config_file) as f:
            self.config_data = json.load(f)
        self.logs_discussion = self.config_data.get('logs_discussion')
        if str(self.logs_discussion) == 'None':
            print('No log discussion in Telegram')
    
    def reload(self):
        with open(self.data_file) as f:
            f = f.read()
            try:
                self.data = json.loads(f)
            except json.decoder.JSONDecodeError:
                try:
                    self.data = json.loads(f)
                except:raise
                
        with open(self.config_file) as f:
            f = f.read()
            try:
                self.config_data = json.loads(f)
            except json.decoder.JSONDecodeError:
                try:
                    self.config_data= json.loads(f)
                except:raise
                    
    def add(self, new_data, file):
        json.dump(new_data, open(file, 'w'), indent=4, default=list)
    
    def add_new_log_discussion(self, id_):
        try:
            if id_ != 'None':
                self.reload()
                print(self.config_file)
                print(self.config_data['logs_discussion'], type(self.config_data['logs_discussion']))
                self.config_data['logs_discussion'] = int(id_)
                json.dump(self.config_data, open(self.config_file, 'w'), indent=4, default=list)
                # self.add(self.config_file, self.config_file)
                self.reload()
            return 'OK', 'None'
        except Exception as err:
            return 'Error', f'{err}'
        
    def send_all_members(self, message):
        try:
            return self.data['channels'][f'{message.chat.id}']['members']
        except KeyError:
            self.add_new_discussion(id_=message.chat.id)
            self.reload()
            return self.data['channels'][f'{message.chat.id}']['members']
    
    def add_new_member(self, message, bot):
        self.old_data = self.data
        member_id_ = message.from_user.id
        channel_id = message.chat.id
        # print(f'adding new member, {self.channels} , {channel_id}')
        for id_ in [member_id_, bot.get_me().id]:
            member_id = id_
            if str(channel_id) not in self.channels:
                # print(f'adding new channel, {self.channels} , {channel_id}')
                self.add_new_discussion(id_=channel_id)
                self.reload()
                
            # len_do = len(self.data['channels'][f'{channel_id}']['members'])
            if member_id not in self.data['channels'][f'{channel_id}']['members']:
                if len(self.data['channels'][str(channel_id)]['members']) == 0:pass
                members = list(self.data['channels'][str(channel_id)]['members'])
                members.append(member_id)
                self.data['channels'][str(channel_id)]['members'] = members
            
            # json.dumps(self.old_data)
            json.dump(self.data, open(self.data_file, 'w'), indent=4, default=list)
            self.reload()
        # len_posle = len(self.data['channels'][f'{channel_id}']['members'])
        # # print(f"DONE! {len_do} + 1 = {len_posle}")
        # # raise
    
    def add_new_discussion(self, id_):
        # print(self.bot.get_chat(id_))
        self.data['channels'][int(id_)] = {
            "name" : self.bot.get_chat(id_).title,
            "invite_link" : self.bot.get_chat(id_).invite_link,
            "count" : self.bot.get_chat_members_count(id_),
            "members" : []
        }
        self.add(self.data, self.data_file)
