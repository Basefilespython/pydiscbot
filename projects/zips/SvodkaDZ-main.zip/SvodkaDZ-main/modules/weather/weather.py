
import requests
import datetime
import traceback

class WeaherConfigEror(Exception):pass

def get_weather(Config, index = 1):
    city = Config.weather['city']
    lang = Config.weather['weather_language'].lower()
    if not city:
        raise WeaherConfigEror('The city has not been determined.')
    else:
        # try:
            # print(city)
            data = requests.get(
                f'http://api.openweathermap.org/data/2.5/weather',
                params={'q': city, 'appid': "8ccf72ecedd6eb76311755cb76799810", 'units': 'metric', 'lang': lang}
            ).json()
            if data["cod"] == "404":
                # text = "❗ Город не найден"
                raise WeaherConfigEror('The city was not found.')
                
            else:
                if index == 1:
                    text = f"""
                    💬 Погода в {data['name']}
        
                    🌡️ Температура: {data['main']['temp']}°С
                    ☀️ Ощущается как: {data['main']['feels_like']}°С
                    ❄️ Макс/мин: {data['main']['temp_max']}°С/{data['main']['temp_min']}°С
                    ☁️ Погода: {data['weather'][0]['description'].capitalize()}
                    🌀 Ветер: {data['wind']['speed']} м/с
                    💧 Влажность: {data['main']['humidity']}%
        
                    🌆 Закат: {str(datetime.datetime.fromtimestamp(data['sys']['sunset']))[11:]}
                    🌅 Рассвет: {str(datetime.datetime.fromtimestamp(data['sys']['sunrise']))[11:]}
        
                    ☄ Давление: {data['main']['pressure']} мбар
                    👀 Видимость: {data['visibility']}м""".replace("                ", "")
                elif index == 2:
                    text = f"""
                    💬 Погода в {data['name']}
                    
                    ☁️ Погода: {data['weather'][0]['description'].capitalize()}
                    🌡️ Температура: {data['main']['temp']}°С
                    ☀️ Ощущается как: {data['main']['feels_like']}°С
                    🌀 Ветер: {data['wind']['speed']} м/с
                    💧 Влажность: {data['main']['humidity']}%

""".replace("                ", "")

            return text
        # except Exception:
        #     print(traceback.format_exc())
        #     return 'Error'

if __name__ == '__main__':
    print(get_weather('Moscow'))
